#include <iostream>
using namespace std;

class Point {public: float x, y;};    // (x,y) point

class Shape {
public:
	Shape(){};
	virtual ~Shape() {}
	virtual void render(int x=1) { cout << "Shape::render is called" << "   x=" << x <<endl;}
	virtual void resize() {}
	void move(const Point& p) {center = p;}
protected:
	Point center;
};

class Ellipse: public Shape {
public:
	Ellipse(float major, float minor):major_axis(major), minor_axis(minor) {}
	virtual ~Ellipse() {}
	virtual void render(int x=2) {cout << "Ellipse:: render called : " << "major_axis: " << major_axis << " minor_axis: " << minor_axis << "   x=" << x << endl;}
protected:
	float major_axis, minor_axis;
};

class Circle: public Ellipse {
public:
	Circle(float radius) : Ellipse(radius, radius), m_radius(radius) {}
	virtual ~Circle() {}
	virtual void render(int x=3){cout << "Circle:: render called : " << "radius: " << m_radius << "   x=" << x << endl;}
protected:
	float m_radius;
};


void render(Shape* p) {
    p->render(); // calls correct render function
} // for given Shape!


int main() {
    Ellipse ell(20, 10);
    ell.render(); // static -- Ellipse::render();

    Circle circ(40);
    circ.render(); // static -- Circle::render();

    render(&ell); // dynamic -- Ellipse::render(); ���﷢������up-cast
    render(&circ); // dynamic -- Circle::render(); 

    Shape &s = circ;
    s.render();
	
	Shape *s1 = &circ;
    s1->render();
	
	// Sliced
	ell = circ;
	ell.render();  // ��circ�ĳ�Աֵ����ell�뾶���Ǹı��ˣ�����û�ı�vptr����̬�������ã�����Ellipse��render
}
