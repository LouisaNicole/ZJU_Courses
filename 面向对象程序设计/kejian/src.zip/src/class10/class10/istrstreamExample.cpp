#include <strstream>
#include <iostream>

int main() {
    char cstr[100];
    std::ostrstream ostr(cstr, sizeof(cstr)); // The buffer cstr and its size are passed to the output stream
    ostr << "Hello, World!" << std::ends; // Writing to the buffer

    std::istrstream istr(cstr); // Using the same buffer for input
    char readBuffer[100];
    istr >> readBuffer; // Reading from the buffer
    // >> 会将输入流中的数据按照 空格 分隔为单词进行读取
    std::cout << readBuffer << std::endl; // Printing the read buffer

    return 0;
}
