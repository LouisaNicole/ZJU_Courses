#include <sstream>
#include <iostream>
#include <string>

int main() { 
    std::ostringstream oss; // Creates an output string stream 创建了一个输出字符串流 oss
    oss << "Hello, World!"; // Writing to the stream

    std::string str = oss.str(); // Fetches the string from the output stream

    std::istringstream iss(str); // Creates an input string stream using the string
    std::string word;
    while (iss >> word) { // Reads word by word from the input stream 
        //这里使用了输入运算符 iss >> word，它会将输入流中的数据按照 空格 分隔为单词进行读取
        std::cout << word << std::endl; // Printing each word
    }
    //str 和 iss 变量的使用是为了将数据从输出流转换为字符串，并在之后将其作为输入流以进行进一步的处理和操作。
    return 0;
}
