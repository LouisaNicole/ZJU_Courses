#include <iostream>
#include <limits>

int main() {
    const int SIZE = 3;
    char buffer[SIZE];
    int number;

    // Using get to read a line without consuming the delimiter
    std::cout << "Enter a line of text:\n";
    std::cin.get(buffer, SIZE);  //读取最多 SIZE-1 个字符，并在遇到换行符或达到最大字符数时停止
    std::cout << "Read " << std::cin.gcount()<< " characters" << std::endl;
    std::cout << "You entered: " << buffer << std::endl;

    // Using getline to read the next line and consume the delimiter
    std::cout << "Enter another line of text:\n";
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Ignore the rest of the first line
    //我们使用 std::cin.ignore() 函数来忽略之前输入的剩余字符，包括换行符。这样做是为了确保 std::cin.getline() 函数从新的一行开始读取。
    std::cin.getline(buffer, SIZE);
    std::cout << "You entered: " << buffer << std::endl;

    // Using ignore to skip characters
    std::cout << "Enter a number followed by some text:\n";
    std::cin.clear();
    std::cin >> number; // Read the number
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Ignore the rest of the line
    std::cout << "You entered the number: " << number << std::endl;
    //我们首先使用 std::cin.clear() 函数清除任何可能的输入错误标志。然后，我们使用 std::cin >> number 读取一个整数。
    //注意，如果用户输入的不是有效的整数，输入流会进入错误状态。
    //接下来，我们使用 std::cin.ignore() 函数忽略剩余的字符，包括换行符。最后，我们打印出用户输入的整数。
    //注意 输入操作符 >> 会自动跳过空白字符（如空格和换行符）
    return 0;
}
