#include <iostream>

class Date {
public:
    int day, month, year;
};

// Self-defined extractor
std::istream& operator>>(std::istream& is, Date& d) {
    char slash1, slash2; 
    is >> d.day >> slash1 >> d.month >> slash2 >> d.year;
    if (slash1 != '/' || slash2 != '/') {
        // If the input format is wrong, set the failbit
        is.setstate(std::ios::failbit);
    }
    return is;
}

int main() {
    Date myBirthday;
    std::cout << "Enter your birthday (dd/mm/yyyy): ";
    std::cin >> myBirthday;
    if (std::cin) {
        std::cout << "Day: " << myBirthday.day << ", Month: " << myBirthday.month << ", Year: " << myBirthday.year << std::endl;
    } else {
        std::cout << "Invalid date format." << std::endl;
    }


    return 0;
}
