//: C06:Constructor1.cpp
// From Thinking in C++, 2nd Edition
// Available at http://www.BruceEckel.com
// (c) Bruce Eckel 2000
// Copyright notice in Copyright.txt
// Constructors & destructors
#include <iostream>
using namespace std;

class Tree {
  int height;
public:
  Tree(int initialHeight);  // Constructor
  ~Tree();  // Destructor
  void grow(int years);
  void printsize();
};

Tree::Tree(int initialHeight) {
  cout << "inside Tree constructor" << endl;  // 2
  height = initialHeight;
}

Tree::~Tree() {
  cout << "inside Tree destructor" << endl;  // 6
  printsize();  // 7
}

void Tree::grow(int years) {
  height += years;
}

void Tree::printsize() {
  cout << "Tree height is " << height << endl;  // 4
}

int main() {
  cout << "before opening brace" << endl;  // 1
  {
    Tree t(12);
    cout << "after Tree creation" << endl;  // 3 
    t.printsize();
    t.grow(4);
    cout << "before closing brace" << endl;  // 5
  }
  cout << "after closing brace" << endl;  // 8
} ///:~
