#include <iostream>
#include <memory>
using namespace std;

class A{
	public:
		A(){
			cout << "A is created." << endl;
		}
		~A(){
			cout << "A is destroyed." << endl;
		}
		void doSomething() {
        	// Some operations...
    	}
};

void uniquePtrExample() {
	cout << " ---- In uniquePtrExample () ----" << endl;
    // using std::make_unique to create a std::unique_ptr
	// std::unique_ptr<A> myUniquePtr1(new A());
    auto myUniquePtr1 = make_unique<A>(); //Safer, need c++14 

    // using -> to visit A's function
    myUniquePtr1->doSomething();

	unique_ptr<A> myUniquePtr2;
	cout << " -- before move -- " << endl;
	cout << "myUniquePtr1 = " << myUniquePtr1.get() << endl;
	cout << "myUniquePtr2 = " << myUniquePtr2.get() << endl;

	// use std::move to transfer the ownership
	myUniquePtr2 = std::move(myUniquePtr1);  // 独占所有权的智能指针，它不允许多个指针同时拥有同一个对象的所有权

	cout << " -- after move -- " << endl;
	cout << "myUniquePtr1 = " << myUniquePtr1.get() << endl;
	cout << "myUniquePtr2 = " << myUniquePtr2.get() << endl; 


    //  When myUniquePtr goes out of scope, the instance of MyClass will be automatically destroyed
}


void sharedPtrExample() {
    cout << " ---- In sharedPtrExample ()  ----" << endl;
	// Create a std::shared_ptr using std::make_shared
    shared_ptr<A> sharedPtr1 = make_shared<A>();	

	// Print the current count number
	cout << "sharedPtr1 count : " << sharedPtr1.use_count() << endl; // 输出了 sharedPtr1 的引用计数
    {
        // Create another std::shared_ptr sharing the same MyClass instance
        shared_ptr<A> sharedPtr2 = sharedPtr1;

		cout << "sharedPtr1 count : " << sharedPtr1.use_count() << endl;
		cout << "sharedPtr2 count : " << sharedPtr2.use_count() << endl;

        // Both smart pointers are valid and can be used
        sharedPtr1->doSomething();
        sharedPtr2->doSomething();
        
        // sharedPtr2 goes out of scope and is destroyed, but the MyClass instance is not deleted
        // because sharedPtr1 still owns it
    }

	cout << "sharedPtr1 count : " << sharedPtr1.use_count() << endl;
    
    // Now sharedPtr1 goes out of scope, the MyClass instance will be automatically destroyed
}

void weakPtrExample() {
    cout << " ---- In weakPtrExample ()  ----" << endl;
	// Create a std::shared_ptr using std::make_shared
    weak_ptr<A> weakPtr;	
	cout << "weakPtr count : " << weakPtr.use_count() << endl; // 由于 std::weak_ptr 不拥有对象的所有权，所以引用计数始终为 0
    {
        // Create another std::shared_ptr sharing the same MyClass instance
        shared_ptr<A> sharedPtr = make_shared<A>();
		cout << "sharedPtr1 count : " << sharedPtr.use_count() << endl;

		weakPtr = sharedPtr;
		cout << "sharedPtr1 count : " << sharedPtr.use_count() << endl;
		cout << "weakPtr count : " << weakPtr.use_count() << endl;
		
        sharedPtr->doSomething();
        //weakPtr->doSomething(); // wrong, weakPtr cannot call doSomething since it does not own the object.
    
    }
	cout << "weakPtr count : " << weakPtr.use_count() << endl;
}


int main(){

	uniquePtrExample();

	sharedPtrExample();

	weakPtrExample();

	return 0;
}