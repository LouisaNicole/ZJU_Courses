#include <iostream>
#include <cstring>
using namespace std;

struct Person{
    char * name;
    Person(const char* s){
        name = new char[strlen(s)+1];
        strcpy(name, s);
        cout << "ctor : " << (void*)name << endl;
    }

    Person(const Person& p){
        name = new char[strlen(p.name)+1];  // 有指针char * name;所以要自己写拷贝构造
        strcpy(name, p.name);
        cout << "copy ctor : " << (void*)name << endl;
    }

    ~Person() {
        cout << "in Dtor" <<endl;
        delete [] name;
    }
};

int main(){
    Person p1("Tom");
    Person p2(p1);

    cout << (void*)p1.name <<endl;
    cout << (void*)p2.name <<endl;

}