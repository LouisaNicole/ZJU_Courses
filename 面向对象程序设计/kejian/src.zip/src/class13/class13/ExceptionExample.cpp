#include <iostream>
#include <exception>
using namespace std;

// Base class for mathematical errors
class MathErr {
public:
    // Pure virtual function to provide diagnostic information for the error
    virtual void diagnostic() const = 0;
    // Virtual destructor to ensure proper destruction of derived classes
    virtual ~MathErr() {}
};

// Derived class representing an overflow error
class OverflowErr : public MathErr {
public:
    void diagnostic() const override {
        std::cout << "Overflow error occurred." << std::endl;
    }
};

// Derived class representing an underflow error
class UnderflowErr : public MathErr {
public:
    void diagnostic() const override {
        std::cout << "Underflow error occurred." << std::endl;
    }
};

// Derived class representing a division by zero error
class ZeroDivideErr : public MathErr {
public:
    void diagnostic() const override {
        std::cout << "Attempted division by zero." << std::endl;
    }
};

int main() {
    try {
        // Code to exercise math operations
        throw UnderflowErr();  // Throwing an UnderflowErr exception
    } catch (const ZeroDivideErr& e) {
        e.diagnostic();
    } catch (const UnderflowErr& e) {
		cout << "Caught by UnderFlowErr" << endl;
        e.diagnostic();
    } catch (const MathErr& e) {
		cout << "Caught by MathErr" << endl;
        e.diagnostic();
    } catch (...) {
        std::cout << "An unknown error occurred." << std::endl;
    }
    return 0;
}
