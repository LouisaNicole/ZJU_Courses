#include <iostream>
#include <exception>
#include <memory>
using namespace std;

class A{
    private:
        int* m_vdata;
    public:
        A() : m_vdata(new int[10]()){
            cout << "A::A()" << endl;
            if (true){ // anything indicating a failure
                delete[] m_vdata;
                throw 2;
            }
        }
        ~A(){
            delete[] m_vdata;
            cout << "A::~A()" << endl;
        }
};

class Wrapper{
    private:
        int* m_vdata;
    public:
        Wrapper(int* vdata) : m_vdata(vdata){
            cout << "Wrapper()" << endl;
        }
        ~Wrapper() {
            delete[] m_vdata;
            cout << "~Wrapper()" << endl;
        }
};

// RAII（Resource Acquisition Is Initialization）
class B{
    private:
        Wrapper w; 
    public:
        B() : w(new int[10]()){
            cout << "B::B()" << endl;
            if (true){ // anything indicating a failure
                throw 2;
            }
        }
        ~B(){
            cout << "B::~B()" << endl;
        }
};

class C{
    private:
        unique_ptr<int[]> up; 
    public:
        C() : up(new int[10]()){  // up(make_unique<int[]>(10)) is better
            cout << "C::C()" << endl;
            if (true){ // anything indicating a failure
                throw 2;
            }
        }
        ~C(){
            cout << "C::~C()" << endl;
        }
};

int main()
{

    try {
        A a;
    } catch(...) {
        cout << "caught in A..." << endl;
    }

    cout << "Better way using RAII(Resource Acquisition Is Initialization)" << endl;
    try {
        B b;
    } catch(...) {
        cout << "caught in B..." << endl;
    }

    try {
        C c;
    } catch(...) {
        cout << "caught in C..." << endl;
    }
}