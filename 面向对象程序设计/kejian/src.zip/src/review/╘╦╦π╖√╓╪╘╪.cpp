//1 
// #include<iostream>
// using namespace std;
// class A{   
// public:
//     A& operator=(const A& r)
//     {
//         cout << 1 << endl;
//         return *this;
//     }
// };
// class B{   
// public:
//     B& operator=(const B& r)
//     {
//         cout << 2 << endl;
//         return *this;
//     }
// };
// class C{
// private:
//     B b;
//     A a;
//     int c;
// };

// int main()
// {
//     C m,n;
//     m = n;
//     return 0;
// }

/*
���ݳ�Ա����������˳�����Ȼ��B b���и�ֵ��
��ˣ��������B�ĸ�ֵ���������غ���B& operator=(const B& r)������� 2��
���ţ���A a���и�ֵ��������A�ĸ�ֵ���������غ���A& operator=(const A& r)������� 1��
*/


//2
#include <iostream>
using namespace std;

class counter{
private:
    int value;
public: 
    counter():value(0) {}
    counter& operator++();  
    int operator++(int);    
    void reset()
    {
        value = 0;
    }
    operator int() const  
    {
        return value;
    }    
};

counter& counter::operator++()    
{     
    if (3 == value)
          value = 0;
    else
        value += 1;
    return *this;
}

int counter::operator++(int) 
{        
    int t = value;
    if (3 == value)
         value = 0;
    else
        value += 1;
    return t;
}

int main()
{
    counter a;   
    while (++a)  
         cout << "***\n";
    cout << a << endl;
    while (a++)  
         cout << "***\n";
    cout << a << endl;
    return 0;
}



/*
#include <iostream>
#include <cstring>
using namespace std;
class ERROR{};
class STRING
{
   char *m_pStr;
   int m_len;
public:
   STRING(char *str=NULL){
      if (str != NULL) {   
         m_len = strlen(str);
         m_pStr = new char[m_len+1];
         strcpy(m_pStr, str); 
      }
      else {
         m_len = 0;
         m_pStr = NULL;
      }
   }  
   
   STRING& operator=(char *str)  {
      delete [] m_pStr ;   
      m_len = strlen(str)+1;
      m_pStr = new char[m_len]; 
      strcpy(m_pStr, str); 
      return *this;
   }

bool operator==(STRING str) const {
   return(strcmp(m_pStr, str.m_pStr)== 0);  
}

char operator [] (int i) const {
   if (i<m_len && i>=0) return m_pStr[i];
   throw ERROR();
}

char& operator[](int i)  { 
   if (i<m_len && i>=0) return m_pStr[i];
   ERROR e;
   throw e;  
   }

   friend ostream& operator<<(ostream& out ,STRING s); 
};

ostream& operator<<(ostream& out ,STRING s)     
{
   out << s.m_pStr;
   return out;  
}

int main()
{
   STRING s1,s2("HeLLO");
   int i;
   cin >> i;
   s1 = s2;
   if (s1 == s2) cout << "S1 == S2\n";
   s1[1] = s1[1] + 1;
   cout << s1 << endl;;
   try {  
      if(s1[i]>='a' && s1[i]<='z') s1[i] =  s1[i] - 32;
      cout << s1 << endl;
   } catch ( ERROR& e)  
   {
      cout << "upperbound overflow";
   }
   return 0;
}*/