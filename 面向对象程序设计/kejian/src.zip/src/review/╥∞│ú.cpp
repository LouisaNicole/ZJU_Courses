#include <iostream>
using namespace std;
class Exception{
   int i;
public:
   Exception(string name="none"):m_name(name){
      cout <<"Exception an obj's name: " << m_name << endl;   
   }
   Exception(const Exception& old){
      m_name = string("ex_") + old.m_name;
      cout <<"copy Exception an obj's name: " << m_name << endl;   
   }
   string getname() {return m_name;}
protected:
   string m_name;
};
class A
{
public:
   A(){cout <<"a()" << endl;}
   ~A(){cout <<"~a()" << endl;}
   int f(int i){
      if(i>=10){
         Exception obj1("obj1");
         throw obj1;
      }
      else return i;
   }
};

int main(){
   try{
      A a;
      a.f(10);
      A b;
      b.f(10);
   }
   catch(Exception& m){ 
      //异常对象被捕获并绑定到一个引用 m 上。由于异常对象是通过值传递抛出的，
      //而捕获异常时使用的是引用，因此会调用拷贝构造函数来创建一个新的异常对象。
      cout << "catch" << endl;
   }
   catch(...){
      cout << "no" << endl;
   }
}