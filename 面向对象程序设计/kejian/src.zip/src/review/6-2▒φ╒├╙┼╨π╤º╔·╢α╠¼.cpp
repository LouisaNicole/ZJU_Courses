#include<iostream>
#include <string>
using namespace std;

class Student{
protected:
    string num;
    string name;
    int s1, s2;
    // double average = 1.0 * (s1 + s2) / 2;
public:
    static double max;
    Student (string num, string name, int s1, int s2) : num(num), name(name), s1(s1), s2(s2) {}
    virtual void display() {
        // cout << num << " " << name << endl;
    }
};
double Student::max = 0;

class GroupA : public Student{
public:
    GroupA (string num, string name, int s1, int s2) : Student(num, name, s1, s2){
        if ((s1 + s2) > max) max = s1 + s2;
    }
    virtual void display() {
        if ((s1 + s2) == max)
            cout << num << " " << name << endl;
    }
};

class GroupB : public Student{
private:
    char gs;
public:
    GroupB (string num, string name, int s1, int s2, char gs) : Student(num, name, s1, s2), gs(gs) {
        if ((s1 + s2) > max) max = s1 + s2;
    }
    virtual void display() {
        if ((s1 + s2) == max || ((s1 + s2) >= 0.7 * max && gs == 'A'))
            cout << num << " " << name << endl;
    }
};

class GroupC : public Student{
private:
    int s3, s4, s5;
public:
    GroupC (string num, string name, int s1, int s2, int s3, int s4, int s5) : Student(num, name, s1, s2), s3(s3), s4(s4), s5(s5) {}
    virtual void display() {
        if ((s1 + s2 + s3 + s4 + s5) >= 2.5 * 0.9 * max)
            cout << num << " " << name << endl;
    }
};

int main()
{
    const int Size=50;
    string num, name;
    int i,ty,s1,s2,s3,s4,s5;
    char gs;
    Student *pS[Size];
    int count=0;
    for(i=0;i<Size;i++){
        cin>>ty;
        if(ty==0) break;
        cin>>num>>name>>s1>>s2;
        switch(ty){
             case 1:pS[count++]=new GroupA(num, name, s1, s2); break;
             case 2:cin>>gs; pS[count++]=new GroupB(num, name, s1,s2, gs); break;
             case 3:cin>>s3>>s4>>s5; pS[count++]=new GroupC(num, name, s1,s2,s3,s4,s5); break;
        }            
    }
    for(i=0;i<count;i++) {
        pS[i]->display();
        delete pS[i];
    }
    return 0;
}
