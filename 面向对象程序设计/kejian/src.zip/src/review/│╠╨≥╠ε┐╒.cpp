//1. Run the following program, the output is: B::f()
#include <iostream>
using namespace std;
class A{ 
public: 
    /*-------*/ { cout<<"A::f()\n"; } 
}; 
class B:public A{ 
public:
    void f() {cout<<"B::f()\n"; } 
}; 
int main() 
{ 
    B b;
    A &p = /*-----*/
    /*----*/ .f(); 
   return 0;
}

/*#include <iostream>
using namespace std;
class A{ 
public: 
    A() { cout<<"A::f()\n"; } 
}; 
class B:public A{ 
public:
    void f() {cout<<"B::f()\n"; } 
}; 
int main() 
{ 
    B b;
    A &p = b;
    b.f(); 
   return 0;
}*/

//2. Run the following program, Enter: 1, the output is:
//S1 == S2
//HfLLO
//HFLLO

#include <iostream>
#include <cstring>
using namespace std;
class ERROR{};
class STRING
{
   char *m_pStr;
   int m_len;
public:
   STRING(char *str=NULL){
      if (str != NULL) {   
        m_len = strlen(str);
        m_pStr = /*------*/ 
        strcpy(/*--------*/); 
      }
      else {
        m_len = 0;
        m_pStr = NULL;
      }
   }  
   
/*-----*/ operator=(char *str)  {
    m_pStr ;   
    m_len = strlen(str)+1;
    m_pStr = new char[m_len]; 
    strcpy(); 
    return /*------*/;
}
 
bool operator==(STRING str) /*----*/ {
    return(/*---*/(m_pStr, str.m_pStr)== 0);  
}

char operator [] (int i) /*---*/ {
    if (i<m_len && i>=0) return m_pStr[i];
    throw /*---*/;
}

char& operator[](int i) /*---*/ { 
    if (i<m_len && i>=0) return m_pStr[i];
    ERROR e;
    throw /*---*/;  
   }
  
    /*---*/ ostream& operator<<(ostream& out ,STRING s); 
};

ostream& operator<<(ostream& out ,STRING s)     
{
   out << s.m_pStr;
   return out;  
}

int main()
{
    STRING s1,s2("HeLLO");
    int i;
    cin >> i;
    s1 = s2;
    if (s1 == s2) cout << "S1 == S2\n";
    s1[1] = s1[1] + 1;
    cout << s1 << endl;;
    /*---*/ {  
       if(s1[i]>='a' && s1[i]<='z') s1[i] =  s1[i] - 32;
       cout << s1 << endl;
    } /*---*/ ( ERROR& e)  
    {
      cout << "upperbound overflow";
    }
   return 0;
}

//3. Run the following program, Enter: 1, the output is: 55 34 21 13 8 5 3 2 1 1
#include <iostream>
using namespace std;

enum ERROR{UnderFlow,OverFlow};
template<typename T>
class StackTemplate {
    enum { ssize = 100 };
    T stack[ssize];
    int top;
public:
    StackTemplate() : top(0) {}
    void push(const T& i) {
        if (top >= ssize) /*-----*/;
        stack[top++] = i;
    }
    T pop() {
        if (/*----*/) throw UnderFlow;
        return /*-----*/;
    }
    int size() const
    { return top; }
};
int fibonacci(int n);
int main() {
    /*---*/ {
        /*----------*/ is;
        for(int i = 0; i < 20; i++)
            is.push(fibonacci(i));
        for(int k = 0; k < 20; k++)
            cout << is.pop() << "  ";
    }
    catch( ERROR e ) {
        switch(e){
            case OverFlow:
                exit;
            case UnderFlow:
                exit;
        }
    }
    catch(...){   
        exit;
    }
    return 0;
}

int fibonacci(int n) {
    const int sz = 100;
    int i;
    static int f[sz]; 
    if (n >= sz) return /*----------*/;
    f[0] = f[1] = 1;
    for(i = 0; i < sz; i++) if(f[i] == 0) break;
    while(i <= n) {
        f[i] = f[i-1] + f[i-2];
        i++;
    }
    return /*-----*/;
}