#include <iostream>
#include<cstdlib>
using namespace std;
class A
{
public:
	virtual ~A(){}
};
class B : public A
{
};
int main()
{
   B *bp;
   B b;
   A *ap;
   A a1;
   A &a2 = b;
   try{
      ap = dynamic_cast<A *>(&b);
      if (bp)
		  cout << "Dynamic_cast  (1) OK!"<<endl;
      else
		  cout << "Dynamic_cast  (1) Fail!"<<endl;

      bp = dynamic_cast<B *>(&a1);
      if (bp)
		  cout << "Dynamic_cast  (2) OK!"<<endl;
      else
		  cout << "Dynamic_cast  (2) Fail!"<<endl;

      bp = static_cast<B *>(&a1);
      if (bp)
		  cout << "static_cast  (3) OK!"<<endl;
      else
		  cout << "static_cast  (3) Fail!"<<endl;

      bp = dynamic_cast<B *>(&a2);
      if (bp)
		  cout << "Dynamic_cast  (4) OK!"<<endl; // 因为引用的实际上是一个B类型的对象
      else
		  cout << "Dynamic_cast  (4) Fail!"<<endl;

      B &b1 = dynamic_cast<B &>(a1);
      cout << "Dynamic_cast  (5) OK!" <<endl;
   }
   catch(...){
      cout << "Dynamic_cast (5) Fail!"<<endl;
   }
   return 0;
}