#include <iostream>
#include<cmath>
using namespace std;
class Point
{
  	float x,y;
public:
   Point(float xx,float yy)
   {
      cout<<"pointctor"<<endl;
      x=xx;
      y=yy;
   }
   Point(Point &p)
   {
      x=p.x;
      y=p.y;
      cout<<"pont copyctor"<<endl;
   }
   ~Point()
   {
      cout<<"Point~dtor"<<endl;
   }
   float GetX()
   {
      return x;
   }
  float GetY()
   {
	   return y;
   }
};
class Distance
{
   Point p1,p2;
   double dist;
public:
   Distance(Point& a,Point& b); //构造函数
   Distance(Distance & d);    //copy构造函数
   ~Distance();
   double GetDis();
};
Distance::Distance(Point& a,Point& b):p1(a),p2(b)
//Distance::Distance(Point a,Point b):p1(a),p2(b)如果这样的话是值传递
//这样就需要创建临时变量Point a,Point b，这样会调用四次拷贝构造
{ 
   double x=double(p1.GetX()-p2.GetX());
   double y=double(p1.GetY()-p2.GetY());
   dist=sqrt(x*x+y*y);
   cout<<"Distancector"<<endl;
}
Distance::Distance(Distance & d):p1(d.p1 ),p2(d.p2 )
{
   cout<<"Distancecopyctor"<<endl;
   dist=d.dist ;
}
Distance::~Distance ()
{
	cout<<"Distance~dtor"<<endl;
}
double Distance::GetDis()
{
	return dist;
}
int main()
{
   Point pa(2,2),pb(5,5); //创建pa,pb
   Distance da(pa,pb); //创建da
   Distance db(da);   //创建db
   cout<<"da:(2,2)_(5,5):  "<<da.GetDis ()<<endl;
   cout<<"db:(2,2)_(5,5):  "<<db.GetDis ()<<endl;
} 