#include <iostream>
using namespace std;
template <typename T>
inline T Max(T x,T y){
   cout <<"In template function Max,";return(x-y)?x:y;
}
inline int Max(int x,int y){
   cout <<"In function Max,";return(x>y)?x:y;
}
int main(){
   cout << Max(1,2.1) << endl;
   //参数是 int 类型，所以进行的是整数比较，结果是返回较大的整数值 2
}

/*程序设计题
#include <iostream>
template <typename T>
class Matrix {
public:
    Matrix(int rows, int cols) : numRows(rows), numCols(cols) {
        data = new T*[numRows];
        for (int i = 0; i < numRows; ++i) {
            data[i] = new T[numCols];
        }
    }

    ~Matrix() {
        for (int i = 0; i < numRows; ++i) {
            delete[] data[i];
        }
        delete[] data;
    }

    friend std::ostream& operator<<(std::ostream& os, const Matrix<T>& m) {
        for (int i = 0; i < m.numRows; ++i) {
            for (int j = 0; j < m.numCols; ++j) {
                os << m.data[i][j] << " ";
            }
            os << '\n';
        }
        return os;
    }

    friend std::istream& operator>>(std::istream& is, Matrix<T>& m) {
        for (int i = 0; i < m.numRows; ++i) {
            for (int j = 0; j < m.numCols; ++j) {
                is >> m.data[i][j];
            }
        }
        return is;
    }

    Matrix<T> operator+(const Matrix<T>& other) const {
        Matrix<T> result(numRows, numCols);
        for (int i = 0; i < numRows; ++i) {
            for (int j = 0; j < numCols; ++j) {
                result.data[i][j] = data[i][j] + other.data[i][j];
            }
        }
        return result;
    }

    T& operator()(int row, int col) {
        return data[row][col];
    }

private:
    int numRows;
    int numCols;
    T** data;
};

int main() {
    // 创建两个 2x2 的矩阵
    Matrix<int> m1(2, 3);
    Matrix<int> m2(2, 3);

    // 输入矩阵元素
    std::cout << "Enter matrix 1 elements:\n";
    std::cin >> m1;

    std::cout << "Enter matrix 2 elements:\n";
    std::cin >> m2;

    // 输出矩阵
    std::cout << "Matrix 1:\n" << m1;
    std::cout << "Matrix 2:\n" << m2;

    // 进行矩阵相加
    Matrix<int> sum = m1 + m2;

    // 输出相加结果
    std::cout << "Sum of matrices:\n" << sum;

    // 访问和修改矩阵元素
    std::cout << "Element at (1, 1) in matrix 1: " << m1(1, 1) << '\n';
    m1(1, 1) = 100;
    std::cout << "Modified element at (1, 1) in matrix 1: " << m1(1, 1) << '\n';

    return 0;
}

*/