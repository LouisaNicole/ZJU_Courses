#include<iostream>
using namespace std;
class Base{
protected:
    int x;
public:
    Base(int b=0): x(b) { }
    virtual void display() const {cout << x << endl;}  //这里有const派生类没有的话不能重载
    // virtual void display() {cout << x << endl;}
};
class Derived: public Base{
    int y;
public:
    Derived(int d=0): y(d) { }
    void display() {cout << x << "," << y << endl;}
    // void display() const {cout << x << "," << y << endl;}
};
int main()
{
  Base b(1);
  Derived d(2);
  Base *p = &d;
  b.display();
  d.display();
  p->display();
  return 0;
}

/*多态
#include <iostream>
using namespace std;
class Base{
public:
   virtual int f1(char x)const {return(int)(x);}
   virtual int f2(int x) {return(2*x);}
   virtual int f3(int x) {return(3*x);}
};
class Derived :public Base{
public:
   virtual int f1(char x)const {return(int)(-x);}
   virtual int f2(double x) {return(x/2);}  // 这个double
   virtual int f3(int x) {return(x/3);}
};
void print(Base& b){
   cout <<b.f1('a') <<"\t"<<b.f2(97)<<"\t"<<b.f3(99)<<endl;
}
int main(){
   Base b;
   Derived d;
   print(b);
   print(d); //Derived 中的 f2() 函数并未覆盖基类的版本
}
*/