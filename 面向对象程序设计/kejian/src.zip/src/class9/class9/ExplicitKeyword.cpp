//: C12:ExplicitKeyword.cpp
// From Thinking in C++, 2nd Edition
// Available at http://www.BruceEckel.com
// (c) Bruce Eckel 2000
// Copyright notice in Copyright.txt
// Using the "explicit" keyword
#include <iostream>
using namespace std;

class One {
public:
  One() {}
};

class Two {
public:
  explicit Two(const One&) {}  //由于Two类的构造函数被声明为"explicit"，禁止自动类型转换
};

void f(Two) {}

int main() {
  One one;
//!  f(one); // No auto conversion allowed
  f(Two(one)); // OK -- user performs conversion
} ///:~
