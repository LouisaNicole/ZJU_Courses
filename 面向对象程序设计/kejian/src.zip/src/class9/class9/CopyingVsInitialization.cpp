//: C12:CopyingVsInitialization.cpp
// From Thinking in C++, 2nd Edition
// Available at http://www.BruceEckel.com
// (c) Bruce Eckel 2000
// Copyright notice in Copyright.txt

#include <iostream>
using namespace std;

class Fi {
public:
	Fi() {}
};

class Fee {
public:
	Fee(int) { cout << "Fee(int)" << endl; }
	Fee(const Fi&) { cout << "Fee(const Fi&)" << endl; }
	Fee(const Fee&) { cout << "Fee(const Fee&)" << endl; }
	Fee& operator=(const Fee&) { cout << "Fee=" << endl; return *this; }
};

int main() {
	Fee fee = 1; // Fee(int)
	Fee fum = fee; //Fee(Fee)
	Fi fi;
	fum = fi;
	//fum = fi这行代码将fi赋值给fum，在赋值过程中会调用Fee类的赋值运算符重载函数operator=。
	//然而，由于没有定义接受const Fi&参数的赋值运算符重载函数，
	//编译器会使用拷贝构造函数Fee(const Fi&)来构造一个临时对象，然后再调用赋值运算符重载函数。
	//因此，会输出"Fee(const Fi&)"，然后输出"Fee="
} ///:~
