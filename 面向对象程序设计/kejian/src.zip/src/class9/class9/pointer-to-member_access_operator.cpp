#include <iostream>

class MyClass {
public:
    void show() {
        std::cout << "MyClass::show() called" << std::endl;
    }
};

class Invoker {
    MyClass* object;
public:
    Invoker(MyClass* obj) : object(obj) {} //它接受一个指向 MyClass 对象的指针作为构造函数的参数。

    // overload ->* 
    auto operator->*(void (MyClass::*func)()) { //重载函数接受一个指向 MyClass 成员函数的指针（void (MyClass::*func)()）
        return [this, func] { return (object->*func)(); };
    }
};


int main() {
    MyClass obj;
    Invoker invoker(&obj);

    void (MyClass::*func)() = &MyClass::show; 
    (obj.*func)(); // direct call
    (invoker->*func)();

    return 0;
}
