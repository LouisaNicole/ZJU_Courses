#include <iostream>

class MyClass {
public:
    // User-defined conversion from double to MyClass
    MyClass(double value) {
        std::cout << "MyClass constructed from a double: " << value << std::endl;
        //使用的是整数输出格式，即默认情况下会忽略浮点数的小数部分。这是C++输出流的默认行为。
        //如果你想以浮点数形式输出，可以使用流控制符 std::fixed 和 std::setprecision 来指定输出的精度
    }

    operator int() const {
     std::cout << "MyClass int () " << std::endl;
     return 1;
   }

};

void func(int i) {
    std::cout << "func(int): " << i << std::endl;
}

void func(double d) {
    std::cout << "func(double): " << d << std::endl;
}

//void func(MyClass mc) {
//    std::cout << "func(MyClass)" << std::endl;
//}

int main() {
    int i = 5;
    double d = 5.5;
    MyClass mc(10.0); 

    func(i);
    func(d);

    func(mc); //在调用func(mc)时，编译器会尝试执行隐式的类型转换，将MyClass对象转换为int类型。
    // 输出  MyClass int ()
    //      func(int): 1

    func(10.0);

    func(static_cast<MyClass>(10.0)); // This will work because we're explicitly casting

    func('a'); 

    return 0;
}
