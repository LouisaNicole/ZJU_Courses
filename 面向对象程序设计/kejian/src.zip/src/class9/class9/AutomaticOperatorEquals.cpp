//: C12:AutomaticOperatorEquals.cpp
// From Thinking in C++, 2nd Edition
// Available at http://www.BruceEckel.com
// (c) Bruce Eckel 2000
// Copyright notice in Copyright.txt
#include <iostream>
using namespace std;

class Cargo {
public:
  Cargo& operator=(const Cargo&) {
    cout << "inside Cargo::operator=()" << endl;
    return *this;
  }
};

class Truck {
  Cargo b;
  Cargo c; // 调用自己Cargo的 operator=
};

int main() {
  Truck a, b; // 把trunk里的每一个成员进行赋值
  a = b; // a里面有两个Cargo对象所以调用两次operator=
  // b = a;
} ///:~
