//: C12:AutomaticTypeConversion.cpp
// From Thinking in C++, 2nd Edition
// Available at http://www.BruceEckel.com
// (c) Bruce Eckel 2000
// Copyright notice in Copyright.txt
// Type conversion constructor

#include <iostream>
using namespace std;

class One {
public:
	One() {}
};

class Two {
public:
	Two(const One&) {}
};

void f(Two) {}

int main() {
	One one;
	f(one); // Wants a Two, has a One
} ///:~
//函数f期望一个Two类型的参数，然而，我们将对象one（类型为One）传递给它。
//由于Two类有一个接受One类型参数的构造函数，编译器会自动执行类型转换，
//将对象one从One类型转换为Two类型，然后调用函数f。
//这种自动类型转换是通过构造函数Two(const One&)实现的。