//: C12:TypeConversionAmbiguity.cpp
// From Thinking in C++, 2nd Edition
// Available at http://www.BruceEckel.com
// (c) Bruce Eckel 2000
// Copyright notice in Copyright.txt
class Orange; // Class declaration

class Apple {
public:
  operator Orange() const; // Convert Apple to Orange
};

class Orange {
public:
  Orange(Apple); // Convert Apple to Orange
};

void f(Orange) {}

int main() {
  Apple a;
//! f(a); // Error: ambiguous conversion
//尝试调用函数f，将对象a作为参数传递给它。由于存在两个类型转换路径：
//Apple到Orange的类型转换操作符和Apple到Orange的构造函数，
//编译器无法确定应该选择哪个转换路径，因此会引发类型转换的二义性错误。
} ///:~
