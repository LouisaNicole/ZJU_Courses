#include <iostream>
// 不同T会有不同的static成员变量
template <typename T>
class MyClass {
public:
    static T sharedData;

    void setSharedData(T data) {
        sharedData = data;
    }
    
    T getSharedData() {
        return sharedData;
    }
};

// Static member definition
template <typename T>
T MyClass<T>::sharedData = T(); // 初始化

// Test the template class with static member
int main() {
    MyClass<int> intInstance;
    intInstance.setSharedData(42);  // Sets the static member for int instances.

    MyClass<double> doubleInstance;
    doubleInstance.setSharedData(3.14);  // Sets the static member for double instances.

    // Even though we change the static member using doubleInstance,
    // intInstance's static member remains unaffected.
    std::cout << "intInstance's sharedData: " << intInstance.getSharedData() << std::endl;       // Outputs 42
    std::cout << "doubleInstance's sharedData: " << doubleInstance.getSharedData() << std::endl; // Outputs 3.14

    return 0;
}
