#include <iostream>

// The CRTP base class template 用模板来实现附列调用子类
template <class T>
class Base {
public:
    void interface() {
        // Cast this pointer to derived type and call the derived implementation
        static_cast<T*>(this)->implementation();
    }

    static void static_func() {
        // Call the static method of the derived class
        T::static_sub_func();
    }
};

// Derived class that inherits from Base using CRTP
class Derived : public Base<Derived> {
public:
    void implementation() {
        std::cout << "Derived implementation called" << std::endl;
    }

    static void static_sub_func() {
        std::cout << "Derived static_sub_func called" << std::endl;
    }
};

// Main function to demonstrate usage
int main() {
    Derived d;
    d.interface();         // Should call the implementation from Derived
    Derived::static_func(); // Should call the static_sub_func from Derived

    return 0;
}
