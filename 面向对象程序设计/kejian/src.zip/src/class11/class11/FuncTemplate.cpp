#include <iostream>
using namespace std;
// 模板不允许自动的类型转换
template < class T>
void Swap( T& x, T& y ){
    T temp = x;
    x = y;
    y = temp;
	cout << "Swap(T, T)" << endl;
}


void Swap( float x, float y ){
    float temp = x;
    x = y;
    y = temp;
	cout << "Swap(float, float)" << endl;
}


int main()
{
	int i = 3; int j = 4;
	Swap(i, j);  // use explicit int swap

	double k = 4.5; double m = 3.7;
	Swap(k, m);  // instantiate double swap

	// Swap(i, k);  // Wrong if only Swap( T& x, T& y ) exist
	// 若存在void Swap( float x, float y )会进行隐式的类型转换 就不会报错

	float f1 = 0.5f; float f2 = 1.0f;
	Swap(f1, f2);

	std::string s("Hello");
	std::string t("World");
	Swap(s, t);  // instantiate std::string swap

	return 0;
}


