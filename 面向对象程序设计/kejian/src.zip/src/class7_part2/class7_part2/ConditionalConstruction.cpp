#include <iostream>

class X {
public:
    X(int i, int j) {
        std::cout << "X constructed with value " << i << ", " << j << std::endl;
    }
    ~X() {
        std::cout << "X destroyed" << std::endl;
    }
};

void f(int x) {
    if (x > 10) {
        static X my_X(x, x * 21); // X only constructed when x > 10
        // ... do something with my_X ...
    }
    // my_X is not destroyed when f exits, because it is static
}

int main() {
    f(5);  // my_X is not constructed here, because x <= 10
    f(15); // my_X is constructed here, because x > 10
    // The program exits here; my_X is destroyed if it was constructed
    f(20);   
    return 0;
}
