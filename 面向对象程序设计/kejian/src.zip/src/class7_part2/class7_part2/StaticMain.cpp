// Main program entry

void myfunc(); // Declaration for the function defined in file2.cpp

int main() {
    for(int i= 0; i< 5; i++)
        myfunc(); // Call the function defined in file2.cpp
    return 0;
}
