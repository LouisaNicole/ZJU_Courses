// C++ program to demonstrate the working of friend class

#include <iostream>
using namespace std;

// forward declaration
class ClassB;

class ClassA {
private:
    int numA;

    // friend class declaration
    // friend class ClassB;

    // friend function declaration
    friend int addAB(ClassA, ClassB);  // A B的公共友元函数 而且这个声明必须是在两个类中都声明

public:
    // constructor to initialize numA to 12
    ClassA() : numA(12) {cout << "A ctor" << endl;}
};

class ClassB {
private:
    int numB;

    // friend function declaration
    friend int addAB(ClassA, ClassB);

public:
    // constructor to initialize numB to 1
    ClassB() : numB(1) {cout << "B ctor" << endl;}

    // member function to add numA
    // from ClassA and numB from ClassB
    int add() {
       ClassA objectA;
    //    return objectA.numA + numB;
    }
};

// access members of both classes
int addAB(ClassA objectA, ClassB objectB) {
    return (objectA.numA + objectB.numB);
}

int main() {
    ClassB objectB;
    // int sum = objectB.add();
    // cout << "Sum: " << sum << endl;

    ClassA objectA;
    cout << "Sum: " << addAB(objectA, objectB) << endl;

    return 0;
}