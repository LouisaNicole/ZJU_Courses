// C++ program to demonstrate the working of friend class

#include <iostream>
using namespace std;

// forward declaration
class ClassB;

class ClassA {
private:
    int numA;

    // friend class declaration
    friend class ClassB;

public:
    // constructor to initialize numA to 12
    ClassA() : numA(12) {cout << "A ctor" << endl;}
    };

class ClassB {
private:
    int numB;
 
public:
    // constructor to initialize numB to 1
    ClassB() : numB(1) {cout << "B ctor" << endl;}

    // member function to add numA
    // from ClassA and numB from ClassB
    int add() {
        ClassA objectA;  // 不加friend就会变成一个client而不是friend，这样B就不能访问A的私有变量
        return objectA.numA + numB;  // private：对于自己和友元函数可见
    }
};


int main() {
    ClassB objectB;
    int sum = objectB.add();
    cout << "Sum: " << sum << endl;
    
    ClassA objectA;
    
    return 0;
}