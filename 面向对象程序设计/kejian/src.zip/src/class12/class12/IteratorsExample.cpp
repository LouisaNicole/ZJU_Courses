#include <iostream>
#include <iterator>
#include <list>
#include <vector>
#include <set>
#include <algorithm>
using namespace std;

int main()
{
	const int Size = 5;
	//int arr[Size] = { 1, 2, 3, 4, 5 };
	int arr[Size] = {5, 4, 3, 2, 1};

	list<int> l(arr, arr + Size);
	vector<int> v(arr, arr + Size);
	set<int> s(arr, arr + Size);  // set会自动排序

	auto itl = find(l.begin(), l.end(), 3);
	cout << *itl << " ";
	//itl+=2;  // 由于auto返回的是一个iteratior迭代器，而list迭代器是没有+2的操作只有顺序++的操作，set也不行，vector可以
	itl++;

	cout << *itl << endl;

	auto itv = find(v.begin(), v.end(), 3);
	cout << *itv << " ";
	// itv++;
	itv+=2;
	cout << *itv << endl;

	auto its = find(s.begin(), s.end(), 3);
	cout << *its << " ";
	its++;
	// its+=2;
	cout << *its << endl;
}