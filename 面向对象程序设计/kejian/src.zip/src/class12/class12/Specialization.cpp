#include <iostream>
using namespace std;

template<class T>
class A
{
	public:
	A() {cout << "template T" <<endl;}
};

template<>
class A<int>
{
	public:
	A() {cout << "template int" <<endl;}
};

template<class T>
class A<T*>
{
	public:
	A() {cout << "template *" <<endl;}
};

struct Node {};

int main()
{
	A<double> d;
	A<int> i;
	A<int*> p;

	A<Node> n;
	A<Node*> np;

	return 0;
}