
/***************************************************************
 VisualStudio 2010 �û�ע�⣺
    ��Character Set����Ϊ Use Multibyte Character Set
	����������ʾ������
***************************************************************/

#define Demo_ID 6

#if Demo_ID == 0
#include "0-emptywindow.c"

#elif Demo_ID == 1
#include "1-drawsomething.c"

#elif Demo_ID == 2
#include "2-addtimer.c"

#elif Demo_ID == 3
#include "3-usemouse.c"

#elif Demo_ID == 4
#include "4-polyline.c"

#elif Demo_ID == 5
#include "5-polygon.c"

#elif Demo_ID == 6
#include "6-addbutton.c"

#endif 
