#include<stdio.h>
#include<time.h>
#define N 80000
#define X 1.0001

double POW(double x, int n);     // Function prototype for calculating power

clock_t start, stop;             // Variables to store clock time
double duration;                 // Variable to store the duration of the calculation

int main() {
    double sum;                 // Variable to store the result of the power calculation
    int cnt = 50000000;         // Set the value of cnt as 10000000
    start = clock();            // Start the timer

    while (cnt--)
        sum = POW(X, N);        // Calculate power X^N in each iteration

    stop = clock();             // Stop the timer
    duration = ((double)(stop - start)) / CLK_TCK;   // Calculate the duration in seconds

    printf("%.2f\n", sum);      // Print the result of the power calculation
    printf("%d\n", (int)stop - (int)start);         // Print the difference between stop and start times
    printf("%.2f", duration);   // Print the duration in seconds

    return 0;
}

double POW (double x,int n){
    if (n == 1) return x;               
        //recursive exit is n==1.      
    else if (n % 2 == 1)                
        return x * POW (x*x, n/2);
        //if n is odd, x^n = [x^(n/2)]^2 * x.
    else return POW (x*x, n/2);         
        //if n is even, x^n = [x^(n/2)]^2.
}

//time complexities: O(logN)
//space complexities: O(logN)