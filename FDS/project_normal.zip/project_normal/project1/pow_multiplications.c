#include <stdio.h>
#include <time.h>

#define N 100000
#define X 1.0001

double POW(double x, int n);     // Function prototype for calculating power

clock_t start, stop;             // Variables to store clock time
double duration;                 // Variable to store the duration of the calculation

int main() {
    double sum;                 // Variable to store the result of the power calculation
    int cnt = 3000;         // Set the value of cnt as 10000000
    double start = clock();            // Start the timer

    while (cnt--)
        sum = POW(X, N);        // Calculate power X^N in each iteration

    double stop = clock();             // Stop the timer
    duration = ((double)(stop - start)) / CLK_TCK;   // Calculate the duration in seconds

    printf("%.2f\n", sum);      // Print the result of the power calculation
    printf("%.0f\n", (double)stop - (double)start);         // Print the difference between stop and start times
    printf("%.2f", duration);   // Print the duration in seconds

    return 0;
}

double POW(double x, int n) {
    double sum = x; // Initial value = x
    while (--n) { // Use N-1 multiplications
        sum = sum * x;
    }
    return sum; // Return the multiplication result
}

//time complexities: O(N)
//space complexities: O(1)