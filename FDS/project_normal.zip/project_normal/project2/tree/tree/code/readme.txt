If you are using devc++ compiler, then you can click compile to run（on the up menu）, you can see the exe file pop up. And then give your input files. The first line gives a positive integer K (≤30) which is the total number of cases. For each case, the first line gives a positive integer N (≤30), the total number of nodes in the binary tree. The second line gives the preorder traversal sequence of the tree. While all the keys in a tree are positive integers, we use negative signs to represent red nodes. All the numbers in a line are separated by a space. The sample input case is as follows:
3
9
7 -2 1 5 -4 -11 8 14 -15
9
11 -2 1 -7 5 -4 8 14 -15
8
10 -7 5 -6 8 15 -11 17
sample output:
Yes
No
No

If you are using vscode editor, click Compile Run Terminal to display the result, enter your input the same as using  devc++ compiler.

PS: Because there are more line breaks, I give the minimum test sample, the ordinary test sample and the maximum test sample. But the maximum test sample is too big (k=30 and n=30) to put a test image in the report, but you can run my code directly to check.

 