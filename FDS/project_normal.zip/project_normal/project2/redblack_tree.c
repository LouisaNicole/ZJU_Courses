#include<stdio.h>
#include<stdlib.h>

struct TreeNode{
    int element;                                        // Element value of the tree node
    struct TreeNode *left;                              // Pointer to the left child
    struct TreeNode *right;                             // Pointer to the right child
    int color;                                          // Color : 0 is black, 1 is red
};
typedef struct TreeNode *tree;

tree create(int num, int color){
    tree t = (tree)malloc(sizeof(struct TreeNode));     // Allocate memory for a new tree node
    t->element = num;                                   // Set the element
    t->left = NULL;                                     // Initialize the left child pointer
    t->right = NULL;                                    // Initialize the right child pointer
    t->color = color;                                   // Set the color
    return t;                                           // Return the created tree node
}

tree insert(tree t, int num, int color) {
    if(t == NULL) {
        return create(num, color);                      // NULL tree, so create one
    }
    
    if(num < t->element) {                              // Less than the element, go to left subtree
        t->left = insert(t->left, num, color);
    }
    else if(num > t->element) {                         // Greater than the element, go to right subtree
        t->right = insert(t->right, num, color);
    }
    
    return t;                                           // Return the modified tree
}

int isRBTree(tree t, int *black_cnt){
    if(t == NULL){
        *black_cnt = 1;                                 // Property 3 : Every leaf (NULL) is black.
        return 1;
    }

    int leftcnt, rightcnt;                              // Record the left and right subtrees' balckcnt 
    int leftflag = isRBTree(t->left, &leftcnt);         // Call the isRBTree function recursively
    int rightflag = isRBTree(t->right, &rightcnt);

    if(t->color == 1 && ((t->left != NULL && t->left->color == 1) || (t->right != NULL && t->right->color == 1))){
        return 0;                                       // Property 4 : Red node has no red children
    }

    if(leftflag && rightflag && leftcnt == rightcnt){   // Property 5 : Same number of black nodes
        if(t->color == 0) *black_cnt = leftcnt + 1;     // Update the number of black nodes
        else *black_cnt = leftcnt;                      
        return 1;
    }

    return 0;
}

int main(){
    int K, N, i, j, num;
    scanf("%d",&K);                                     // Read the number of red-black trees
    int is_rbtree[K];                                   // Record whether trees are redblack trees

    for(i=0; i<K; i++){                                 // Iterate over each red-black tree
        scanf("%d",&N);                                 // Read the number of nodes
        int *tree_order = (int*)malloc(N * sizeof(int));// Allocate memory for the nodes

        for(j=0; j<N; j++) {
            scanf("%d", &num);                          // Read the value of each node
            tree_order[j] = num;                        // Store the node value in the array
        }

        tree root = NULL;                               // Create an empty tree

        for(j=0; j<N; j++) {                            // Insert each node into the tree
            int color = 0;   
            if (tree_order[j] < 0) {
                color = 1;                              // Set the color of the node
                tree_order[j] = -tree_order[j];         // Convert the value to positive
            }
            root = insert(root, tree_order[j], color);  // Insert the node into the tree
        }

        int flag, black_cnt;                            // Store the check result of the tree
        flag = isRBTree(root, &black_cnt);              // Check if the tree is a redblack tree

        if(root != NULL && root->color == 0 && flag) is_rbtree[i] = 1; 
        else is_rbtree[i] = 0;                          // Check if root is black and the tree is redblack

        free(tree_order);                               // Free the memory
    }

    for(i=0; i<K; i++){                                 // Print the results for each tree
        if(is_rbtree[i]){
            printf("Yes\n");                            // The tree is a redblack tree
        }else{
            printf("No\n");                             // The tree is not a redblack tree
        }
    }
    system ("pause") ; 
}
