#include<stdio.h>
#include<stdlib.h>
#define MaxVertexNum 1000 /* maximum number of vertices */

typedef struct GNode {  
	int Nv;                  // Number of vertices
	int Ne;                  // Number of edges
	int G[MaxVertexNum][MaxVertexNum];   // Adjacency matrix
}*PtrToGNode;
typedef PtrToGNode RGraph;

int IsDijkstra(RGraph Graph, int path[]);   // Function to check if a path satisfies the Dijkstra's shortest path algorithm
RGraph ReadG();                             // Function to read the graph

int main() {
    int i, j, K;
    RGraph Graph = ReadG();                  // Read the graph
    scanf("%d", &K);                         // Read the number of paths to check
    int print_flag[100];                     // Array to store the flags indicating if a path satisfies Dijkstra's algorithm
    for (i = 0; i < K; i++) {
        int path[MaxVertexNum];
        for (j = 0; j < Graph->Nv; j++) {
            scanf("%d", &path[j]);           // Read the vertices of the path
        }
        print_flag[i] = IsDijkstra(Graph, path);   // Check if the path satisfies Dijkstra's algorithm
    }
    for (i = 0; i < K; i++) {
        if (print_flag[i]) {
            printf("Yes\n");                 // Print "YES" if the path satisfies Dijkstra's algorithm
        } else {
            printf("No\n");                  // Print "NO" if the path does not satisfy Dijkstra's algorithm
        }
    }
    return 0;
}


RGraph ReadG() {
    int Nv, Ne, i, j;
    scanf("%d %d", &Nv, &Ne);  // Read the number of vertices and edges
    RGraph graph = (RGraph)malloc(sizeof(struct GNode));
    graph->Nv = Nv;
    graph->Ne = Ne;

    for(i=0; i<Nv; i++) {
        for(j=0; j<Nv; j++) {
            graph->G[i][j] = 0; // Initialize the weight of edges as 0
        }
    }
    for(i=0; i<Ne; i++) {
        int v1, v2, weight;
        scanf("%d %d %d", &v1, &v2, &weight);  // Read the start and end vertices of an edge and its weight
        graph->G[v1-1][v2-1] = weight;
        graph->G[v2-1][v1-1] = weight;
    }
    return graph;
}

int IsDijkstra(RGraph Graph, int path[]){
    int i, j, source, min_weight = 100000, temp_source;
    source = path[0];
    int dist[MaxVertexNum], know[MaxVertexNum];
    for(i=0; i<Graph->Nv; i++){
        dist[i] = 0;  // Initialize the shortest path distance of all vertices as 0
        know[i] = 0;  // Initialize all vertices as not processed
    }
    // Record the shortest path for each node
    for(j=0; j<Graph->Nv; j++){    
        know[source-1] = 1;   // Mark the source node as processed
        for(i=0; i<Graph->Nv; i++){ // Process the shortest paths starting from the source node
            if(Graph->G[source-1][i]!=0 && know[i]==0){ // If there is an edge and the adjacent node is not processed, update the shortest path
                if(dist[i] == 0)    // If the shortest path is not determined yet
                    dist[i] = Graph->G[source-1][i] + dist[source-1];
                else if(Graph->G[source-1][i]+dist[source-1] < dist[i]){ // Update the shortest path
                    dist[i] = Graph->G[source-1][i] + dist[source-1];
                }
                else dist[i] = dist[i];  // The shortest path remains the same
            }
            if(min_weight>dist[i] && dist[i]>0 && know[i]==0){
                min_weight = dist[i];
                temp_source = i+1;    // Next node in the shortest path
            }
        }
        source = temp_source;
        min_weight = 100000;
    }
    // Check if the given sequence satisfies the shortest path
    for(j=1; j<Graph->Nv; j++){    
        for(i=0; i<Graph->Nv; i++){
            if(dist[i]!=0){
                if(dist[path[j]-1] > dist[i]) return 0;
            }
        }
        dist[path[j]-1] = 0;
    }
    return 1;
}