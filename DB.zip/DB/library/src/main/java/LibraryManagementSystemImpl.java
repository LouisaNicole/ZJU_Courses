import entities.Book;
import entities.Borrow;
import entities.Card;
import queries.*;
import utils.DBInitializer;
import utils.DatabaseConnector;

import java.sql.*;
import java.util.List;
import java.util.ArrayList;

public class LibraryManagementSystemImpl implements LibraryManagementSystem {

    private final DatabaseConnector connector;

    public LibraryManagementSystemImpl(DatabaseConnector connector) {
        this.connector = connector;
    }

    @Override
    public ApiResult storeBook(Book book) {
        Connection my_connect = connector.getConn();  // Get the database connection object
        try {
            my_connect.setAutoCommit(false);  // Turn off auto-commit to manage transactions manually
            my_connect.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
            PreparedStatement pre_state = null;
            String sql_exist = "SELECT * FROM book WHERE category = ? AND title = ? AND press = ? AND publish_year = ? AND author = ?\n";
            // Check if the book already exists in the library system
            pre_state = my_connect.prepareStatement(sql_exist);
            // Use PreparedStatement to execute SQL statements with parameters
            pre_state.setString(1, book.getCategory());
            pre_state.setString(2, book.getTitle());
            pre_state.setString(3, book.getPress());
            pre_state.setInt(4, book.getPublishYear());
            pre_state.setString(5, book.getAuthor());
            ResultSet res_exist = pre_state.executeQuery();
            // Execute the query and store the result in a ResultSet object
            if (res_exist.next()) {
                // If the query result contains any row, the book already exists in the library system
                throw new SQLException("The book is already in the library system.");
            } else {  // Otherwise, insert the book into the library system
                String sql_insert = "INSERT INTO book(category,title,press,publish_year,author,price,stock) VALUES(?,?,?,?,?,?,?)\n";
                pre_state = my_connect.prepareStatement(sql_insert, Statement.RETURN_GENERATED_KEYS);
                pre_state.setString(1, book.getCategory());
                pre_state.setString(2, book.getTitle());
                pre_state.setString(3, book.getPress());
                pre_state.setInt(4, book.getPublishYear());
                pre_state.setString(5, book.getAuthor());
                pre_state.setDouble(6, book.getPrice());
                pre_state.setInt(7, book.getStock());
                pre_state.executeUpdate();  // Execute the SQL statement and return the number of affected rows

                ResultSet generatedKeys = pre_state.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int generatedId = generatedKeys.getInt(1);  // Get the automatically generated ID
                    book.setBookId(generatedId);  // Update the book_id in the book object
                } else {
                    throw new SQLException("Failed to get generated book_id.");
                }
            }
            commit(my_connect);  // Commit the transaction if the insertion is successful
            return new ApiResult(true, "storeBook(Book book) success.");
        } catch (SQLException e) {
            rollback(my_connect);  // Rollback the transaction if the insertion fails
            return new ApiResult(false, e.getMessage());
        } finally {  // Restore auto-commit mode
            try {
                my_connect.setAutoCommit(true);
            } catch (SQLException e) {
                // Nothing
            }
        }
    }

    @Override
    public ApiResult incBookStock(int bookId, int deltaStock) {
        Connection my_connect = connector.getConn();  // Get the database connection object
        try {
            my_connect.setAutoCommit(false);  // Turn off auto-commit to manage transactions manually
            my_connect.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
            PreparedStatement pre_state = null;
            String sql_select = "SELECT stock FROM book WHERE book_id = ?\n";
            pre_state = my_connect.prepareStatement(sql_select);  // Execute SQL statements with parameters
            pre_state.setInt(1, bookId);  // Assign bookId to the first ? argument
            ResultSet res_exist = pre_state.executeQuery();  // Execute the query
            int currentStock = 0;
            if (res_exist.next()) {
                currentStock = res_exist.getInt("stock");
                // Retrieves the value of the "stock" column from the current row of the result set
            } else {
                throw new SQLException("Book with ID " + bookId + " not found.");
            }
            // Update stock
            int newStock = currentStock + deltaStock;
            if (newStock < 0) {
                throw new SQLException("Stock cannot be negative.");
            }
            String sql_update = "UPDATE book SET stock = ? WHERE book_id = ?\n";
            pre_state = my_connect.prepareStatement(sql_update);
            pre_state.setInt(1, newStock);  // Pass the first parameter
            pre_state.setInt(2, bookId);  // Pass the second parameter
            pre_state.executeUpdate();
            my_connect.commit();  // Commit the transaction if the insertion is successful
            return new ApiResult(true, "incBookStock(int bookId, int deltaStock) success.");
        } catch (SQLException e) {
            rollback(my_connect);
            return new ApiResult(false, e.getMessage());
        } finally {  // Restore auto-commit mode
            try {
                my_connect.setAutoCommit(true);
            } catch (SQLException e) {
                // Nothing
            }
        }
    }

    @Override
    public ApiResult storeBook(List<Book> books) {
        Connection my_connect = connector.getConn();  // Get the database connection object
        try {
            my_connect.setAutoCommit(false);  // Turn off auto-commit to manage transactions manually
            my_connect.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
            PreparedStatement pre_state = null;
            for (Book book : books) {
                String sql_exist = "SELECT * FROM book WHERE category = ? AND title = ? AND press = ? AND publish_year = ? AND author = ?\n";
                pre_state = my_connect.prepareStatement(sql_exist);
                pre_state.setString(1, book.getCategory());
                pre_state.setString(2, book.getTitle());
                pre_state.setString(3, book.getPress());
                pre_state.setInt(4, book.getPublishYear());
                pre_state.setString(5, book.getAuthor());
                ResultSet res_exist = pre_state.executeQuery();

                if (res_exist.next()) {
                    throw new SQLException("The book '" + book.getTitle() + "' already exists in the library system.");
                } else {
                    String sql_insert = "INSERT INTO book(category,title,press,publish_year,author,price,stock) VALUES(?,?,?,?,?,?,?)\n";
                    pre_state = my_connect.prepareStatement(sql_insert, Statement.RETURN_GENERATED_KEYS);
                    pre_state.setString(1, book.getCategory());
                    pre_state.setString(2, book.getTitle());
                    pre_state.setString(3, book.getPress());
                    pre_state.setInt(4, book.getPublishYear());
                    pre_state.setString(5, book.getAuthor());
                    pre_state.setDouble(6, book.getPrice());
                    pre_state.setInt(7, book.getStock());
                    pre_state.executeUpdate();

                    ResultSet generatedKeys = pre_state.getGeneratedKeys();
                    if (generatedKeys.next()) {
                        int generatedId = generatedKeys.getInt(1);
                        book.setBookId(generatedId);
                    } else {
                        throw new SQLException("Failed to get generated book_id for '" + book.getTitle() + "'.");
                    }
                }
            }
            commit(my_connect);  // Commit the transaction if all insertions are successful
            return new ApiResult(true, "storeBook(List<Book> books) success.");
        } catch (SQLException e) {
            rollback(my_connect);  // Rollback the transaction if any insertion fails
            return new ApiResult(false, e.getMessage());
        } finally {
            try {
                my_connect.setAutoCommit(true);  // Restore auto-commit mode
            } catch (SQLException e) {
                // Nothing
            }
        }
    }

    @Override
    public ApiResult removeBook(int bookId) {
        Connection my_connect = connector.getConn();  // Get the database connection object
        try {
            my_connect.setAutoCommit(false);  // Turn off auto-commit to manage transactions manually
            my_connect.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
            PreparedStatement pre_state = null;
            // Check if the book exists
            String sql_exist = "SELECT * FROM book WHERE book_id = ?\n";
            pre_state = my_connect.prepareStatement(sql_exist);
            pre_state.setInt(1, bookId);
            ResultSet res = pre_state.executeQuery();
            if (!res.next()) {  // The book doesn't exist
                throw new SQLException("The book with ID " + bookId + " doesn't exist in the library system.");
            }
            // Check if the book is currently borrowed and not returned
            String sql_check_borrowed = "SELECT * FROM borrow WHERE book_id = ? AND return_time = 0\n";
            pre_state = my_connect.prepareStatement(sql_check_borrowed);
            pre_state.setInt(1, bookId);
            ResultSet res_borrowed = pre_state.executeQuery();
            if (res_borrowed.next()) {  // If the book is still borrowed and not returned, the deletion operation fails
                throw new SQLException("The book with ID " + bookId + " is borrowed and not returned.");
            } else {  // Otherwise, delete the book from the library
                String sql_delete = "DELETE FROM book WHERE book_id = ?\n";
                pre_state = my_connect.prepareStatement(sql_delete,Statement.RETURN_GENERATED_KEYS);
                pre_state.setInt(1, bookId);
                int affectedRows = pre_state.executeUpdate();  // Return the updated rows
                if (affectedRows == 0) {
                    throw new SQLException("Failed to delete the book with ID " + bookId + ".");
                }
            }
            commit(my_connect);  // Commit the transaction if deletion is successful
            return new ApiResult(true, "removeBook(int bookId) success.");
        } catch (SQLException e) {
            rollback(my_connect);  // Rollback the transaction if deletion fails
            return new ApiResult(false, e.getMessage());
        } finally {
            try {
                my_connect.setAutoCommit(true);  // Restore auto-commit mode
            } catch (SQLException e) {
                // Nothing
            }
        }
    }

    @Override
    public ApiResult modifyBookInfo(Book book) {
        Connection my_connect = connector.getConn();  // Get the database connection object
        try {
            my_connect.setAutoCommit(false);  // Turn off auto-commit to manage transactions manually
            my_connect.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
            PreparedStatement pre_state = null;
            // Check if the book exists
            String sql_exist = "SELECT * FROM book WHERE book_id = ?\n";
            pre_state = my_connect.prepareStatement(sql_exist);
            pre_state.setInt(1, book.getBookId());
            ResultSet res = pre_state.executeQuery();
            if (!res.next()) {  // The book doesn't exist
                throw new SQLException("The book '" + book.getTitle() + "' doesn't exist in the library system.");
            }
            String sql_update = "UPDATE book SET category = ?, title = ?, press = ?, publish_year = ?, author = ?, price = ? WHERE book_id = ?\n";
            // Update the basic information of the book in the library system
            pre_state = my_connect.prepareStatement(sql_update);
            // Use PreparedStatement to execute SQL statements with parameters
            pre_state.setString(1, book.getCategory());
            pre_state.setString(2, book.getTitle());
            pre_state.setString(3, book.getPress());
            pre_state.setInt(4, book.getPublishYear());
            pre_state.setString(5, book.getAuthor());
            pre_state.setDouble(6, book.getPrice());
            pre_state.setInt(7, book.getBookId());
            pre_state.executeUpdate();
            commit(my_connect);  // Commit the transaction if deletion is successful
            return new ApiResult(true, "modifyBookInfo(Book book) success.");
        } catch (SQLException e) {
            rollback(my_connect);  // Rollback the transaction if update fails
            return new ApiResult(false, e.getMessage());
        } finally {
            try {
                my_connect.setAutoCommit(true);  // Restore auto-commit mode
            } catch (SQLException e) {
                // Nothing
            }
        }
    }

    @Override
    public ApiResult queryBook(BookQueryConditions conditions) {
        Connection my_connect = connector.getConn();
        BookQueryResults bookQuery = null;
        try {
            my_connect.setAutoCommit(false);  // Turn off auto-commit to manage transactions manually
            my_connect.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
            PreparedStatement pre_state = null;
            StringBuilder string_query = new StringBuilder("SELECT * FROM book WHERE 1=1");
            // A class that handles strings, which allows build strings dynamically
            List<Object> para_query = new ArrayList<>();  // Store query parameters
            if (conditions.getCategory() != null) {
                string_query.append(" AND category = ?");
                para_query.add(conditions.getCategory());
            }
            if (conditions.getTitle() != null) {
                string_query.append(" AND title LIKE ?");
                para_query.add("%" + conditions.getTitle() + "%");
            }
            if (conditions.getPress() != null) {
                string_query.append(" AND press LIKE ?");
                para_query.add("%" + conditions.getPress() + "%");
            }
            if (conditions.getAuthor() != null) {
                string_query.append(" AND author LIKE ?");
                para_query.add("%" + conditions.getAuthor() + "%");
            }
            if (conditions.getMinPublishYear() != null) {
                string_query.append(" AND publish_year >= ?");
                para_query.add(conditions.getMinPublishYear());
            }
            if (conditions.getMaxPublishYear() != null) {
                string_query.append(" AND publish_year <= ?");
                para_query.add(conditions.getMaxPublishYear());
            }
            if (conditions.getMinPrice() != null) {
                string_query.append(" AND price >= ?");
                para_query.add(conditions.getMinPrice());
            }
            if (conditions.getMaxPrice() != null) {
                string_query.append(" AND price <= ?");
                para_query.add(conditions.getMaxPrice());
            }
            // string_query.append(" ORDER BY category, title, press, publish_year, author, price, book_id");
            boolean flag = false;
            if (conditions.getSortBy() != null) {  // The sorted fields in the query criteria need to be sorted
                flag = true;
                string_query.append(" ORDER BY ").append(conditions.getSortBy());
            }
            if (conditions.getSortBy() != null && conditions.getSortOrder() != null) {
                string_query.append(' ').append(conditions.getSortOrder().getValue());
            }
            if(flag) {
                string_query.append(" , book_id ASC");
            } else {  // The sorting conditions of two records are the same
                string_query.append(" ORDER BY book_id ASC");
            }
//            System.out.println(connector.toString());
            // Converts the SQL query statement in string_query into a PreparedStatement object.
            pre_state = my_connect.prepareStatement(string_query.toString());
            // The setObject method sets these values in a PreparedStatement
            for (int i = 0; i < para_query.size(); i++) {
                pre_state.setObject(i + 1, para_query.get(i));
            }
            ResultSet res = pre_state.executeQuery();
            List<Book> books = new ArrayList<>();
            while (res.next()) {
                int bookId = res.getInt("book_id");
                String category = res.getString("category");
                String title = res.getString("title");
                String press = res.getString("press");
                int publishYear = res.getInt("publish_year");
                String author = res.getString("author");
                double price = res.getDouble("price");
                int stock = res.getInt("stock");
                books.add(new Book(bookId, category, title, press, publishYear, author, price, stock));
            }
            commit(my_connect);
            return new ApiResult(true, "queryBook(BookQueryConditions conditions) success", new BookQueryResults(books));
        } catch (SQLException e) {
            return new ApiResult(false, e.getMessage());
        } finally {
            try {
                my_connect.setAutoCommit(true);  // Restore auto-commit mode
            } catch (SQLException e) {
                // Nothing
            }
        }
    }


    @Override
    public ApiResult borrowBook(Borrow borrow) {
        Connection my_connect = connector.getConn();  // Get the database connection object
        try {
//            System.out.println("1111");
            PreparedStatement pre_state = null;
            // Set the transaction isolation level to Serializable for concurrent situations
            my_connect.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
            my_connect.setAutoCommit(false);  // Turn off auto-commit to manage transactions manually
            // Check if the book is already borrowed by the same user and not returned yet
            String sql_check = "SELECT * FROM borrow WHERE card_id = ? AND book_id = ? AND return_time = 0\n";
            pre_state = my_connect.prepareStatement(sql_check);
            pre_state.setInt(1, borrow.getCardId());
            pre_state.setInt(2, borrow.getBookId());
            ResultSet res_check = pre_state.executeQuery();
            if (res_check.next()) {
                return new ApiResult(false, "The user has already borrowed this book.");
            }
            sql_check = "SELECT * FROM book WHERE book_id = ?\n";
            pre_state = my_connect.prepareStatement(sql_check);
            pre_state.setInt(1, borrow.getBookId());
//            System.out.println(borrow.getBookId());
            res_check = pre_state.executeQuery();
            int stock = 0;
            if (res_check.next()) {  // If the book is found, get the inventory
                stock = res_check.getInt("stock");
            } else {  // If the book is not found, the loan operation fails
//                System.out.println("stock.");
                throw new SQLException("The book with ID '" + borrow.getBookId() + "' doesn't exist in the library system.");
            }
            if (stock <= 0) {  // If there is no stock, the borrowing operation fails
//                System.out.println("out of stock");
                throw new SQLException("The book is out of stock.");
            }
            // Insert a new borrow record
            String sql_insert = "INSERT INTO borrow (card_id,book_id,borrow_time,return_time) VALUES (?,?,?,0)";
            pre_state = my_connect.prepareStatement(sql_insert);
            pre_state.setInt(1, borrow.getCardId());
//            System.out.println(borrow.getCardId());
            pre_state.setInt(2, borrow.getBookId());
//            System.out.println(borrow.getBookId());
            pre_state.setLong(3, borrow.getBorrowTime());
//            System.out.println(borrow.getBorrowTime());
            pre_state.executeUpdate();
            // Update the book stock
            String sql_update_stock = "UPDATE book SET stock = stock - 1 WHERE book_id = ?\n";
            pre_state = my_connect.prepareStatement(sql_update_stock,Statement.RETURN_GENERATED_KEYS);
            pre_state.setInt(1, borrow.getBookId());
            int affectedRows = pre_state.executeUpdate();
            if (affectedRows == 0) {  // Rollback the transaction if the book stock update fails
                rollback(my_connect);
                throw new SQLException("Failed to update book stock.");
            }
            commit(my_connect);  // Commit the transaction if the borrow operation is successful
            return new ApiResult(true, "borrowBook(Borrow borrow) success.");
        } catch (SQLException e) {
            rollback(my_connect);  // Rollback the transaction if an exception occurs
            return new ApiResult(false, e.getMessage());
        } finally {
            try {
                my_connect.setAutoCommit(true);  // Restore auto-commit mode
            } catch (SQLException e) {
                // Nothing
            }
        }
    }

    @Override
    public ApiResult returnBook(Borrow borrow) {
        Connection my_connect = connector.getConn();  // Get the database connection object
        try {
            PreparedStatement pre_state = null;
            // Set the transaction isolation level to Serializable for concurrent situations
            my_connect.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
            my_connect.setAutoCommit(false);  // Turn off auto-commit to manage transactions manually
            // Check the loan record
            String sql_check = "SELECT * FROM borrow WHERE card_id = ? AND book_id = ? AND borrow_time = ? AND return_time = 0\n";
            pre_state = my_connect.prepareStatement(sql_check);
            pre_state.setInt(1, borrow.getCardId());
            pre_state.setInt(2, borrow.getBookId());
            pre_state.setLong(3, borrow.getBorrowTime());
            ResultSet res_check = pre_state.executeQuery();
            if (!res_check.next()) {  // Check the loan record if there is no corresponding loan record
                throw new SQLException("There is no such borrowing record or the book has been returned.");
            }
            // Update the borrow record with the return time
            String sql_update = "UPDATE borrow SET return_time = ? WHERE card_id = ? AND book_id = ? AND borrow_time = ? AND return_time = 0";
            pre_state = my_connect.prepareStatement(sql_update,Statement.RETURN_GENERATED_KEYS);
            pre_state.setLong(1, borrow.getReturnTime());
            pre_state.setInt(2, borrow.getCardId());
            pre_state.setInt(3, borrow.getBookId());
            pre_state.setLong(4, borrow.getBorrowTime());
            int affectedRows = pre_state.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("The borrow record does not exist or the book has already been returned.");
            }
            if (borrow.getReturnTime() < borrow.getBorrowTime()) {
                throw new SQLException("The borrow ReturnTime < BorrowTime.");
            }
            // Update the book stock
            sql_update = "UPDATE book SET stock = stock + 1 WHERE book_id = ?";
            pre_state = my_connect.prepareStatement(sql_update);
            pre_state.setInt(1, borrow.getBookId());
            pre_state.executeUpdate();
            commit(my_connect);  // Commit the transaction if the return operation is successful
            return new ApiResult(true, "returnBook(Borrow borrow) success.");
        } catch (SQLException e) {
            rollback(my_connect);  // Rollback the transaction if an exception occurs
            return new ApiResult(false, e.getMessage());
        } finally {
            try {
                my_connect.setAutoCommit(true);  // Restore auto-commit mode
            } catch (SQLException e) {
                // Nothing
            }
        }
    }

    @Override
    public ApiResult showBorrowHistory(int cardId) {
        Connection my_connect = connector.getConn();
        BorrowHistories borrowHistories = null;
        try {
            PreparedStatement pre_state = null;
            my_connect.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
            my_connect.setAutoCommit(false);  // Turn off auto-commit to manage transactions manually
            String sql = "SELECT * FROM borrow WHERE card_id = ? ORDER BY borrow_time DESC, book_id ASC";
            pre_state = my_connect.prepareStatement(sql);
            pre_state.setInt(1, cardId);
            ResultSet res_check = pre_state.executeQuery();

            List<BorrowHistories.Item> items = new ArrayList<BorrowHistories.Item>();
            while (res_check.next()) {  // Get loan information from the query result
                int bookId = res_check.getInt("book_id");
                long borrowTime = res_check.getLong("borrow_time");
                long returnTime = res_check.getLong("return_time");
                String sql_update = "SELECT * FROM book WHERE book_id = ?\n";
                pre_state = my_connect.prepareStatement(sql_update);
                pre_state.setInt(1, bookId);
                ResultSet resultSet = pre_state.executeQuery();
                if (resultSet.next()) {
                    String category = resultSet.getString("category");
                    String title = resultSet.getString("title");
                    String press = resultSet.getString("press");
                    int publishYear = resultSet.getInt("publish_year");
                    String author = resultSet.getString("author");
                    double price = resultSet.getDouble("price");
                    BorrowHistories.Item item = new BorrowHistories.Item();
                    item.setCardId(cardId);
                    item.setBookId(bookId);
                    item.setCategory(category);
                    item.setTitle(title);
                    item.setPress(press);
                    item.setPublishYear(publishYear);
                    item.setAuthor(author);
                    item.setPrice(price);
                    item.setBorrowTime(borrowTime);
                    item.setReturnTime(returnTime);
                    items.add(item);
                }
            }
            borrowHistories = new BorrowHistories(items);
            commit(my_connect);
            return new ApiResult(true, "showBorrowHistory(int cardId) success.", borrowHistories);
        } catch (SQLException e) {
            rollback(my_connect);  // Rollback the transaction if an exception occurs
            return new ApiResult(false, e.getMessage());
        } finally {
            try {
                my_connect.setAutoCommit(true);  // Restore auto-commit mode
            } catch (SQLException e) {
                // Nothing
            }
        }
    }

    @Override
    public ApiResult registerCard(Card card) {
        Connection my_connect = connector.getConn();
        try {
            PreparedStatement pre_state = null;
            my_connect.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
            my_connect.setAutoCommit(false);  // Turn off auto-commit to manage transactions manually
            // Check if the card already exists
            String sql_check = "SELECT * FROM card WHERE name = ? AND department = ? AND type = ?\n";
            pre_state = my_connect.prepareStatement(sql_check);
            pre_state.setString(1, card.getName());
            pre_state.setString(2, card.getDepartment());
            pre_state.setString(3, card.getType().getStr());
            ResultSet resultSet = pre_state.executeQuery();
            if (resultSet.next()) {
                throw new SQLException("The card already exists.");
            }
            // Insert the new card into the database
            String sql_insert = "INSERT INTO card (name, department, type) VALUES (?, ?, ?)";
            pre_state = my_connect.prepareStatement(sql_insert,Statement.RETURN_GENERATED_KEYS);
            pre_state.setString(1, card.getName());
            pre_state.setString(2, card.getDepartment());
            pre_state.setString(3, card.getType().getStr());
            int affectedRows = pre_state.executeUpdate();
            if (affectedRows > 0) {
                ResultSet keys = pre_state.getGeneratedKeys();
                keys.next();
                int id = keys.getInt(1);
                card.setCardId(id);
                commit(my_connect);
                return new ApiResult(true, "registerCard(Card card) success." + id);
            } else {
                rollback(my_connect);  // Rollback the transaction if an exception occurs
                throw new SQLException("Register a card fails.");
            }

        } catch (SQLException e) {
            rollback(my_connect);  // Rollback the transaction if an exception occurs
            return new ApiResult(false, e.getMessage());
        } finally {
            try {
                my_connect.setAutoCommit(true);  // Restore auto-commit mode
            } catch (SQLException e) {
                // Nothing
            }
        }
    }

    @Override
    public ApiResult removeCard(int cardId) {
        Connection my_connect = connector.getConn();
        try {
            PreparedStatement pre_state = null;
            my_connect.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
            my_connect.setAutoCommit(false);  // Turn off auto-commit to manage transactions manually
            // Check if the card has books not returned
            String sql_check = "SELECT * FROM card WHERE card_id = ?\n";
            pre_state = my_connect.prepareStatement(sql_check);
            pre_state.setInt(1, cardId);
            ResultSet res = pre_state.executeQuery();
            if (!res.next()) {  // An error is reported if the library card does not exist
                throw new SQLException("The card doesn't exist.");
            }
            // Check if the library card has any unreturned books
            sql_check = "SELECT * FROM borrow WHERE card_id = ? AND return_time = 0\n";
            pre_state = my_connect.prepareStatement(sql_check);
            pre_state.setInt(1, cardId);
            res = pre_state.executeQuery();
            if (res.next()) {  // If the library card has books that have not yet been returned
                throw new SQLException("There is some book that hasn't been returned.");
            }
            String sql_delete = "DELETE FROM card WHERE card_id = ?\n";
            pre_state = my_connect.prepareStatement(sql_delete);
            pre_state.setInt(1, cardId);
            pre_state.executeUpdate();
            commit(my_connect);
            return new ApiResult(true, "removeCard(int cardId) success.");
        } catch (SQLException e) {
            rollback(my_connect);  // Rollback the transaction if an exception occurs
            return new ApiResult(false, e.getMessage());
        } finally {
            try {
                my_connect.setAutoCommit(true);  // Restore auto-commit mode
            } catch (SQLException e) {
                // Nothing
            }
        }
    }

    public ApiResult modifyCardInfo(Card card) {
        Connection my_connect = connector.getConn();  // Get the database connection object
        try {
            my_connect.setAutoCommit(false);  // Turn off auto-commit to manage transactions manually
            my_connect.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
            PreparedStatement pre_state = null;
            // Check if the card exists
            String sql_exist = "SELECT * FROM card WHERE card_id = ?\n";
            pre_state = my_connect.prepareStatement(sql_exist);
            pre_state.setInt(1, card.getCardId());
            ResultSet res = pre_state.executeQuery();
            if (!res.next()) {  // The book doesn't exist
                throw new SQLException("The card with ID: '" + card.getCardId() + "' doesn't exist in the library system.");
            }
            String sql_update = "UPDATE card SET name = ?, department = ?, type = ? WHERE card_id = ?\n";
            // Update the basic information of the book in the library system
            pre_state = my_connect.prepareStatement(sql_update);
            // Use PreparedStatement to execute SQL statements with parameters
            pre_state.setString(1, card.getName());
            pre_state.setString(2, card.getDepartment());
            if (card.getType().getStr() == "T") {
                pre_state.setString(3, "T");
            } else {
                pre_state.setString(3, "S");
            }
            pre_state.setInt(4, card.getCardId());
            pre_state.executeUpdate();
            commit(my_connect);  // Commit the transaction if deletion is successful
            return new ApiResult(true, "modifyCardInfo(Card card) success.");
        } catch (SQLException e) {
            rollback(my_connect);  // Rollback the transaction if update fails
            return new ApiResult(false, e.getMessage());
        } finally {
            try {
                my_connect.setAutoCommit(true);  // Restore auto-commit mode
            } catch (SQLException e) {
                // Nothing
            }
        }
    }

    @Override
    public ApiResult showCards() {
        Connection my_connect = connector.getConn();
        CardList cardList = null;
        try {
            PreparedStatement pre_state = null;
            my_connect.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
            my_connect.setAutoCommit(false);  // Turn off auto-commit to manage transactions manually
            // Check if the card has books not returned
            String sql_check = "SELECT * FROM card ORDER BY card_id\n";
            pre_state = my_connect.prepareStatement(sql_check);
            ResultSet res_check = pre_state.executeQuery();

            List<Card> cards = new ArrayList<>();
            while (res_check.next()) {  // Get loan information from the query result
                int cardId = res_check.getInt("card_id");
                String name = res_check.getString("name");
                String department = res_check.getString("department");
                String type = res_check.getString("type");
                cards.add(new Card(cardId, name, department, Card.CardType.values(type)));
            }
            cardList = new CardList(cards);
            commit(my_connect);
            return new ApiResult(true, "showCards() success.", cardList);
        } catch (SQLException e) {
            rollback(my_connect);  // Rollback the transaction if an exception occurs
            return new ApiResult(false, e.getMessage());
        } finally {
            try {
                my_connect.setAutoCommit(true);  // Restore auto-commit mode
            } catch (SQLException e) {
                // Nothing
            }
        }
    }

    @Override
    public ApiResult resetDatabase() {
        Connection conn = connector.getConn();
        try {
            Statement stmt = conn.createStatement();
            DBInitializer initializer = connector.getConf().getType().getDbInitializer();
            stmt.addBatch(initializer.sqlDropBorrow());
            stmt.addBatch(initializer.sqlDropBook());
            stmt.addBatch(initializer.sqlDropCard());
            stmt.addBatch(initializer.sqlCreateCard());
            stmt.addBatch(initializer.sqlCreateBook());
            stmt.addBatch(initializer.sqlCreateBorrow());
            stmt.executeBatch();
            commit(conn);
        } catch (Exception e) {
            rollback(conn);
            return new ApiResult(false, e.getMessage());
        }
        return new ApiResult(true, null);
    }

    private void rollback(Connection conn) {
        try {
            conn.rollback();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void commit(Connection conn) {
        try {
            conn.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static final Object inventoryLock = new Object();
}