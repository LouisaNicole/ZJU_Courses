//import com.alibaba.fastjson.JS0N0bject;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sun.net.httpserver.*;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import entities.Book;
import entities.Borrow;
import entities.Card;
import lombok.SneakyThrows;
import queries.*;
import utils.*;
import java.io.*;
import java.net.InetSocketAddress;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    private static final Logger log = Logger.getLogger(Main.class.getName());

    public static void main(String[] args) throws IOException {
        try {
            // parse connection config from "resources/application.yaml"
            ConnectConfig conf = new ConnectConfig();
            log.info("Success to parse connect config. " + conf.toString());
            // connect to database
            DatabaseConnector connector = new DatabaseConnector(conf);
            boolean connStatus = connector.connect();
            if (!connStatus) {
                log.severe("Failed to connect database.");
                System.exit(1);
            }
            /* do somethings */
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                if (connector.release()) {
                    log.info("Success to release connection.");
                } else {
                    log.warning("Failed to release connection.");
                }
            }));

            // 创建HTTP服务器，监听指定端口
            // 这里是8000，建议不要80端口，容易和其他的撞
            HttpServer server = HttpServer.create(new InetSocketAddress(8000), 0);
            // 添加handler，这里就绑定到/card路由
            // 所以localhost:8000/card是会有handler来处理
            LibraryManagementSystemImpl library_system = new LibraryManagementSystemImpl(connector);
//            MyLibrary my = MyLibrary.createLibrary(library_system, 100, 50, 30);
            // 启动服务器
            server.createContext("/card", new CardHandler(library_system));
            server.createContext("/borrow", new BorrowHandler(library_system));
            server.createContext("/book", new BookHandler(library_system));
            server.start();
            // 标识一下，这样才知道我的后端启动了（确信
            System.out.println("Server is listening on port 8000");

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    static class CardHandler implements HttpHandler {
        private final LibraryManagementSystem library_system;

        public CardHandler(LibraryManagementSystem library_system) {
            this.library_system = library_system;
        }
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            // 允许所有域的请求，cors处理
            Headers headers = exchange.getResponseHeaders();
            headers.add("Access-Control-Allow-Origin", "*");
            headers.add("Access-Control-Allow-Methods", "GET, POST");
            headers.add("Access-Control-Allow-Headers", "Content-Type");
            // 解析请求的方法，看GET还是POST
            String requestMethod = exchange.getRequestMethod();
            // 注意判断要用equals方法而不是==啊，java的小坑（
            if (requestMethod.equals("GET")) {
                // 处理GET
                handleGetRequest(exchange);
            } else if (requestMethod.equals("POST")) {
                // 处理POST
                handlePostRequest(exchange);
            } else if (requestMethod.equals("OPTIONS")) {
                // 处理OPTIONS
                handleOptionsRequest(exchange);
            } else {
                // 其他请求返回405 Method Not Allowed
                exchange.sendResponseHeaders(405, -1);
            }
        }

        public void handleGetRequest(HttpExchange exchange) throws IOException {
            try {
                // 响应头，因为是JSON通信
                exchange.getResponseHeaders().set("Content-Type", "application/json");
                // 状态码为200，也就是status ok
                exchange.sendResponseHeaders(200, 0);
                // 获取输出流，java用流对象来进行io操作
                OutputStream outputStream = exchange.getResponseBody();
                // 构建JSON响应数据，这里简化为字符串

                //            // 这里写的一个固定的JSON，实际可以查表获取数据，然后再拼出想要的JSON
                //            String response = "[{\"id\": 1, \"name\": \"John Smith\", \"department\": \"Computer Science\", \"type\": \"Student\"}," +
                //                    "{\"id\": 2, \"name\": \"Jane Smith\", \"department\": \"Electrical Engineering\", \"type\": \"Faculty\"}]";

                ApiResult result = library_system.showCards();
                CardList cards = (CardList) result.payload;
                // 将借书证列表转换为JSON字符串
                String response = convertCardListToJson(cards);

                // 写
                outputStream.write(response.getBytes());
                // 流一定要close！！！小心泄漏
                outputStream.close();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public void handlePostRequest(HttpExchange exchange) throws IOException {
            try {
                // 读取POST请求体
                InputStream requestBody = exchange.getRequestBody();
                // 用这个请求体（输入流）构造个buffered reader
                BufferedReader reader = new BufferedReader(new InputStreamReader(requestBody));
                // 拼字符串的
                StringBuilder requestBodyBuilder = new StringBuilder();
                // 用来读的
                String line;
                // 没读完，一直读，拼到string builder里
                while ((line = reader.readLine()) != null) {
                    requestBodyBuilder.append(line);
                }
//                System.out.println(requestBodyBuilder);
//                Card card = JsonToCard(requestBodyBuilder.toString());
//                System.out.println(card);
                OutputStream outputStream = exchange.getResponseBody();
                String response = null;

                if (requestBodyBuilder.toString().matches((".*\"id\":.*"))) {
                    // 有id,删除或修改
                    if (requestBodyBuilder.toString().matches((".*\"name\":.*"))) {
                        // 有name,修改
                        Card card = JsonToCard(requestBodyBuilder.toString(),OperationType.UPDATE);
//                        System.out.println(card);
                        ApiResult result = library_system.modifyCardInfo(card);
//                        System.out.println(card);
                        if (result.ok) {
                            response = "Modify card successfully";
                        } else {
                            response = "Modify card failed";
                        }
                    } else {
                        Card card = JsonToCard(requestBodyBuilder.toString(),OperationType.DELETE);
//                        System.out.println(card);
//                        System.out.println(card.fromJSON(requestBodyBuilder.toString()).getCardId());
                        ApiResult result = library_system.removeCard(card.getCardId());
                        if (result.ok) {
                            response = "Remove card successfully";
                        } else {
                            response = "Remove card failed";
                        }
                    }
                } else {
                    // 没有id，一定是添加
                    Card card = JsonToCard(requestBodyBuilder.toString(),OperationType.CREATE);
//                    System.out.println(card);
                    ApiResult result = library_system.registerCard(card);
                    if (result.ok) {
                        response = "Register card successfully";
                    } else {
                        response = "Register card failed";
                    }
                }

                // 响应头
                exchange.getResponseHeaders().set("Content-Type", "application/json");
                // 响应状态码200
                exchange.sendResponseHeaders(200, response.getBytes().length);
                // 写入响应体
                outputStream.write(response.getBytes());
                outputStream.close();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public void handleOptionsRequest(HttpExchange exchange) throws IOException {
            // 处理OPTIONS请求的逻辑
            exchange.sendResponseHeaders(200, -1);
        }
    }

    public static String convertCardListToJson(CardList cards) {
        JSONArray jsonArray = new JSONArray();
        List<Card> cardList = cards.getCards();  // 获取 CardList 中的 List<Card> 对象
        for (Card card : cardList) {  // 使用 cardList 进行遍历
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("id", card.getCardId());
            jsonObject.put("name", card.getName());
            jsonObject.put("department", card.getDepartment());
            jsonObject.put("type", card.getType().toString());
            jsonArray.add(jsonObject);
        }
        return jsonArray.toJSONString();
    }

    public static Card JsonToCard(String string, OperationType operationType) {
        try {
            if (string.startsWith("{") && string.endsWith("}")) {
                string = string.substring(1, string.length() - 1);
            }
            String[] keyValuePairs = string.split(",");
            int expectedLength = (operationType == OperationType.DELETE) ? 1 : 3;
            if (keyValuePairs.length < expectedLength || keyValuePairs.length > 4) {
                // Handle the case when the string does not have the expected number of key-value pairs
                return null; // Or throw an exception, display an error message, etc.
            }

            int id = -1; // Default value for id
            String name = null;
            String department = null;
            Card.CardType type = null;

            for (String keyValuePair : keyValuePairs) {
                String[] parts = keyValuePair.split(":");
                if (parts.length != 2) {
                    return null;
                }
                String key = parts[0].trim();
                String value = parts[1].trim();

                if (key.equals("\"id\"")) {
                    id = Integer.parseInt(removeQuotes(value));
                } else if (key.equals("\"name\"")) {
                    name = removeQuotes(value);
                } else if (key.equals("\"department\"")) {
                    department = removeQuotes(value);
                } else if (key.equals("\"type\"")) {
                    String typeStr = removeQuotes(value);
                    if (typeStr.equals("学生") || typeStr.equals("Student")) {
                        type = Card.CardType.Student;
                    } else if (typeStr.equals("教师") || typeStr.equals("Teacher")) {
                        type = Card.CardType.Teacher;
                    }
                }
            }

            if (operationType == OperationType.DELETE) {
                // Only ID is required for delete operation
                if (id == -1) {
                    return null;
                }
                return new Card(id);
            } else if (operationType == OperationType.UPDATE) {
                // ID is required for update operation
                if (id == -1) {
                    return null;
                }
                // Create a new card object with updated values
                Card card = new Card(id);
                if (name != null) {
                    card.setName(name);
                }
                if (department != null) {
                    card.setDepartment(department);
                }
                if (type != null) {
                    card.setType(type);
                }
                return card;
            } else if (operationType == OperationType.CREATE) {
                // Name, department, and type are required for create operation
                if (name == null || department == null || type == null) {
                    return null;
                }
                return new Card(name, department, type);
            }
        } catch (Exception e) {
            return null;
        }
        return null;
    }

    enum OperationType {
        CREATE,
        UPDATE,
        DELETE
    }

    public static String removeQuotes(String value) {
        if (value.startsWith("\"") && value.endsWith("\"")) {
            return value.substring(1, value.length() - 1);
        }
        return value;
    }


    static class BorrowHandler implements HttpHandler {
        private final LibraryManagementSystem library_system;

        public BorrowHandler(LibraryManagementSystem library_system) {
            this.library_system = library_system;
        }
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            // 允许所有域的请求，cors处理
            Headers headers = exchange.getResponseHeaders();
            headers.add("Access-Control-Allow-Origin", "*");
            headers.add("Access-Control-Allow-Methods", "GET, POST");
            headers.add("Access-Control-Allow-Headers", "Content-Type");
            // 解析请求的方法，看GET还是POST
            String requestMethod = exchange.getRequestMethod();
            // 注意判断要用equals方法而不是==啊，java的小坑（
            if (requestMethod.equals("GET")) {
                // 处理GET
                handleGetRequest(exchange);
            } else if (requestMethod.equals("POST")) {
                // 处理POST
                handlePostRequest(exchange);
            } else if (requestMethod.equals("OPTIONS")) {
                // 处理OPTIONS
                handleOptionsRequest(exchange);
            } else {
                // 其他请求返回405 Method Not Allowed
                exchange.sendResponseHeaders(405, -1);
            }
        }

        private void handleGetRequest(HttpExchange exchange) throws IOException {
            try {
                String query = exchange.getRequestURI().getQuery();
                // 获取查询字符串
//                System.out.println(query);
                Map<String, String> query_para = QueryToMap(query);
                // 键值对映查询字符串射
                String IDStr = query_para.get("cardID");
                ApiResult result = library_system.showBorrowHistory(Integer.parseInt(IDStr));
                // 查询借书记录
                exchange.getResponseHeaders().set("Content-Type", "application/json");
                BorrowHistories borrowhistories = (BorrowHistories) result.payload;
                // 获取借书历史记录
                String response = borrowhistories.toJSON();
//                System.out.println(response);
                // 转换为 JSON 格式的字符串
                exchange.sendResponseHeaders(200, 0);
                OutputStream outputStream = exchange.getResponseBody();
                // 获取响应体的输出流
                outputStream.write(response.getBytes());
                // 将响应字符串写入响应体
                outputStream.close();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private void handlePostRequest(HttpExchange exchange) throws IOException {
            try {
                // 读取POST请求体
                InputStream requestBody = exchange.getRequestBody();
                // 用这个请求体（输入流）构造个buffered reader
                BufferedReader reader = new BufferedReader(new InputStreamReader(requestBody));
                // 拼字符串的
                StringBuilder requestBodyBuilder = new StringBuilder();
                // 用来读的
                String line;
                // 没读完，一直读，拼到string builder里
                while ((line = reader.readLine()) != null) {
                    requestBodyBuilder.append(line);
                }
                OutputStream outputStream = exchange.getResponseBody();
                String response = null;

                // 响应头
                exchange.getResponseHeaders().set("Content-Type", "application/json");
                // 响应状态码200
                exchange.sendResponseHeaders(200, 0);

                String jsonString = requestBodyBuilder.toString();
//                System.out.println(jsonString);
                Borrow borrow = parseBorrowFromJson(jsonString);
//                System.out.println(borrow);
                if(Integer.parseInt(BorrowextractValue(jsonString, "return_time")) == 0){
                    // borrow
//                    System.out.println(extractValue(jsonString, "return_time"));
                    ApiResult result = library_system.borrowBook(borrow);
//                    System.out.println(borrow);
                    if(result.ok) {
//                        System.out.println(res);
                        outputStream.write("Borrow book successfully".getBytes());
                    }else {
                        outputStream.write("Borrow book failed".getBytes());
                    }
                }else {
                    // return
//                    System.out.println(extractValue(jsonString, "return_time"));
                    ApiResult result = library_system.returnBook(borrow);
                    if(result.ok) {
                        outputStream.write("Return book successfully".getBytes());
                    }else {
                        outputStream.write("Return book failed".getBytes());
                    }
                }

                outputStream.close();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private void handleOptionsRequest(HttpExchange exchange) throws IOException {
            // 处理OPTIONS请求的逻辑
            exchange.sendResponseHeaders(200, -1);
        }
    }

    public static Map<String, String> QueryToMap(String query) {
        Map<String, String> queryParams = new HashMap<>();
        if (query != null && !query.isEmpty()) {
            String[] query_para = query.split("&");
            for (String param : query_para) {
                String[] keyValue = param.split("=");
                if (keyValue.length == 2) {
                    String key = keyValue[0];
                    String value = keyValue[1];
                    queryParams.put(key, value);
                }
            }
        }
        return queryParams;
    }

    public static Borrow parseBorrowFromJson(String jsonString) {
        String cardIdStr = BorrowextractValue(jsonString, "card_id");
        String bookIdStr = BorrowextractValue(jsonString, "book_id");
        String borrowTimeStr = BorrowextractValue(jsonString, "borrow_time");
        String returnTimeStr = BorrowextractValue(jsonString, "return_time");

        Borrow borrow = new Borrow();
        borrow.setCardId(Integer.parseInt(cardIdStr));
        borrow.setBookId(Integer.parseInt(bookIdStr));
        borrow.setBorrowTime(Long.parseLong(borrowTimeStr));
        borrow.setReturnTime(Long.parseLong(returnTimeStr));

        return borrow;
    }

    public static String BorrowextractValue(String jsonString, String key) {
        String keyPattern = "\"" + key + "\":";
        int keyIndex = jsonString.indexOf(keyPattern) + keyPattern.length();
        int commaIndex = jsonString.indexOf(",", keyIndex);
        if (commaIndex == -1) {
            // 最后一个键值对，没有逗号
            commaIndex = jsonString.indexOf("}", keyIndex);
        }
        return jsonString.substring(keyIndex, commaIndex).replaceAll("[^\\d.]", "");
    }

    static class BookHandler implements HttpHandler {
        private final LibraryManagementSystem library_system;

        public BookHandler(LibraryManagementSystem library_system) {
            this.library_system = library_system;
        }
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            // 允许所有域的请求，cors处理
            Headers headers = exchange.getResponseHeaders();
            headers.add("Access-Control-Allow-Origin", "*");
            headers.add("Access-Control-Allow-Methods", "GET, POST");
            headers.add("Access-Control-Allow-Headers", "Content-Type");
            // 解析请求的方法，看GET还是POST
            String requestMethod = exchange.getRequestMethod();
            // 注意判断要用equals方法而不是==啊，java的小坑（
            if (requestMethod.equals("GET")) {
                // 处理GET
                handleGetRequest(exchange);
            } else if (requestMethod.equals("POST")) {
                // 处理POST
                handlePostRequest(exchange);
            } else if (requestMethod.equals("OPTIONS")) {
                // 处理OPTIONS
                handleOptionsRequest(exchange);
            } else {
                // 其他请求返回405 Method Not Allowed
                exchange.sendResponseHeaders(405, -1);
            }
        }

        public void handleGetRequest(HttpExchange exchange) throws IOException {
            try {
                // 响应头，因为是JSON通信
                exchange.getResponseHeaders().set("Content-Type", "application/json");
                // 状态码为200，也就是status ok
                exchange.sendResponseHeaders(200, 0);
                // 获取输出流，java用流对象来进行io操作
                OutputStream outputStream = exchange.getResponseBody();
                String response = "[{\"id\": 0,\"category\": \" \",\"title\": \" \",\"press\": \" \",\"publish_year\": 0,\"author\": \" \",\"price\": 0,\"stock\": 0}]";
//                System.out.println(111);
                // 写
                outputStream.write(response.getBytes());
                // 流一定要close！！！小心泄漏
                outputStream.close();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public void handlePostRequest(HttpExchange exchange) throws IOException {
            try {
                // 读取POST请求体
                InputStream requestBody = exchange.getRequestBody();
                // 用这个请求体（输入流）构造个buffered reader
                BufferedReader reader = new BufferedReader(new InputStreamReader(requestBody));
                // 拼字符串的
                StringBuilder requestBodyBuilder = new StringBuilder();
                // 用来读的
                String line;
                // 没读完，一直读，拼到string builder里
                while ((line = reader.readLine()) != null) {
                    requestBodyBuilder.append(line);
                }
                OutputStream outputStream = exchange.getResponseBody();
                String response = null;
                // 响应头
                exchange.getResponseHeaders().set("Content-Type", "application/json");
                // 响应状态码200
                exchange.sendResponseHeaders(200, 0);
                // 写入响应体

//                System.out.println("Received POST request to create book with data: " + requestBodyBuilder.toString());
                if(requestBodyBuilder.toString().matches((".*\"minPublishYear\".*"))){
                    String jsonString = requestBodyBuilder.toString();
                    BookQueryConditions conditions = parseConditionFromJSON(jsonString);
                    ApiResult result = library_system.queryBook(conditions);
                    BookQueryResults queryResults = (BookQueryResults)result.payload;
                    String res_query = parseQueryToJSON(queryResults);
//                    String response = "{\"data\":" + queryResults.toJSON() + "}";
                    outputStream.write(res_query.getBytes());
                }
                else if(requestBodyBuilder.toString().matches((".*\"snippets\":.*"))){
                    String jsonString = requestBodyBuilder.toString();
                    List<Book> books = extractBooksFromRequest(jsonString);
                    ApiResult result = library_system.storeBook(books);
                    if(result.ok) {
                        outputStream.write("Store books successfully".getBytes());
                    }else {
                        outputStream.write("Store books failed".getBytes());
                    }

                }
                else if(requestBodyBuilder.toString().matches((".*\"delta\":.*"))){  // 增加库存对应的信息是出现 delta
                    String jsonString = requestBodyBuilder.toString();
                    String BookIdStr = jsonString.substring(jsonString.indexOf("id") + 5, jsonString.indexOf("\",", jsonString.indexOf("id")));
                    //  加上 5 相当于跳过 "id" 和冒号，指向 "id" 后面的引号
                    String deltaStr = jsonString.substring(jsonString.indexOf("delta") + 8, jsonString.indexOf("\"}", jsonString.indexOf("delta")));
                    ApiResult result = library_system.incBookStock(Integer.parseInt(BookIdStr), Integer.parseInt(deltaStr));
                    if(result.ok) {
                        outputStream.write("Inc stock successfully".getBytes());
                    }else {
                        outputStream.write("Inc stock failed".getBytes());
                    }
                }
                else if(requestBodyBuilder.toString().matches((".*\"id\":.*"))){  // 只出现 id, 是删除
                    String jsonString = requestBodyBuilder.toString();
//                    System.out.println(111);
                    String BookIdStr = jsonString.substring(jsonString.indexOf("id") + 5, jsonString.indexOf("\"}", jsonString.indexOf("id")));
//                    System.out.println(BookIdStr);
                    ApiResult result = library_system.removeBook(Integer.parseInt(BookIdStr));
                    if(result.ok) {
                        outputStream.write("Delete book successfully".getBytes());
                    }else {
                        outputStream.write("Delete book failed".getBytes());
                    }
                }
                else if(requestBodyBuilder.toString().matches((".*\"book_id\":.*"))){  // 出现 bookid 的还可能是修改信息
                    String jsonString = requestBodyBuilder.toString();
                    System.out.println(jsonString);
                    Book book = parseBookFromJsonWithID(jsonString);
                    ApiResult result = library_system.modifyBookInfo(book);
                    if(result.ok) {
                        outputStream.write("Modify book successfully".getBytes());
                    }else {
                        outputStream.write("Modify book failed".getBytes());
                    }
                }
                else {  // 剩下情况是图书入库
                    String jsonString = requestBodyBuilder.toString();
//                    System.out.println(jsonString);
                    Book book = parseBookFromJson(jsonString);
                    ApiResult result = library_system.storeBook(book);
                    if(result.ok) {
                        outputStream.write("Create book successfully".getBytes());
                    }else {
                        outputStream.write("Create book failed".getBytes());
                    }
                }

                outputStream.close();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public void handleOptionsRequest(HttpExchange exchange) throws IOException {
            // 处理OPTIONS请求的逻辑
            exchange.sendResponseHeaders(200, -1);
        }
    }

    public static BookQueryConditions parseConditionFromJSON(String jsonString) {
        BookQueryConditions bookQueryConditions = new BookQueryConditions();
        String category = null;
        String title = null;
        String press = null;
        String minPublishYearStr = null;
        String maxPublishYearStr = null;
        String author = null;
        String minPriceStr = null;
        String maxPriceStr = null;

        category = jsonString.substring(jsonString.indexOf("\"category\":") + 12, jsonString.indexOf("\",", jsonString.indexOf("\"category\":")));
//        System.out.println(category);
        title = jsonString.substring(jsonString.indexOf("\"title\":") + 9, jsonString.indexOf("\",", jsonString.indexOf("\"title\":")));
//        System.out.println(title);
        press = jsonString.substring(jsonString.indexOf("\"press\":") + 9, jsonString.indexOf("\",", jsonString.indexOf("\"press\":")));
//        System.out.println(press);
        minPublishYearStr = jsonString.substring(jsonString.indexOf("\"minPublishYear\":") + 18, jsonString.indexOf(",", jsonString.indexOf("\"minPublishYear\":"))).replaceAll("[^\\d.]", "");
//        System.out.println("minPY" + minPublishYearStr);
        maxPublishYearStr = jsonString.substring(jsonString.indexOf("\"maxPublishYear\":") + 18, jsonString.indexOf(",", jsonString.indexOf("\"maxPublishYear\":"))).replaceAll("[^\\d.]", "");
//        System.out.println("maxPY" + maxPublishYearStr);
        author = jsonString.substring(jsonString.indexOf("\"author\":") + 10, jsonString.indexOf("\",", jsonString.indexOf("\"author\":")));
//        System.out.println(author);
        minPriceStr = jsonString.substring(jsonString.indexOf("\"minPrice\":") + 12, jsonString.indexOf(",", jsonString.indexOf("\"minPrice\":"))).replaceAll("[^\\d.]", "");
//        System.out.println(minPriceStr);
        maxPriceStr = jsonString.substring(jsonString.indexOf("\"maxPrice\":") + 12, jsonString.indexOf("}", jsonString.indexOf("\"maxPrice\":"))).replaceAll("[^\\d.]", "");
//        System.out.println(maxPriceStr);
        if(!category.isEmpty()) {
            bookQueryConditions.setCategory(category);
        }
        if(!title.isEmpty()) {
            bookQueryConditions.setTitle(title);
        }
        if(!press.isEmpty()) {
            bookQueryConditions.setPress(press);
        }
        if (!minPublishYearStr.isEmpty()) {
            bookQueryConditions.setMinPublishYear(Integer.parseInt(minPublishYearStr));
        }
        if (!maxPublishYearStr.isEmpty()) {
            bookQueryConditions.setMaxPublishYear(Integer.parseInt(maxPublishYearStr));
        }
        bookQueryConditions.setAuthor(author);
        if (!minPriceStr.isEmpty()) {
            bookQueryConditions.setMinPrice(Double.parseDouble(minPriceStr));
        }
        if (!maxPriceStr.isEmpty()) {
            bookQueryConditions.setMaxPrice(Double.parseDouble(maxPriceStr));
        }
        return bookQueryConditions;
    }

    public static String parseQueryToJSON(BookQueryResults querys){
        StringBuilder jsonBuilder = new StringBuilder("[");
        for (Book book : querys.getResults()) {
            jsonBuilder.append("{")
                    .append("\"id\": ").append(book.getBookId()).append(", ")
                    .append("\"category\": \"").append(book.getCategory()).append("\", ")
                    .append("\"title\": \"").append(book.getTitle()).append("\", ")
                    .append("\"press\": \"").append(book.getPress()).append("\", ")
                    .append("\"publish_year\": ").append(book.getPublishYear()).append(", ")
                    .append("\"author\": \"").append(book.getAuthor()).append("\", ")
                    .append("\"price\": ").append(book.getPrice()).append(", ")
                    .append("\"stock\": ").append(book.getStock()).append("},");
        }
        if (!querys.getResults().isEmpty()){
//            jsonBuilder.deleteCharAt(jsonBuilder.length()-1);
            int lastCommaIndex = jsonBuilder.lastIndexOf(",");
            if (lastCommaIndex != -1) {
                jsonBuilder.deleteCharAt(lastCommaIndex);
            }
        }
        jsonBuilder.append("]");
        return jsonBuilder.toString();
    }

    public static List<Book> extractBooksFromRequest(String requestBody) {
//        System.out.println(requestBody);
        Pattern pattern = Pattern.compile("\\{([^\\}]+)\\}");
        Matcher matcher = pattern.matcher(requestBody.substring(2, requestBody.length() - 2));
        List<String> matchList = new ArrayList<>();
        while (matcher.find()) {
            matchList.add(matcher.group(1));
        }
        String[] matchArray = matchList.toArray(new String[0]);
        List<Book> bookList = new ArrayList<>();
        for(String match : matchArray){
//            System.out.println(match);
            Book book = parseBookFromSnippet(match);
            bookList.add(book);
        }
//        System.out.println(bookList);
        return bookList;
    }

    public static Book parseBookFromSnippet(String snippet) {
        String category = null;
        String title = null;
        String press = null;
        String publishYearStr = null;
        String author = null;
        String priceStr = null;
        String stockStr = null;

        Book book = new Book();
        category = snippet.substring(snippet.indexOf("category") + 13, snippet.indexOf("\\\",", snippet.indexOf("category"))).trim().replaceAll("^\"|\"$", "");
        book.setCategory(category);
        title = snippet.substring(snippet.indexOf("title") + 11, snippet.indexOf("\\\",", snippet.indexOf("title"))).trim().replaceAll("^\"|\"$", "");
        book.setTitle(title);
        press = snippet.substring(snippet.indexOf("press") + 11, snippet.indexOf("\\\",", snippet.indexOf("press"))).trim().replaceAll("^\"|\"$", "");
        book.setPress(press);
        publishYearStr = snippet.substring(snippet.indexOf("publish_year") + 16, snippet.indexOf(",", snippet.indexOf("publish_year"))).trim().replaceAll("^\"|\"$", "");
        book.setPublishYear(Integer.parseInt(publishYearStr));
        author = snippet.substring(snippet.indexOf("author") + 12, snippet.indexOf("\\\",", snippet.indexOf("author"))).trim().replaceAll("^\"|\"$", "");
        book.setAuthor(author);
        priceStr = snippet.substring(snippet.indexOf("price") + 9, snippet.indexOf(",", snippet.indexOf("price"))).trim().replaceAll("^\"|\"$", "");
        book.setPrice(Double.parseDouble(priceStr));
        stockStr = snippet.substring(snippet.indexOf("stock") + 9).trim();
        stockStr = stockStr.replaceAll("[^\\d.]", "");
        book.setStock(Integer.parseInt(stockStr));

        return book;
    }

    public static Book parseBookFromJson(String jsonString) {
//        System.out.println(jsonString);
        String category = BookextractValue(jsonString, "category");
//        System.out.println(category);
        String title = BookextractValue(jsonString, "title");
//        System.out.println(title);
        String press = BookextractValue(jsonString, "press");
        String publishYearStr = BookextractValue(jsonString, "publish_year");
        String author = BookextractValue(jsonString, "author");
        String priceStr = BookextractValue(jsonString, "price");
        String stockStr = BookextractValue(jsonString, "stock");

        Book book = new Book();
        book.setCategory(category);
        book.setTitle(title);
        book.setPress(press);
        book.setPublishYear(Integer.parseInt(publishYearStr));
        book.setAuthor(author);
        book.setPrice(Double.parseDouble(priceStr));
        book.setStock(Integer.parseInt(stockStr));
//        System.out.println(book);
        return book;
    }

    public static Book parseBookFromJsonWithID(String jsonString) {
//        System.out.println(jsonString);
        String bookIdStr = BookextractValue(jsonString, "book_id");
        String category = BookextractValue(jsonString, "category");
//        System.out.println(category);
        String title = BookextractValue(jsonString, "title");
//        System.out.println(title);
        String press = BookextractValue(jsonString, "press");
        String publishYearStr = BookextractValue(jsonString, "publish_year");
        String author = BookextractValue(jsonString, "author");
        String priceStr = BookextractValue(jsonString, "price");
        String stockStr = BookextractValue(jsonString, "stock");

        Book book = new Book();
        book.setBookId(Integer.parseInt(bookIdStr));
        book.setCategory(category);
        book.setTitle(title);
        book.setPress(press);
        book.setPublishYear(Integer.parseInt(publishYearStr));
        book.setAuthor(author);
        book.setPrice(Double.parseDouble(priceStr));
        book.setStock(Integer.parseInt(stockStr));
//        System.out.println(book);
        return book;
    }

    public static String BookextractValue(String jsonString, String key) {
        String keyPattern = "\"" + key + "\":";
        int keyIndex = jsonString.indexOf(keyPattern) + keyPattern.length();
        int commaIndex = jsonString.indexOf(",", keyIndex);
        if (commaIndex == -1) {
            // Last key-value pair, no comma
            commaIndex = jsonString.indexOf("}", keyIndex);
        }
        String value = jsonString.substring(keyIndex, commaIndex);

        // Remove leading/trailing quotes (if present)
        if (value.startsWith("\"") && value.endsWith("\"")) {
            value = value.substring(1, value.length() - 1);
        }
        return value;
    }
}
