#include "storage/table_iterator.h"

#include "common/macros.h"
#include "storage/table_heap.h"

/**
 * TODO: Student Implement
 */

bool TableIterator::operator==(const TableIterator &itr) const {
  // Row row1(rid_), row2(itr.rid_);
  // table_heap_->GetTuple(&row1, txn_);
  // itr.table_heap_->GetTuple(&row2, itr.txn_);
  return (table_heap_ == itr.table_heap_) && (rid_ == itr.rid_);
}

bool TableIterator::operator!=(const TableIterator &itr) const {
  return !(operator==(itr));
}

const Row &TableIterator::operator*() {
  Row* row = new Row(rid_);
  table_heap_->GetTuple(row, txn_);
  return *row;
}

Row *TableIterator::operator->() {
  Row* row = new Row(rid_);
  table_heap_->GetTuple(row, txn_);
  return row;
}

TableIterator &TableIterator::operator=(const TableIterator &itr) noexcept {
  rid_ = itr.rid_;
  // table_heap_ = new TableHeap(other.table_heap_->buffer_pool_manager_, other.table_heap_->first_page_id_, other.table_heap_->schema_, other.table_heap_->log_manager_, other.table_heap_->lock_manager_);
  table_heap_ = itr.table_heap_;
  txn_ = itr.txn_;
  return *this;
}

// ++iter
TableIterator &TableIterator::operator++() {
  if(*this == table_heap_->End()) return *this;
  page_id_t pageid = rid_.GetPageId();
  auto page = reinterpret_cast<TablePage *>((table_heap_->buffer_pool_manager_)->FetchPage(pageid));
  RowId nextid;
  int find = 0;
  // page->RLatch();
  if(!page->GetNextTupleRid(rid_, &nextid))
  {
    while((pageid = page->GetNextPageId()) != INVALID_PAGE_ID)
    {
      page = reinterpret_cast<TablePage *>((table_heap_->buffer_pool_manager_)->FetchPage(pageid));
      if(page->GetFirstTupleRid(&nextid))
      {
        (table_heap_->buffer_pool_manager_)->UnpinPage(pageid, false);
        find = 1;
        break;
      }
      (table_heap_->buffer_pool_manager_)->UnpinPage(pageid, false);
    }
  }
  else find = 1;
  (table_heap_->buffer_pool_manager_)->UnpinPage(rid_.GetPageId(), false);
  if(find)
  {
    rid_ = nextid;
    return *this;
  }
  else
  {
    *this = table_heap_->End();
    return *this;
  }
  
}

// iter++
TableIterator TableIterator::operator++(int) { 
  TableIterator itr(*this);
  ++(*this);
  return itr;
}
