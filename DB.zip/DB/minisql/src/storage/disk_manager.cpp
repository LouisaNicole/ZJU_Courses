#include "storage/disk_manager.h"

#include <sys/stat.h>

#include <filesystem>
#include <stdexcept>

#include "glog/logging.h"
#include "page/bitmap_page.h"

DiskManager::DiskManager(const std::string &db_file) : file_name_(db_file) {
  std::scoped_lock<std::recursive_mutex> lock(db_io_latch_);
  db_io_.open(db_file, std::ios::binary | std::ios::in | std::ios::out);
  // directory or file does not exist
  if (!db_io_.is_open()) {
    db_io_.clear();
    // create a new file
    std::filesystem::path p = db_file;
    if (p.has_parent_path()) std::filesystem::create_directories(p.parent_path());
    db_io_.open(db_file, std::ios::binary | std::ios::trunc | std::ios::out);
    db_io_.close();
    // reopen with original mode
    db_io_.open(db_file, std::ios::binary | std::ios::in | std::ios::out);
    if (!db_io_.is_open()) {
      throw std::exception();
    }
  }
  ReadPhysicalPage(META_PAGE_ID, meta_data_);
}

void DiskManager::Close() {
  std::scoped_lock<std::recursive_mutex> lock(db_io_latch_);
  WritePhysicalPage(META_PAGE_ID, meta_data_);
  if (!closed) {
    db_io_.close();
    closed = true;
  }
}

void DiskManager::ReadPage(page_id_t logical_page_id, char *page_data) {
  ASSERT(logical_page_id >= 0, "Invalid page id.");
  ReadPhysicalPage(MapPageId(logical_page_id), page_data);
}

void DiskManager::WritePage(page_id_t logical_page_id, const char *page_data) {
  ASSERT(logical_page_id >= 0, "Invalid page id.");
  WritePhysicalPage(MapPageId(logical_page_id), page_data);
}

/**
 * TODO: Student Implement
 */
page_id_t DiskManager::AllocatePage() {
    // 将meta_data_指针转换为DiskFileMetaPage类型指针
    DiskFileMetaPage *metaPage = reinterpret_cast<DiskFileMetaPage *>(meta_data_);
    // 检查是否已达到最大有效页面ID，如果是，则返回无效页面ID
    if (metaPage->GetAllocatedPages() >= MAX_VALID_PAGE_ID){
        return INVALID_PAGE_ID;
    }

    uint32_t logic_index; // 逻辑索引
    uint32_t page_offset; // 页面偏移量
    page_id_t physical_page_id; // 物理页面ID
    char buffer[PAGE_SIZE] = {0}; // 页面大小的缓冲区，初始化为0

    // 查找第一个未完全使用的扩展区
    for (logic_index = 0; logic_index < metaPage->GetExtentNums(); ++logic_index) {
        if (metaPage->extent_used_page_[logic_index] < BITMAP_SIZE) break;
    }
    // 计算物理页面ID
    physical_page_id = logic_index * (BITMAP_SIZE + 1) + 1;

    // 如果当前逻辑索引等于扩展区数量，说明需要新增一个扩展区
    if (logic_index == metaPage->GetExtentNums()){
        metaPage->extent_used_page_[logic_index] = 1; // 初始化使用页面为1
        metaPage->num_allocated_pages_ ++;  // 增加已分配页面数
        metaPage->num_extents_ ++;  // 增加扩展区数量
        BitmapPage<PAGE_SIZE> * bitmapPage = reinterpret_cast<BitmapPage<PAGE_SIZE>*>(buffer);
        bitmapPage->AllocatePage(page_offset);  // 在新的扩展区分配页面
    }
    else {
        // 读取已存在的物理页面到缓冲区
        ReadPhysicalPage(physical_page_id, buffer);
        metaPage->extent_used_page_[logic_index] ++;  // 更新已使用的页面数
        metaPage->num_allocated_pages_ ++;  // 更新已分配的页面数
        BitmapPage<PAGE_SIZE> *bitmapPage = reinterpret_cast<BitmapPage<PAGE_SIZE>*>(buffer);
        bitmapPage->AllocatePage(page_offset);  // 在已有的扩展区分配页面
    }
    // 将更新后的数据写回到物理页面
    WritePhysicalPage(physical_page_id, buffer);
    // 返回逻辑页面ID
    return logic_index * BITMAP_SIZE + page_offset;
}

/**
 * TODO: Student Implement
 */
void DiskManager::DeAllocatePage(page_id_t logical_page_id) {
  // 首先检查该逻辑页是否已经是空闲的，如果是，则直接返回
    if (IsPageFree(logical_page_id))
        return;

    char buffer[PAGE_SIZE];  // 定义一个页面大小的缓冲区
    // 计算对应的物理页面ID
    page_id_t physical_page_id = logical_page_id / BITMAP_SIZE * (BITMAP_SIZE + 1) + 1;
    // 从磁盘读取物理页面到缓冲区
    ReadPhysicalPage(physical_page_id, buffer);

    // 将meta_data_转换为DiskFileMetaPage类型指针
    DiskFileMetaPage *metaPage = reinterpret_cast<DiskFileMetaPage *>(meta_data_);
    // 将buffer转换为BitmapPage指针
    BitmapPage<PAGE_SIZE> *bitmapPage = reinterpret_cast<BitmapPage<PAGE_SIZE>*>(buffer);

    // 计算所属扩展区索引和在扩展区内的偏移量
    uint32_t page_index = logical_page_id / BITMAP_SIZE;
    uint32_t page_offset = logical_page_id % BITMAP_SIZE;
    // 更新元数据页中的已分配页面计数
    metaPage->num_allocated_pages_ --;
    // 更新扩展区已使用页面计数
    metaPage->extent_used_page_[page_index] --;
    // 在位图页面中释放对应的页面
    bitmapPage->DeAllocatePage(page_offset);

    // 将更新后的缓冲区写回到物理页面
    WritePhysicalPage(physical_page_id, buffer);
}

/**
 * TODO: Student Implement
 */
bool DiskManager::IsPageFree(page_id_t logical_page_id) {
    char buffer[PAGE_SIZE]; // 定义一个页面大小的缓冲区
    // 根据逻辑页面ID计算相应的物理页面ID
    page_id_t physical_page_id = logical_page_id / BITMAP_SIZE * (BITMAP_SIZE + 1) + 1;
    // 从磁盘读取物理页面到缓冲区
    ReadPhysicalPage(physical_page_id, buffer);

    // 将buffer转换为BitmapPage类型的指针
    BitmapPage<PAGE_SIZE> *bitmapPage = reinterpret_cast<BitmapPage<PAGE_SIZE> *>(buffer);
    // 计算逻辑页面ID在位图中的偏移量
    uint32_t page_offset = logical_page_id % BITMAP_SIZE;
    // 调用BitmapPage的IsPageFree方法，检查指定偏移量的页面是否空闲
    return bitmapPage->IsPageFree(page_offset);
}

/**
 * TODO: Student Implement
 */
page_id_t DiskManager::MapPageId(page_id_t logical_page_id) {
  // 计算物理页面ID：逻辑页面ID + 对应的扩展区索引 + 2的偏移量
  // 逻辑页面ID每增加BITMAP_SIZE个，其位于新的扩展区，因此需要增加对应的偏移量
  return logical_page_id + logical_page_id / BITMAP_SIZE + 2;
}

int DiskManager::GetFileSize(const std::string &file_name) {
  struct stat stat_buf;
  int rc = stat(file_name.c_str(), &stat_buf);
  return rc == 0 ? stat_buf.st_size : -1;
}

void DiskManager::ReadPhysicalPage(page_id_t physical_page_id, char *page_data) {
  int offset = physical_page_id * PAGE_SIZE;
  // check if read beyond file length
  if (offset >= GetFileSize(file_name_)) {
#ifdef ENABLE_BPM_DEBUG
    LOG(INFO) << "Read less than a page" << std::endl;
#endif
    memset(page_data, 0, PAGE_SIZE);
  } else {
    // set read cursor to offset
    db_io_.seekp(offset);
    db_io_.read(page_data, PAGE_SIZE);
    // if file ends before reading PAGE_SIZE
    int read_count = db_io_.gcount();
    if (read_count < PAGE_SIZE) {
#ifdef ENABLE_BPM_DEBUG
      LOG(INFO) << "Read less than a page" << std::endl;
#endif
      memset(page_data + read_count, 0, PAGE_SIZE - read_count);
    }
  }
}

void DiskManager::WritePhysicalPage(page_id_t physical_page_id, const char *page_data) {
  size_t offset = static_cast<size_t>(physical_page_id) * PAGE_SIZE;
  // set write cursor to offset
  db_io_.seekp(offset);
  db_io_.write(page_data, PAGE_SIZE);
  // check for I/O error
  if (db_io_.bad()) {
    LOG(ERROR) << "I/O error while writing";
    return;
  }
  // needs to flush to keep disk file in sync
  db_io_.flush();
}