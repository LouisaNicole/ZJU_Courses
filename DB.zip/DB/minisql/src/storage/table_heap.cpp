#include "storage/table_heap.h"

/**
 * TODO: Student Implement
 */
bool TableHeap::InsertTuple(Row &row, Txn *txn) { 
  auto page = reinterpret_cast<TablePage *>(buffer_pool_manager_->FetchPage(first_page_id_));
  page_id_t next_page_id = page->GetNextPageId();
  if (row.GetSerializedSize(schema_) > page->SIZE_MAX_ROW) return false;
  
  while(!page->InsertTuple(row, schema_, txn, lock_manager_, log_manager_))
  {
    // std::cout << "can't insert into this page" << std::endl;
    if(next_page_id == INVALID_PAGE_ID)
    {
      auto next_page = reinterpret_cast<TablePage *>(buffer_pool_manager_->NewPage(next_page_id));
      next_page->Init(next_page_id, page->GetPageId(), log_manager_, txn);
      next_page->SetNextPageId(INVALID_PAGE_ID);
      page->SetNextPageId(next_page_id);
      buffer_pool_manager_->UnpinPage(next_page_id, true);
    }
    buffer_pool_manager_->UnpinPage(page->GetTablePageId(), false);
    page = reinterpret_cast<TablePage *>(buffer_pool_manager_->FetchPage(next_page_id));
    if(page == nullptr) return false;
    next_page_id = page->GetNextPageId();
  }

  buffer_pool_manager_->UnpinPage(page->GetTablePageId(), true);
  return true; 
}

bool TableHeap::MarkDelete(const RowId &rid, Txn *txn) {
  // Find the page which contains the tuple.
  auto page = reinterpret_cast<TablePage *>(buffer_pool_manager_->FetchPage(rid.GetPageId()));
  // If the page could not be found, then abort the recovery.
  if (page == nullptr) {
    return false;
  }
  // Otherwise, mark the tuple as deleted.
  page->WLatch();
  page->MarkDelete(rid, txn, lock_manager_, log_manager_);
  page->WUnlatch();
  buffer_pool_manager_->UnpinPage(page->GetTablePageId(), true);
  return true;
}

/**
 * TODO: Student Implement
 */
bool TableHeap::UpdateTuple(Row &row, const RowId &rid, Txn *txn) { 
  if (row.GetSerializedSize(schema_) >= PAGE_SIZE) return false;
  auto page = reinterpret_cast<TablePage *>(buffer_pool_manager_->FetchPage(rid.GetPageId()));
  if (page == nullptr) {
    return false;
  }
  Row old_row(rid);
  page->WLatch();

  int message = page->UpdateTuple(row, &old_row, schema_, txn, lock_manager_, log_manager_);
  if(message == 3)
  {
    // MarkDelete(rid, txn);
    // if(!InsertTuple(row, txn)) return false;
    page->ApplyDelete(rid, txn, log_manager_);
    page->WUnlatch();
    buffer_pool_manager_->UnpinPage(page->GetTablePageId(), true);
    return InsertTuple(row, txn);
  }
  else if(message == 2)
  {
    LOG(WARNING) << "The tuple is deleted, abort." << std::endl;
    buffer_pool_manager_->UnpinPage(page->GetTablePageId(), false);
    return false;
  }
  else if(message == 1) 
  {
    LOG(WARNING) << "The slot number is invalid, abort." << std::endl;
    buffer_pool_manager_->UnpinPage(page->GetTablePageId(), false);
    return false;
  }
  page->WUnlatch();
  buffer_pool_manager_->UnpinPage(page->GetTablePageId(), true);
  return true; 
}

/**
 * TODO: Student Implement
 */
void TableHeap::ApplyDelete(const RowId &rid, Txn *txn) {
  // Step1: Find the page which contains the tuple.
  auto page = reinterpret_cast<TablePage *>(buffer_pool_manager_->FetchPage(rid.GetPageId()));
  // Step2: Delete the tuple from the page.
  // if(page == nullptr) return;
  page->WLatch();
  page->ApplyDelete(rid, txn, log_manager_);
  page->WUnlatch();
  buffer_pool_manager_->UnpinPage(page->GetTablePageId(), true);
}

void TableHeap::RollbackDelete(const RowId &rid, Txn *txn) {
  // Find the page which contains the tuple.
  auto page = reinterpret_cast<TablePage *>(buffer_pool_manager_->FetchPage(rid.GetPageId()));
  assert(page != nullptr);
  // Rollback to delete.
  page->WLatch();
  page->RollbackDelete(rid, txn, log_manager_);
  page->WUnlatch();
  buffer_pool_manager_->UnpinPage(page->GetTablePageId(), true);
}

/**
 * TODO: Student Implement
 */
bool TableHeap::GetTuple(Row *row, Txn *txn) {
  RowId rid = row->GetRowId();
  auto page = reinterpret_cast<TablePage *>(buffer_pool_manager_->FetchPage(rid.GetPageId()));
  // assert(page != nullptr);
  bool result = page->GetTuple(row, schema_, txn, lock_manager_);

  buffer_pool_manager_->UnpinPage(page->GetTablePageId(), true);
  return result; 
}

void TableHeap::DeleteTable(page_id_t page_id) {
  if (page_id != INVALID_PAGE_ID) {
    auto temp_table_page = reinterpret_cast<TablePage *>(buffer_pool_manager_->FetchPage(page_id));  // 删除table_heap
    if (temp_table_page->GetNextPageId() != INVALID_PAGE_ID)
      DeleteTable(temp_table_page->GetNextPageId());
    buffer_pool_manager_->UnpinPage(page_id, false);
    buffer_pool_manager_->DeletePage(page_id);
  } else {
    DeleteTable(first_page_id_);
  }
}

/**
 * TODO: Student Implement
 */
TableIterator TableHeap::Begin(Txn *txn) { 
  auto page = reinterpret_cast<TablePage *>(buffer_pool_manager_->FetchPage(first_page_id_));
  if(page == nullptr) return End();
  RowId rowid;
  if(page->GetFirstTupleRid(&rowid))
  {
    buffer_pool_manager_->UnpinPage(page->GetTablePageId(), true);
    return TableIterator(this, rowid, txn); 
  }
  else
  {
    buffer_pool_manager_->UnpinPage(page->GetTablePageId(), true);
    return End(); 
  }
  
}

/**
 * TODO: Student Implement
 */
TableIterator TableHeap::End() { 
  RowId rowid(INVALID_PAGE_ID, 0);
  return TableIterator(this, rowid, nullptr); 
}
