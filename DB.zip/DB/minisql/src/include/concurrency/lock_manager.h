

#ifndef MINISQL_LOCK_MANAGER_H
#define MINISQL_LOCK_MANAGER_H

#include <assert.h>
#include <atomic>
#include <condition_variable>
#include <list>
#include <mutex>
#include <set>
#include <stack>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "common/config.h"
#include "common/rowid.h"

class Txn;

class TxnManager;

/**
 * LockManager handles transactions asking for locks on records
 */
class LockManager {
 public:
  enum class LockMode {
    kNone, kShared, kExclusive
    // 无锁,共享锁,独占锁
  };

  /**
   * This class represents a lock request made by a transaction (txn_id)
   */
  class LockRequest { // 事务对记录的锁请求
   public:
    LockRequest(txn_id_t txn_id, LockMode lock_mode)
        : txn_id_(txn_id), lock_mode_(lock_mode), granted_(LockMode::kNone) {}
    // 事务ID,请求的锁模式,已授予的锁模式
    txn_id_t txn_id_{0};
    // The type of lock requested (e.g., shared or exclusive)
    LockMode lock_mode_{LockMode::kShared};
    // The type of lock that has been granted to the transaction
    LockMode granted_{LockMode::kNone};
  };

  /**
   * This class manages a queue of lock requests and provides methods to manipulate it. It uses a list (req_list_) to
   * store the requests and an unordered map (req_list_iter_map_) to keep track of the iterators to each request in the
   * list. It also includes a condition variable (cv_) for synchronization purposes, along with some flags to manage
   * concurrent access.
   */
  class LockRequestQueue { // 管理锁请求队列
   public:
    using ReqListType = std::list<LockRequest>;

    void EmplaceLockRequest(txn_id_t txn_id, LockMode lock_mode) { // 将一个锁请求插入到队列的前面
      req_list_.emplace_front(txn_id, lock_mode);
      bool res = req_list_iter_map_.emplace(txn_id, req_list_.begin()).second;
      // 在无序映射中插入事务 ID 和请求在链表中的迭代器的映射关系
      assert(res);
    }

    bool EraseLockRequest(txn_id_t txn_id) { // 从队列中删除指定事务 ID 的锁请求
      auto iter = req_list_iter_map_.find(txn_id);
      if (iter == req_list_iter_map_.end()) {
        return false;
      }
      req_list_.erase(iter->second);   // 从 req_list_ 链表中删除
      req_list_iter_map_.erase(iter);  // 从 req_list_iter_map_ 中删除该事务 ID 的映射关系
      return true;
    }

    ReqListType::iterator GetLockRequestIter(txn_id_t txn_id) { // 获取指定事务 ID 的锁请求的迭代器
      auto iter = req_list_iter_map_.find(txn_id);
      assert(iter != req_list_iter_map_.end());
      return iter->second;
    }

   public:
    ReqListType req_list_{}; // 锁请求链表
    // 无序映射，将事务 ID 映射到锁请求链表中的迭代器
    std::unordered_map<txn_id_t, ReqListType::iterator> req_list_iter_map_{};

    // for notify blocked txn on this rid. 即用于阻塞等待通知的事务
    std::condition_variable cv_{};

    // A boolean flag indicating whether there's an exclusive write lock currently held. 即指示当前是否存在一个独占写锁
    bool is_writing_{false};
    // A boolean flag indicating whether a lock upgrade is in progress. 即指示是否正在进行锁升级
    bool is_upgrading_{false};
    // An integer count of the number of transactions holding shared locks. 即表示持有共享锁的事务数量
    int32_t sharing_cnt_{0};
  };

 public:
  LockManager() = default;

  ~LockManager() = default;

  void SetTxnMgr(TxnManager *txn_mgr); // 设置事务管理器的指针

  /**
   * Acquire a lock on RID in shared mode. See [LOCK_NOTE] in header file.
   * @param txn the transaction requesting the shared lock
   * @param rid the RID to be locked in shared mode
   * @return true if the lock is granted, false otherwise
   */

  bool LockShared(Txn *txn, const RowId &rid); // 以共享模式获取给定 RID 的锁
  /**
   * Acquire a lock on RID in exclusive mode. See [LOCK_NOTE] in header file.
   * @param txn the transaction requesting the exclusive lock
   * @param rid the RID to be locked in exclusive mode
   * @return true if the lock is granted, false otherwise
   */

  bool LockExclusive(Txn *txn, const RowId &rid); // 以独占模式获取给定 RID 的锁
  /**
   * Upgrade a lock from a shared lock to an exclusive lock.
   * @param txn the transaction requesting the lock upgrade
   * @param rid the RID that should already be locked in shared mode by the requesting transaction
   * @return true if the upgrade is successful, false otherwise
   */

  bool LockUpgrade(Txn *txn, const RowId &rid); // 将给定 RID 的锁从共享模式升级为独占模式

  /**
   * Release the lock held by the transaction.
   * @param txn the transaction releasing the lock, it should actually hold the lock
   * @param rid the RID that is locked by the transaction
   * @return true if the unlock is successful, false otherwise
   */
  bool Unlock(Txn *txn, const RowId &rid); // 释放事务持有的锁

  /*
   * Add edge t1->t2 in the dependency graph
   * */
  void AddEdge(txn_id_t t1, txn_id_t t2);
  /** Removes an edge from t1 -> t2. */
  void RemoveEdge(txn_id_t t1, txn_id_t t2);

  /**
   *  Looks for a cycle by using the Depth First Search (DFS) algorithm.
   *  If it finds a cycle, HasCycle should store the transaction id of the youngest
   *  transaction in the cycle in txn_id and return true. Your function should
   *  return the first cycle it finds. If your graph has no cycles, HasCycle should return false.
   */
  bool HasCycle(txn_id_t &newest_tid_in_cycle); // 使用深度优先搜索算法检测是否存在循环

  bool DFS(const std::unordered_map<txn_id_t, std::set<txn_id_t>>& waits_for,
           txn_id_t txn_id,
           std::unordered_set<txn_id_t>& visited_set,
           std::stack<txn_id_t>& visited_path,
           txn_id_t& revisited_node);

  void DeleteNode(txn_id_t txn_id); // 删除依赖图中的指定事务节点

  /** Runs cycle detection in the background. */
  void RunCycleDetection();

  /*
   * return the set of all edges in the graph, used for testing only!
   * */
  std::vector<std::pair<txn_id_t, txn_id_t>> GetEdgeList(); // 返回图中所有边的列表

  inline void EnableCycleDetection(std::chrono::milliseconds &interval) {
    // 启用循环检测功能，并设置检测间隔时间
    enable_cycle_detection_ = true;
    cycle_detection_interval_ = interval;
  }

  inline void DisableCycleDetection() { enable_cycle_detection_ = false; }
  // 禁用循环检测功能

 private:
  void LockPrepare(Txn *txn, const RowId &rid); // 锁准备阶段，用于准备锁请求

  void CheckAbort(Txn *txn, LockRequestQueue &req_queue); // 检查事务是否需要中止

 private:
  /** Lock table for lock requests. */
  std::unordered_map<RowId, LockRequestQueue> lock_table_{};
  std::mutex latch_{};

  /** Waits-for graph representation. */
  std::unordered_map<txn_id_t, std::set<txn_id_t>> waits_for_{};
  std::unordered_set<txn_id_t> visited_set_{};
  std::stack<txn_id_t> visited_path_{};
  txn_id_t revisited_node_{INVALID_TXN_ID};
  std::atomic<bool> enable_cycle_detection_{false};
  std::chrono::milliseconds cycle_detection_interval_{100};
  TxnManager *txn_mgr_{nullptr};
};

#endif  // MINISQL_LOCK_MANAGER_H
