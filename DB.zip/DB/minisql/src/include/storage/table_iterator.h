#ifndef MINISQL_TABLE_ITERATOR_H
#define MINISQL_TABLE_ITERATOR_H

#include "common/rowid.h"
#include "concurrency/txn.h"
#include "record/row.h"

class TableHeap;

class TableIterator {
public:
 // you may define your own constructor based on your member variables
 explicit TableIterator(TableHeap *table_heap, RowId rid, Txn *txn):table_heap_(table_heap), rid_(rid), txn_(txn)
 {}

 TableIterator(const TableIterator &other)
 {
  this->rid_ = other.rid_;
  // table_heap_ = new TableHeap(other.table_heap_->buffer_pool_manager_, other.table_heap_->first_page_id_, other.table_heap_->schema_, other.table_heap_->log_manager_, other.table_heap_->lock_manager_);
  this->table_heap_ = other.table_heap_;
  this->txn_ = other.txn_;
 }

  virtual ~TableIterator(){}

  bool operator==(const TableIterator &itr) const;

  bool operator!=(const TableIterator &itr) const;

  const Row &operator*();

  Row *operator->();

  TableIterator &operator=(const TableIterator &itr) noexcept;

  TableIterator &operator++();

  TableIterator operator++(int);

private:
  // add your own private member variables here
  TableHeap *table_heap_; 
  RowId rid_;
  Txn *txn_;
};

#endif  // MINISQL_TABLE_ITERATOR_H
