#ifndef MINISQL_RECOVERY_MANAGER_H
#define MINISQL_RECOVERY_MANAGER_H

#include <map>
#include <unordered_map>
#include <vector>

#include "recovery/log_rec.h"

using KvDatabase = std::unordered_map<KeyType, ValType>;
using ATT = std::unordered_map<txn_id_t, lsn_t>; // 活动事务表

struct CheckPoint {
  lsn_t checkpoint_lsn_{INVALID_LSN}; // 检查点的日志序列号
  ATT active_txns_{}; // 活动事务表
  KvDatabase persist_data_{}; // 数据的键值对

  inline void AddActiveTxn(txn_id_t txn_id, lsn_t last_lsn) { active_txns_[txn_id] = last_lsn; }

  inline void AddData(KeyType key, ValType val) { persist_data_.emplace(std::move(key), val); } // 使用了 std::move 函数，将 key 的所有权转移给插入操作
};

class RecoveryManager {
 public:
  /**
  * TODO: Student Implement
  */
  void Init(CheckPoint &last_checkpoint) {
    persist_lsn_ = last_checkpoint.checkpoint_lsn_;  // checkout 的日志序列号
    active_txns_ = last_checkpoint.active_txns_;
    data_ = last_checkpoint.persist_data_;
  }

  /**
  * TODO: Student Implement
  */
  void RedoPhase() {
    int flag = 0; // 标记是否开始执行重做操作
    for (auto iter = log_recs_.begin(); iter != log_recs_.end(); iter++) { // 迭代 log_recs_ 中的日志记录进行重做操作
      if (iter->first >= persist_lsn_) flag = 1; // 当前日志记录的日志序列号大于等于checkout的日志序列号
      if (flag) {
        auto &log_rec = *(iter->second);
        active_txns_[log_rec.txn_id_] = log_rec.lsn_;
        switch (log_rec.type_) {
          case LogRecType::kInsert:
            data_[log_rec.ins_key_] = log_rec.ins_val_;
            break;
          case LogRecType::kDelete:
            data_.erase(log_rec.del_key_);
            break;
          case LogRecType::kUpdate:
            data_.erase(log_rec.old_key_);
            data_[log_rec.new_key_] = log_rec.new_val_;
            break;
          case LogRecType::kCommit:
            active_txns_.erase(log_rec.txn_id_);
            break;
          case LogRecType::kAbort:
            Rollback(log_rec.txn_id_);
            active_txns_.erase(log_rec.txn_id_);
            break;
          default:
            break;
        }
      }
      else continue;
    }
  }

  /**
  * TODO: Student Implement
  */
  void UndoPhase() {
    for (const auto& txn : active_txns_) {
      Rollback(txn.first);
    }
    active_txns_.clear();
  }

  void Rollback(txn_id_t txn_id) {
    auto last_log_lsn = active_txns_[txn_id];
    LogRecPtr log_rec;
    for(; last_log_lsn != INVALID_LSN; last_log_lsn = log_rec->prev_lsn_){
      log_rec = log_recs_[last_log_lsn];
      if (log_rec == nullptr) break;
      switch (log_rec->type_) {
        case LogRecType::kInsert: // 反向的操作
          data_.erase(log_rec->ins_key_);
          break;
        case LogRecType::kDelete:
          data_[log_rec->del_key_] = log_rec->del_val_;
          break;
        case LogRecType::kUpdate:
          data_.erase(log_rec->new_key_);
          data_[log_rec->old_key_] = log_rec->old_val_;
          break;
        default:
          break;
      }
    }
  }

  // used for test only
  void AppendLogRec(LogRecPtr log_rec) { log_recs_.emplace(log_rec->lsn_, log_rec); }

  // used for test only
  inline KvDatabase &GetDatabase() { return data_; }

 private:
  std::map<lsn_t, LogRecPtr> log_recs_{};
  lsn_t persist_lsn_{INVALID_LSN};
  ATT active_txns_{};
  KvDatabase data_{};  // all data in database
};

#endif  // MINISQL_RECOVERY_MANAGER_H
