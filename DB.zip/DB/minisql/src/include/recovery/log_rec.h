#ifndef MINISQL_LOG_REC_H
#define MINISQL_LOG_REC_H

#include <unordered_map>
#include <utility>

#include "common/config.h"
#include "common/rowid.h"
#include "record/row.h"

enum class LogRecType {
  kInvalid,
  kInsert,
  kDelete,
  kUpdate,
  kBegin,
  kCommit,
  kAbort,
};

// used for testing only
using KeyType = std::string;
using ValType = int32_t;

/**
 * TODO: Student Implement
 */
struct LogRec {
  LogRec() = default;

  LogRec(LogRecType type, lsn_t lsn, txn_id_t txn_id, lsn_t prev_lsn)
      : type_(type), lsn_(lsn), txn_id_(txn_id), prev_lsn_(prev_lsn) {}

  LogRecType type_{LogRecType::kInvalid};
  lsn_t lsn_{INVALID_LSN}; // 日志序列号
  lsn_t prev_lsn_{INVALID_LSN}; // 上一个日志记录的序列号
  txn_id_t txn_id_{INVALID_TXN_ID};

  /* used for testing only */
  static std::unordered_map<txn_id_t, lsn_t> prev_lsn_map_;
  static lsn_t next_lsn_;

  // insert data
  KeyType ins_key_{};
  ValType ins_val_{};
  // delete data
  KeyType del_key_{};
  ValType del_val_{};
  // update data
  KeyType old_key_{};
  ValType old_val_{};
  KeyType new_key_{};
  ValType new_val_{};

  static lsn_t get_priv_lsn(txn_id_t txn_id, lsn_t cur_lsn) {
    auto iter = prev_lsn_map_.find(txn_id);
    auto prev_lsn = INVALID_LSN;
    if (iter != prev_lsn_map_.end()) {
      prev_lsn = iter->second;  // 找到前一个日志序列号
      iter->second = cur_lsn;  // 更新最新的日志序列号
    }
    else prev_lsn_map_.emplace(txn_id, cur_lsn);  // 没找到，把当前要找的日志号加入map中
    return prev_lsn;
  }
};

std::unordered_map<txn_id_t, lsn_t> LogRec::prev_lsn_map_ = {};
lsn_t LogRec::next_lsn_ = 0;
// 定义了一个类型别名，表示指向LogRec结构体的智能指针
typedef std::shared_ptr<LogRec> LogRecPtr;

/**
 * TODO: Student Implement
 */
static LogRecPtr CreateInsertLog(txn_id_t txn_id, KeyType ins_key, ValType ins_val) {
  lsn_t lsn = LogRec::next_lsn_++;
  // 通过创建智能指针，可以方便地管理LogRec对象的生命周期，确保在不再需要该对象时能够自动释放相关的内存
  auto type = LogRecType::kInsert;
  auto priv = LogRec::get_priv_lsn(txn_id, lsn);
  auto log = std::make_shared<LogRec>(type, lsn, txn_id, priv);
  log->ins_key_ = ins_key;
  log->ins_val_ = ins_val;
  return log;
}

/**
 * TODO: Student Implement
 */
static LogRecPtr CreateDeleteLog(txn_id_t txn_id, KeyType del_key, ValType del_val) {
  lsn_t lsn = LogRec::next_lsn_++;
  // 通过创建智能指针，可以方便地管理LogRec对象的生命周期，确保在不再需要该对象时能够自动释放相关的内存
  auto type = LogRecType::kDelete;
  auto priv = LogRec::get_priv_lsn(txn_id, lsn);
  auto log = std::make_shared<LogRec>(type, lsn, txn_id, priv);
  log->del_key_ = del_key;
  log->del_val_ = del_val;
  return log;
}

/**
 * TODO: Student Implement
 */
static LogRecPtr CreateUpdateLog(txn_id_t txn_id, KeyType old_key, ValType old_val, KeyType new_key, ValType new_val) {
  lsn_t lsn = LogRec::next_lsn_++;
  // 通过创建智能指针，可以方便地管理LogRec对象的生命周期，确保在不再需要该对象时能够自动释放相关的内存
  auto type = LogRecType::kUpdate;
  auto priv = LogRec::get_priv_lsn(txn_id, lsn);
  auto log = std::make_shared<LogRec>(type, lsn, txn_id, priv);
  log->old_key_ = old_key;
  log->old_val_ = old_val;
  log->new_key_ = new_key;
  log->new_val_ = new_val;
  return log;
}

/**
 * TODO: Student Implement
 */
static LogRecPtr CreateBeginLog(txn_id_t txn_id) {
  lsn_t lsn = LogRec::next_lsn_++;
  // 通过创建智能指针，可以方便地管理LogRec对象的生命周期，确保在不再需要该对象时能够自动释放相关的内存
  auto type = LogRecType::kBegin;
  auto priv = LogRec::get_priv_lsn(txn_id, lsn);
  auto log = std::make_shared<LogRec>(type, lsn, txn_id, priv);
  return log;
}

/**
 * TODO: Student Implement
 */
static LogRecPtr CreateCommitLog(txn_id_t txn_id) {
  lsn_t lsn = LogRec::next_lsn_++;
  // 通过创建智能指针，可以方便地管理LogRec对象的生命周期，确保在不再需要该对象时能够自动释放相关的内存
  auto type = LogRecType::kCommit;
  auto priv = LogRec::get_priv_lsn(txn_id, lsn);
  auto log = std::make_shared<LogRec>(type, lsn, txn_id, priv);
  return log;
}

/**
 * TODO: Student Implement
 */
static LogRecPtr CreateAbortLog(txn_id_t txn_id) {
  lsn_t lsn = LogRec::next_lsn_++;
  // 通过创建智能指针，可以方便地管理LogRec对象的生命周期，确保在不再需要该对象时能够自动释放相关的内存
  auto type = LogRecType::kAbort;
  auto priv = LogRec::get_priv_lsn(txn_id, lsn);
  auto log = std::make_shared<LogRec>(type, lsn, txn_id, priv);
  return log;
}

#endif  // MINISQL_LOG_REC_H
