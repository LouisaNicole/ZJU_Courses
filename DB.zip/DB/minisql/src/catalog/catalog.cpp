#include "catalog/catalog.h"

void CatalogMeta::SerializeTo(char *buf) const {
  ASSERT(GetSerializedSize() <= PAGE_SIZE, "Failed to serialize catalog metadata to disk.");
  MACH_WRITE_UINT32(buf, CATALOG_METADATA_MAGIC_NUM);
  buf += 4;
  MACH_WRITE_UINT32(buf, table_meta_pages_.size());
  buf += 4;
  MACH_WRITE_UINT32(buf, index_meta_pages_.size());
  buf += 4;
  for (auto iter : table_meta_pages_) {
    MACH_WRITE_TO(table_id_t, buf, iter.first);
    buf += 4;
    MACH_WRITE_TO(page_id_t, buf, iter.second);
    buf += 4;
  }
  for (auto iter : index_meta_pages_) {
    MACH_WRITE_TO(index_id_t, buf, iter.first);
    buf += 4;
    MACH_WRITE_TO(page_id_t, buf, iter.second);
    buf += 4;
  }
}

CatalogMeta *CatalogMeta::DeserializeFrom(char *buf) {
  // check valid
  uint32_t magic_num = MACH_READ_UINT32(buf);
  buf += 4;
  ASSERT(magic_num == CATALOG_METADATA_MAGIC_NUM, "Failed to deserialize catalog metadata from disk.");
  // get table and index nums
  uint32_t table_nums = MACH_READ_UINT32(buf);
  buf += 4;
  uint32_t index_nums = MACH_READ_UINT32(buf);
  buf += 4;
  // create metadata and read value
  CatalogMeta *meta = new CatalogMeta();
  for (uint32_t i = 0; i < table_nums; i++) {
    auto table_id = MACH_READ_FROM(table_id_t, buf);
    buf += 4;
    auto table_heap_page_id = MACH_READ_FROM(page_id_t, buf);
    buf += 4;
    meta->table_meta_pages_.emplace(table_id, table_heap_page_id);
  }
  for (uint32_t i = 0; i < index_nums; i++) {
    auto index_id = MACH_READ_FROM(index_id_t, buf);
    buf += 4;
    auto index_page_id = MACH_READ_FROM(page_id_t, buf);
    buf += 4;
    meta->index_meta_pages_.emplace(index_id, index_page_id);
  }
  return meta;
}

/**
 * TODO: Student Implement
 */
uint32_t CatalogMeta::GetSerializedSize() const {
  // ASSERT(false, "Not Implemented yet");
  uint32_t len1 = 4, len2 = 4;
  for(uint32_t i=0; i<table_meta_pages_.size(); i++) len1 += 8;
  for(uint32_t i=0; i<index_meta_pages_.size(); i++) len2 += 8;
  return 4 + len1 + len2;
}

CatalogMeta::CatalogMeta() {}

/**
 * TODO: Student Implement
 */
CatalogManager::CatalogManager(BufferPoolManager *buffer_pool_manager, LockManager *lock_manager,
                               LogManager *log_manager, bool init)
    : buffer_pool_manager_(buffer_pool_manager), lock_manager_(lock_manager), log_manager_(log_manager) {
      if(init)
      {
        catalog_meta_ = CatalogMeta::NewInstance();
        next_table_id_ = 0;
        next_index_id_ = 0;
        Page * catalog_meta_page = buffer_pool_manager->FetchPage(CATALOG_META_PAGE_ID);
        catalog_meta_->SerializeTo(catalog_meta_page->GetData());
        buffer_pool_manager->UnpinPage(CATALOG_META_PAGE_ID,true);
      }
      else
      {
        auto catalog_page = buffer_pool_manager->FetchPage(CATALOG_META_PAGE_ID);
        catalog_meta_ = CatalogMeta::DeserializeFrom(catalog_page->GetData());
        // retrieve table data
        for(const auto& table_data : catalog_meta_->table_meta_pages_)
        {
          page_id_t pageid = table_data.second;
          table_id_t tableid = table_data.first;
          auto table_page = buffer_pool_manager->FetchPage(pageid);
          TableMetadata *table_metadata;
          TableMetadata::DeserializeFrom(table_page->GetData(), table_metadata);
          TableHeap *table_heap = TableHeap::Create(buffer_pool_manager, table_metadata->GetFirstPageId(), table_metadata->GetSchema(), log_manager, lock_manager);
          TableInfo *table_info = TableInfo::Create();
          table_info->Init(table_metadata, table_heap);
          table_names_[table_metadata->GetTableName()] = tableid;
          tables_[tableid] = table_info;
          buffer_pool_manager_->UnpinPage(pageid, false);
        }

        // retrieve index data
        for(const auto& index_data : catalog_meta_->index_meta_pages_)
        {
          page_id_t pageid = index_data.second;
          index_id_t indexid = index_data.first;
          auto index_page = buffer_pool_manager->FetchPage(pageid);
          IndexMetadata *index_metadata;
          IndexMetadata::DeserializeFrom(index_page->GetData(), index_metadata);

          TableInfo *table_info = tables_.at(index_metadata->GetTableId());
          // ASSERT(table_info != nullptr, "Table info is null.");
          IndexInfo *index_info = IndexInfo::Create();
          index_info->Init(index_metadata, table_info, buffer_pool_manager);
          index_names_[table_info->GetTableName()].emplace(index_metadata->GetIndexName(), indexid);
          indexes_[indexid] = index_info;
          buffer_pool_manager_->UnpinPage(pageid, false);
        }
        buffer_pool_manager->UnpinPage(CATALOG_META_PAGE_ID, false);
        next_table_id_ = catalog_meta_->GetNextTableId();
        next_index_id_ = catalog_meta_->GetNextIndexId();
      }
}

CatalogManager::~CatalogManager() {
  FlushCatalogMetaPage();
  delete catalog_meta_;
  for (auto iter : tables_) {
    delete iter.second;
  }
  for (auto iter : indexes_) {
    delete iter.second;
  }
}

/**
 * TODO: Student Implement
 */
dberr_t CatalogManager::CreateTable(const string &table_name, TableSchema *schema, Txn *txn, TableInfo *&table_info) {
  // ASSERT(false, "Not Implemented yet");
  if(table_names_.find(table_name) != table_names_.end()) return DB_TABLE_ALREADY_EXIST;

  table_id_t tableid = catalog_meta_->GetNextTableId();
  page_id_t pageid;
  auto table_page = buffer_pool_manager_->NewPage(pageid);
  auto meta_page = buffer_pool_manager_->FetchPage(CATALOG_META_PAGE_ID);
  TableSchema *new_schema = Schema::DeepCopySchema(schema);
  TableHeap *table_heap = TableHeap::Create(buffer_pool_manager_, new_schema, txn, log_manager_, lock_manager_);
  TableMetadata *table_meta = TableMetadata::Create(tableid, table_name, table_heap->GetFirstPageId(), new_schema);
  table_info = TableInfo::Create();
  table_info->Init(table_meta, table_heap);
  tables_[tableid] = table_info;
  table_names_[table_name] = tableid;
  catalog_meta_->table_meta_pages_[tableid] = pageid;
  table_meta->SerializeTo(table_page->GetData());
  catalog_meta_->SerializeTo(meta_page->GetData());
  buffer_pool_manager_->UnpinPage(pageid, true);
  buffer_pool_manager_->UnpinPage(CATALOG_META_PAGE_ID, true);
  return DB_SUCCESS;
}

/**
 * TODO: Student Implement
 */
dberr_t CatalogManager::GetTable(const string &table_name, TableInfo *&table_info) {
  // ASSERT(false, "Not Implemented yet");
  if(table_names_.find(table_name) != table_names_.end())
  {
    table_info = tables_[table_names_[table_name]];
    return DB_SUCCESS;
  }
  else return DB_TABLE_NOT_EXIST;
}

/**
 * TODO: Student Implement
 */
dberr_t CatalogManager::GetTables(vector<TableInfo *> &tables) const {
  // ASSERT(false, "Not Implemented yet");
  if(tables_.empty()) return DB_TABLE_NOT_EXIST;
  for(auto table_info : tables_)
  {
    tables.push_back(table_info.second);
  }
  return DB_SUCCESS;
}

/**
 * TODO: Student Implement
 */
dberr_t CatalogManager::CreateIndex(const std::string &table_name, const string &index_name,
                                    const std::vector<std::string> &index_keys, Txn *txn, IndexInfo *&index_info,
                                    const string &index_type) {
  // ASSERT(false, "Not Implemented yet");
  if(table_names_.find(table_name) != table_names_.end())
  {
    if(index_names_.find(table_name) != index_names_.end())
    {
      if(index_names_[table_name].find(index_name) != index_names_[table_name].end()) return DB_INDEX_ALREADY_EXIST;
    }
    std::cout << "create index table name: " << table_name << " index name : " << index_name << std::endl;
    std::vector<uint32_t> keymap;
    table_id_t tableid = table_names_[table_name];
    TableInfo *table_info = tables_[tableid];
    TableSchema *schema = table_info->GetSchema();
    for(auto key : index_keys)
    {
      index_id_t idx;
      if(schema->GetColumnIndex(key, idx) == DB_COLUMN_NAME_NOT_EXIST) return DB_COLUMN_NAME_NOT_EXIST;
      else keymap.push_back(idx);
    }

    index_id_t indexid = catalog_meta_->GetNextIndexId();
    page_id_t pageid;
    auto index_page = buffer_pool_manager_->NewPage(pageid);
    auto meta_page = buffer_pool_manager_->FetchPage(CATALOG_META_PAGE_ID);
    IndexMetadata *index_meta = IndexMetadata::Create(indexid, index_name, tableid, keymap);
    index_info = IndexInfo::Create();
    index_info->Init(index_meta, table_info, buffer_pool_manager_);
    indexes_[indexid] = index_info;
    index_names_[table_name].emplace(index_name, indexid);
    catalog_meta_->index_meta_pages_[indexid] = pageid;
    index_meta->SerializeTo(index_page->GetData());
    catalog_meta_->SerializeTo(meta_page->GetData());
    buffer_pool_manager_->UnpinPage(pageid, true);
    buffer_pool_manager_->UnpinPage(CATALOG_META_PAGE_ID, true);
    return DB_SUCCESS;
  }
  else return DB_TABLE_NOT_EXIST;
}

/**
 * TODO: Student Implement
 */
dberr_t CatalogManager::GetIndex(const std::string &table_name, const std::string &index_name,
                                 IndexInfo *&index_info) const {
  // ASSERT(false, "Not Implemented yet");
  if(index_names_.find(table_name) != index_names_.end())
  {
    if(index_names_.at(table_name).find(index_name) != index_names_.at(table_name).end())
    {
      index_info = indexes_.at(index_names_.at(table_name).at(index_name));
      return DB_SUCCESS;
    }
    else return DB_INDEX_NOT_FOUND;
  }
  else return DB_TABLE_NOT_EXIST;
}

/**
 * TODO: Student Implement
 */
dberr_t CatalogManager::GetTableIndexes(const std::string &table_name, std::vector<IndexInfo *> &indexes) const {
  // ASSERT(false, "Not Implemented yet");
  if(index_names_.find(table_name) == index_names_.end()) return DB_TABLE_NOT_EXIST;
  if(indexes_.empty()) return DB_INDEX_NOT_FOUND;
  for(const auto index_info : index_names_.at(table_name))
  {
    indexes.push_back(indexes_.at(index_info.second));
  }
  return DB_SUCCESS;
}

/**
 * TODO: Student Implement
 */
dberr_t CatalogManager::DropTable(const string &table_name) {
  // ASSERT(false, "Not Implemented yet");
  if(table_names_.find(table_name) != table_names_.end())
  {
    std::cout<< "drop table : " << table_name << endl;
    std::unordered_map<std::string, index_id_t> temp;
    temp = index_names_[table_name];
    for(auto index : temp) DropIndex(table_name, index.first);
    table_id_t tableid = table_names_[table_name];
    table_names_.erase(table_name);
    tables_.erase(tableid);
    auto delete_page_id = catalog_meta_->table_meta_pages_[tableid];
    auto meta_page = buffer_pool_manager_->FetchPage(CATALOG_META_PAGE_ID);
    (catalog_meta_->table_meta_pages_).erase(tableid);
    buffer_pool_manager_->DeletePage(delete_page_id);
    catalog_meta_->SerializeTo(meta_page->GetData());
    buffer_pool_manager_->UnpinPage(CATALOG_META_PAGE_ID, true);
    return DB_SUCCESS;
  }
  else return DB_TABLE_NOT_EXIST;
}

/**
 * TODO: Student Implement
 */
dberr_t CatalogManager::DropIndex(const string &table_name, const string &index_name) {
  // ASSERT(false, "Not Implemented yet");
  if(table_names_.find(table_name) != table_names_.end())
  {
    if(index_names_.at(table_name).find(index_name) != index_names_.at(table_name).end())
    {
      std::cout<< "drop index table : " << table_name << " index name : " << index_name << endl;
      index_id_t indexid = index_names_.at(table_name).at(index_name);
      index_names_.at(table_name).erase(index_name);
      indexes_.erase(indexid);
      auto delete_page_id = catalog_meta_->index_meta_pages_[indexid];
      auto meta_page = buffer_pool_manager_->FetchPage(CATALOG_META_PAGE_ID);
      (catalog_meta_->index_meta_pages_).erase(indexid);
      buffer_pool_manager_->DeletePage(delete_page_id);
      catalog_meta_->SerializeTo(meta_page->GetData());
      buffer_pool_manager_->UnpinPage(CATALOG_META_PAGE_ID, true);
      return DB_SUCCESS;
    }
    else return DB_INDEX_NOT_FOUND;
  }
  else return DB_TABLE_NOT_EXIST;
}

/**
 * TODO: Student Implement
 */
dberr_t CatalogManager::FlushCatalogMetaPage() const {
  // ASSERT(false, "Not Implemented yet");
  auto meta_page = buffer_pool_manager_->FetchPage(CATALOG_META_PAGE_ID);
  catalog_meta_->SerializeTo(meta_page->GetData());
  buffer_pool_manager_->UnpinPage(CATALOG_META_PAGE_ID, true);
  if(buffer_pool_manager_->FlushPage(CATALOG_META_PAGE_ID)) return DB_SUCCESS;
  else return DB_FAILED;
}

/**
 * TODO: Student Implement
 */
dberr_t CatalogManager::LoadTable(const table_id_t table_id, const page_id_t page_id) {
  // ASSERT(false, "Not Implemented yet");
  if(tables_.find(table_id) != tables_.end()) return DB_TABLE_ALREADY_EXIST;
  TableMetadata *table_meta;
  auto table_page = buffer_pool_manager_->FetchPage(page_id);
  TableMetadata::DeserializeFrom(table_page->GetData(), table_meta);
  TableHeap *table_heap = TableHeap::Create(buffer_pool_manager_, table_meta->GetFirstPageId(), table_meta->GetSchema(), log_manager_, lock_manager_);
  TableInfo *table_info = TableInfo::Create();
  table_info->Init(table_meta, table_heap);
  tables_[table_id] = table_info;
  table_names_[table_meta->GetTableName()] = table_id;
  catalog_meta_->table_meta_pages_[table_id] = page_id;
  buffer_pool_manager_->UnpinPage(page_id, true);
  return DB_SUCCESS;
}

/**
 * TODO: Student Implement
 */
dberr_t CatalogManager::LoadIndex(const index_id_t index_id, const page_id_t page_id) {
  // ASSERT(false, "Not Implemented yet");
  if(indexes_.find(index_id) != indexes_.end()) return DB_INDEX_ALREADY_EXIST;
  IndexMetadata *index_meta;
  auto table_page = buffer_pool_manager_->FetchPage(page_id);
  IndexMetadata::DeserializeFrom(table_page->GetData(), index_meta);
  TableInfo *table_info = tables_[index_meta->GetTableId()];
  IndexInfo *index_info = IndexInfo::Create();
  index_info->Init(index_meta, table_info, buffer_pool_manager_);
  indexes_[index_id] = index_info;
  index_names_[table_info->GetTableName()].emplace(index_meta->GetIndexName(), index_id);
  catalog_meta_->index_meta_pages_[index_id] = page_id;
  buffer_pool_manager_->UnpinPage(page_id, true);
  return DB_SUCCESS;
}

/**
 * TODO: Student Implement
 */
dberr_t CatalogManager::GetTable(const table_id_t table_id, TableInfo *&table_info) {
  // ASSERT(false, "Not Implemented yet");
  if(tables_.find(table_id) != tables_.end())
  {
    table_info = tables_[table_id];
    return DB_SUCCESS;
  }
  else return DB_FAILED;
}