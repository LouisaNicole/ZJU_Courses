#include "record/column.h"

#include "glog/logging.h"

Column::Column(std::string column_name, TypeId type, uint32_t index, bool nullable, bool unique)
    : name_(std::move(column_name)), type_(type), table_ind_(index), nullable_(nullable), unique_(unique) {
  ASSERT(type != TypeId::kTypeChar, "Wrong constructor for CHAR type.");
  switch (type) {
    case TypeId::kTypeInt:
      len_ = sizeof(int32_t);
      break;
    case TypeId::kTypeFloat:
      len_ = sizeof(float_t);
      break;
    default:
      ASSERT(false, "Unsupported column type.");
  }
}

Column::Column(std::string column_name, TypeId type, uint32_t length, uint32_t index, bool nullable, bool unique)
    : name_(std::move(column_name)),
      type_(type),
      len_(length),
      table_ind_(index),
      nullable_(nullable),
      unique_(unique) {
  ASSERT(type == TypeId::kTypeChar, "Wrong constructor for non-VARCHAR type.");
}

Column::Column(const Column *other)
    : name_(other->name_),
      type_(other->type_),
      len_(other->len_),
      table_ind_(other->table_ind_),
      nullable_(other->nullable_),
      unique_(other->unique_) {}

/**
* TODO: Student Implement
*/
uint32_t Column::SerializeTo(char *buf) const {
  // replace with your code here
  uint32_t len = 0;
  MACH_WRITE_UINT32(buf + len, COLUMN_MAGIC_NUM);
  len += sizeof(uint32_t);
  MACH_WRITE_TO(TypeId, buf + len, type_);
  len += sizeof(TypeId);
  MACH_WRITE_UINT32(buf + len, name_.length());
  len += sizeof(uint32_t);
  MACH_WRITE_STRING(buf + len, name_);
  len += name_.length();
  MACH_WRITE_UINT32(buf + len, len_);
  len += sizeof(uint32_t);
  MACH_WRITE_UINT32(buf + len, table_ind_);
  len += sizeof(uint32_t);
  MACH_WRITE_TO(bool, buf + len, nullable_);
  len += sizeof(bool);
  MACH_WRITE_TO(bool, buf + len, unique_);
  len += sizeof(bool);

  return len;
}

/**
 * TODO: Student Implement
 */
uint32_t Column::GetSerializedSize() const {
  // replace with your code here
  return 4*sizeof(uint32_t) + sizeof(TypeId) + name_.length() + 2*sizeof(bool);
}

/**
 * TODO: Student Implement
 */
uint32_t Column::DeserializeFrom(char *buf, Column *&column) {
  if (column != nullptr) {
//    LOG(WARNING) << "Pointer to column is not null in column deserialize." 									 << std::endl;
  }

  uint32_t magic_num = MACH_READ_UINT32(buf);
  ASSERT(magic_num == COLUMN_MAGIC_NUM, "Failed to deserialize column data from disk.");
  
  // replace with your code here
  uint32_t type_id, name_len, max_len, index, nullable, unique, read_pos=sizeof(uint32_t);
  type_id = MACH_READ_FROM(TypeId, buf + read_pos);
  read_pos += sizeof(TypeId);
  name_len = MACH_READ_UINT32(buf + read_pos);
  read_pos += sizeof(uint32_t);
  std::string name(buf + read_pos, name_len);
  read_pos += name_len;
  max_len = MACH_READ_UINT32(buf + read_pos);
  read_pos += sizeof(uint32_t);
  index = MACH_READ_UINT32(buf + read_pos);
  read_pos += sizeof(uint32_t);
  nullable = MACH_READ_FROM(bool, buf + read_pos);
  read_pos += sizeof(bool);
  unique = MACH_READ_FROM(bool, buf + read_pos);
  read_pos += sizeof(bool);
  if(type_id == TypeId::kTypeChar)
    column = new Column(name, TypeId::kTypeChar, max_len, index, nullable, unique);
  else if(type_id == TypeId::kTypeInt)
    column = new Column(name, TypeId::kTypeInt, index, nullable, unique);
  else if(type_id == TypeId::kTypeFloat)
    column = new Column(name, TypeId::kTypeFloat, index, nullable, unique);

  return read_pos;
}
