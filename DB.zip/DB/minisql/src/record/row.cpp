#include "record/row.h"

/**
 * TODO: Student Implement
 */
uint32_t Row::SerializeTo(char *buf, Schema *schema) const {
  ASSERT(schema != nullptr, "Invalid schema before serialize.");
  ASSERT(schema->GetColumnCount() == fields_.size(), "Fields size do not match schema's column size.");
  // replace with your code here
  
  uint32_t len = 0;
  MACH_WRITE_UINT32(buf + len, (uint32_t)fields_.size());
  len += sizeof(uint32_t);

  // std::cout << "Step1 : " << len << " bitmap size :" << bitmap_size << std::endl;

  int32_t bitmap = 0;
  int i=0;
  for(Field *val : fields_)
  {
    if(!val->IsNull()) bitmap |= (1 << i);
    i++;
  }

  // std::cout << "bitmap : " << bitmap[0] << std::endl;
  MACH_WRITE_TO(int32_t, buf + len, bitmap);
  len += sizeof(int32_t);
  // std::cout << "Step2 : " << len << std::endl;

  for(Field *val : fields_)
  {
    if(!val->IsNull()) len += val->SerializeTo(buf + len);
  }

  // std::cout << "SerializedSize : " << len << std::endl;
  return len;
}

uint32_t Row::DeserializeFrom(char *buf, Schema *schema) {
  ASSERT(schema != nullptr, "Invalid schema before serialize.");
  ASSERT(fields_.empty(), "Non empty field in row.");
  // replace with your code here
  uint32_t pos = 0, field_size;
  field_size = MACH_READ_UINT32(buf + pos);
  pos += sizeof(uint32_t);
  // std::cout << "step1 :" << pos << std::endl;

  int32_t bitmap;
  bitmap = MACH_READ_FROM(int32_t, buf + pos);
  pos += sizeof(int32_t);

  // std::cout << "step2 :" << pos << " field size = " << field_size << std::endl;
  fields_.clear();
  fields_.resize(field_size);
  std::vector<Column *> columns = schema->GetColumns();
  // std::cout << "colunm num : " << schema->GetColumnCount() << " bitmap = " << bitmap[0] << std::endl;
  for(uint32_t i=0; i<field_size; i++)
  {
    pos += Field::DeserializeFrom(buf + pos, columns[i]->GetType(), &fields_[i], ((bitmap >> i) & 1) == 0);
  }

  // std::cout << "DeSerializedSize : " << pos << std::endl;
  return pos;
}

uint32_t Row::GetSerializedSize(Schema *schema) const {
  ASSERT(schema != nullptr, "Invalid schema before serialize.");
  ASSERT(schema->GetColumnCount() == fields_.size(), "Fields size do not match schema's column size.");
  // replace with your code here
  uint32_t len = 0;
  // std::cout << "bitmap size : " << bitmap_size << std::endl;
  for(Field *val : fields_)
  {
    len += val->GetSerializedSize();
    // std::cout << "val len" << val->GetTypeId() << ' ' << len << std::endl;
  }
  // std::cout << "GetSerializedSize : " << 2*sizeof(uint32_t) + bitmap_size * sizeof(int32_t) + len << std::endl;
  return sizeof(uint32_t) + sizeof(int32_t) + len;
}

void Row::GetKeyFromRow(const Schema *schema, const Schema *key_schema, Row &key_row) {
  auto columns = key_schema->GetColumns();
  std::vector<Field> fields;
  uint32_t idx;
  for (auto column : columns) {
    schema->GetColumnIndex(column->GetName(), idx);
    fields.emplace_back(*this->GetField(idx));
  }
  key_row = Row(fields);
}
