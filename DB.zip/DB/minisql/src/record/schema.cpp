#include "record/schema.h"

/**
 * TODO: Student Implement
 */
uint32_t Schema::SerializeTo(char *buf) const {
  // replace with your code here
  uint32_t len = 0;
  MACH_WRITE_UINT32(buf + len, SCHEMA_MAGIC_NUM);
  len += sizeof(uint32_t);
  MACH_WRITE_UINT32(buf + len, (uint32_t)columns_.size());
  len += sizeof(uint32_t);
  for(Column *col : columns_)
  {
    len += col->SerializeTo(buf + len);
  }
  MACH_WRITE_TO(bool, buf + len, is_manage_);
  len += sizeof(bool);
  return len;
}

uint32_t Schema::GetSerializedSize() const {
  // replace with your code here
  uint32_t len = 0;
  for(Column *col : columns_)
  {
    len += col->GetSerializedSize();
  }
  
  return 2*sizeof(uint32_t) + len + sizeof(bool);
}

uint32_t Schema::DeserializeFrom(char *buf, Schema *&schema) {
  // replace with your code here
  if (schema != nullptr) {
    LOG(WARNING) << "Pointer to schema is not null in schema deserialize." << std::endl;
  }
  uint32_t magic_num = MACH_READ_UINT32(buf);
  ASSERT(magic_num == SCHEMA_MAGIC_NUM, "Failed to deserialize schema data from disk.");

  uint32_t pos = sizeof(uint32_t), size;
  size = MACH_READ_UINT32(buf + pos);
  pos += sizeof(uint32_t);

  std::vector<Column *> cols; 
  Column *col = nullptr;
  for(uint32_t i=0; i<size; i++)
  {
    pos += Column::DeserializeFrom(buf + pos, col);
    cols.push_back(col);
  }

  bool is_manage = MACH_READ_FROM(bool, buf + pos);
  pos += sizeof(bool);
  schema = new Schema(cols, is_manage);

  return pos;
}