#include "buffer/lru_replacer.h"

LRUReplacer::LRUReplacer(size_t num_pages){ this->num_pages = num_pages; }

LRUReplacer::~LRUReplacer() = default;

/**
 * TODO: Student Implement
 */
bool LRUReplacer::Victim(frame_id_t *frame_id) {
    // 检查victims列表是否为空，如果为空则没有可被替换的帧，返回false
    if (victims.empty())
        return false;

    // 从victims的表头（即最近最少被访问的数据页）获取帧ID
    *frame_id = victims.front();
    // 将该帧从列表中移除，因为它即将被替换
    victims.pop_front();

    // 在lru_map中找到该帧的迭代器
    auto it = lru_map.find(*frame_id);
    // 从映射中删除该帧的条目，因为它不再是LRU列表的一部分
    lru_map.erase(it);
    // 返回true表示成功找到并准备替换的帧
    return true;
}


/**
 * TODO: Student Implement
 */
void LRUReplacer::Pin(frame_id_t frame_id) {
    // 在lru_map中查找指定的帧ID
    auto it = lru_map.find(frame_id);
    // 如果找到了，说明该帧目前在LRU列表中，需要进行处理
    if (it != lru_map.end()){
        // 从victims列表中删除该帧，因为它现在被固定，不应被替换
        victims.erase(it->second);
        // 同时在lru_map中也删除该帧的条目，更新LRU列表的状态
        lru_map.erase(it);
    }
}


/**
 * TODO: Student Implement
 */
void LRUReplacer::Unpin(frame_id_t frame_id) {
    // 在lru_map中查找指定的帧ID
    auto it = lru_map.find(frame_id);
    // 如果lru_map的大小已达到设定的页面数上限或帧ID已经在lru_map中，直接返回
    if (lru_map.size() >= num_pages || it != lru_map.end())
        return;

    // 将帧ID添加到victims列表的末尾
    victims.push_back(frame_id);
    // 在lru_map中添加帧ID，并将其关联到victims列表的最新（末尾）元素
    lru_map[frame_id] = --victims.end();
}


/**
 * TODO: Student Implement
 */
size_t LRUReplacer::Size() {
  return lru_map.size();
}