#include "buffer/buffer_pool_manager.h"

#include "glog/logging.h"
#include "page/bitmap_page.h"

static const char EMPTY_PAGE_DATA[PAGE_SIZE] = {0};

BufferPoolManager::BufferPoolManager(size_t pool_size, DiskManager *disk_manager)
    : pool_size_(pool_size), disk_manager_(disk_manager) {
  pages_ = new Page[pool_size_];
  replacer_ = new LRUReplacer(pool_size_);
  for (size_t i = 0; i < pool_size_; i++) {
    free_list_.emplace_back(i);
  }
}

BufferPoolManager::~BufferPoolManager() {
  for (auto page : page_table_) {
    FlushPage(page.first);
  }
  delete[] pages_;
  delete replacer_;
}

/**
 * TODO: Student Implement
 */
Page *BufferPoolManager::FetchPage(page_id_t page_id) {
  // 1.     Search the page table for the requested page (P).
  //  1 .获取要fetch的数据页从磁盘到缓冲区的映射
  auto it = page_table_.find(page_id);
  // 1.1    If P exists, pin it and return it immediately.
  // 1.1 如果该映射存在，则表明该数据页在缓冲区中存在
    if (it != page_table_.end()){
      // 获取该数据页在缓冲区中的id
        frame_id_t frameId = it->second;
        Page * page_ret = &pages_[frameId];
        // 数据页固定
        replacer_->Pin(frameId);
        return page_ret;
    }
  // 1.2    If P does not exist, find a replacement page (R) from either the free list or the replacer.
  //        Note that pages are always found from the free list first.
    else {
      // 1.2 如果该映射不存在，则表明该数据页在缓冲区中不存在，需要把数据页先从磁盘取到缓冲区中
        frame_id_t frameId = TryToFindFreePage();
  // 2.     If R is dirty, write it back to the disk.
        if (frameId == INVALID_PAGE_ID && !replacer_->Victim(&frameId))
          // 如果没有数据页可以被替换，则返回nullptr
            return nullptr;
        Page * page = &pages_[frameId];
        // 2.如果被替换的空间中有脏数据，就先把数据写入到磁盘中
        if (page->IsDirty()){
            FlushPage(page->GetPageId());
        }
  // 3.     Delete R from the page table and insert P.
        // 3.在page_table_的映射关系中删除原有的关系，插入新的关系
        page_table_.erase(page->GetPageId());
        page_table_.insert({page_id, frameId});
  // 4.     Update P's metadata, read in the page content from disk, and then return a pointer to P.
        // 4.更新缓冲区对应空间的数据
        page->ResetMemory();
        page->page_id_ = page_id;
        // 数据页固定
        ++page->pin_count_;
        replacer_->Pin(frameId);
        // 从磁盘读入数据
        disk_manager_->ReadPage(page_id, page->GetData());
//        std::cout << "allocated page addr = " << &pages_[frameId] << std::endl;
        return page;
    }
}
frame_id_t BufferPoolManager::TryToFindFreePage()
{
    frame_id_t frameId = INVALID_PAGE_ID;
    // 先从free_list_表示的缓冲区空闲空间中找一个用来写入的空间
    if (!free_list_.empty()){
      // 获取在free_list_表头的空闲空间id
        frameId = free_list_.front();
        // 将该空闲空间从free_list_中删掉
        free_list_.pop_front();
    }
    else {
      // 如果缓冲区没有空闲空间，就从relacer_中寻找用来替换的一块空间
        if (!replacer_->Victim(&frameId))
          // 采用LRU策略寻找最近最少使用的数据页用来替换
            return INVALID_PAGE_ID;
        // 如果没有数据页可以被替换，则返回 INVALID_PAGE_ID
    }
    return frameId;
}

/**
 * TODO: Student Implement
 */
Page *BufferPoolManager::NewPage(page_id_t &page_id) {
  // 0.   Make sure you call AllocatePage!
  // 1.   If all the pages in the buffer pool are pinned, return nullptr.
  // 2.   Pick a victim page P from either the free list or the replacer. Always pick from the free list first.
  // 3.   Update P's metadata, zero out memory and add P to the page table.
  // 4.   Set the page ID output parameter. Return a pointer to P.
    // 1.判断缓冲区是否所有的数据页都被固定
    size_t i;
    for (i = 0; i < pool_size_; ++i) {
        if (pages_[i].GetPinCount() == 0) break;
    }
    // 如果缓冲区中所有的数据页都被固定，则返回 nullptr
    if (i == pool_size_) return nullptr;
    // 2.从缓冲区中找一个用来替换的数据页
    frame_id_t frameId = TryToFindFreePage();
    // 如果没有数据页可以被替换，则返回nullptr
    if (frameId == INVALID_PAGE_ID && !replacer_->Victim(&frameId)) return nullptr;
    // 3.申请新的数据页，更新缓冲区数据以及page_table_的映射关系
    Page * page = &pages_[frameId];
    // 如果被替换的空间中有脏数据，就先把数据写入到磁盘中
    if (page->IsDirty()) FlushPage(page->GetPageId());

    // 从磁盘中申请新的数据页
    page_id_t newPageId = AllocatePage();
    // 在page_table_的映射关系中删除原有的关系，插入新的关系
    page_table_.erase(page->GetPageId());
    page_table_.insert({newPageId, frameId});
    // 更新缓冲区对应空间的数据
    page->ResetMemory();
    page->page_id_ = newPageId;
    // 数据页固定
    ++page->pin_count_;
    replacer_->Pin(frameId);
    page_id = newPageId;
//    printf("newPageId = %d\n", newPageId);
    return page;
}

/**
 * TODO: Student Implement
 */
bool BufferPoolManager::DeletePage(page_id_t page_id) {
  // 0.   Make sure you call DeallocatePage!
  // 1.   Search the page table for the requested page (P).
  // 1.   If P does not exist, return true.
  // 2.   If P exists, but has a non-zero pin-count, return false. Someone is using the page.
  // 3.   Otherwise, P can be deleted. Remove P from the page table, reset its metadata and return it to the free list.
  // 1.获取要delete的数据页从磁盘到缓冲区的映射
  auto it = page_table_.find(page_id);
  // 2. 如果该映射不存在，则表明该数据页在缓冲区中不存在，直接返回true
    if (it == page_table_.end()) return true;
    // 3.如果该映射存在，则表明该数据页在缓冲区中存在
    // 获取该数据页在缓冲区中的id 并获取该数据页
    Page * page = &pages_[it->second];
    // 如果有人在使用该数据页，则无法删除，返回false
    if (page->GetPinCount()) return false;
    // 4.否则，将数据页删除，并更新page table和free list
    // 如果被删除的空间中有脏数据，就先把数据写入到磁盘中
    // 更新page table和free list
    if (page->IsDirty()) FlushPage(page->GetPageId());
    page_table_.erase(page->GetPageId());
    // 删除数据页
    DeallocatePage(page->GetPageId());

    // 更新page对应数据
    page->ResetMemory();
    page->page_id_ = INVALID_PAGE_ID;
    page->pin_count_ = 0;
    page->is_dirty_ = false;

    replacer_->Unpin(it->second);
    return true;
}

/**
 * TODO: Student Implement
 */
bool BufferPoolManager::UnpinPage(page_id_t page_id, bool is_dirty) {
  // 获取要unpin的数据页从磁盘到缓冲区的映射
    auto it = page_table_.find(page_id);
    // 如果该映射不存在，则表明该数据页在缓冲区中不存在，直接返回true
    if (it == page_table_.end()) return true;
    // 如果该映射存在，则表明该数据页在缓冲区中存在
    // 获取该数据页在缓冲区中的id
    frame_id_t frameId = it->second;
    Page * page = &pages_[frameId];
    // 如果pin count为0，则不应该unpin，返回false
    if (page->GetPinCount() == 0) return false;
//    page->is_dirty_ = is_dirty;
    if (is_dirty) page->is_dirty_ = true;
    // 将该数据页在缓冲区中unpin
    --page->pin_count_;
    // 如果缓冲区中unpin后pin count为0，则还需要在replacer中unpin
    if (page->GetPinCount() == 0) replacer_->Unpin(frameId);
    return true;
}

/**
 * TODO: Student Implement
 */
bool BufferPoolManager::FlushPage(page_id_t page_id) {
  // 获取要flush的数据页从磁盘到缓冲区的映射
    auto it = page_table_.find(page_id);
    // 如果该映射不存在，则表明该数据页在缓冲区中不存在，直接返回false
    if (it == page_table_.end()) return false;
    // 如果该映射存在，则表明该数据页在缓冲区中存在
    // 获取该数据页在缓冲区中的id
    frame_id_t frameId = it->second;
    Page * page = &pages_[frameId];
    // 写入磁盘
    disk_manager_->WritePage(page_id, page->GetData());
    // 由于转储到磁盘中，脏数据会被写入，因此要把is_dirty置为false
    page->is_dirty_ = false;
    return true;
}

page_id_t BufferPoolManager::AllocatePage() {
  int next_page_id = disk_manager_->AllocatePage();
  return next_page_id;
}

void BufferPoolManager::DeallocatePage(__attribute__((unused)) page_id_t page_id) {
  disk_manager_->DeAllocatePage(page_id);
}

bool BufferPoolManager::IsPageFree(page_id_t page_id) {
  return disk_manager_->IsPageFree(page_id);
}

// Only used for debug
bool BufferPoolManager::CheckAllUnpinned() {
  bool res = true;
  for (size_t i = 0; i < pool_size_; i++) {
    if (pages_[i].pin_count_ != 0) {
      res = false;
      LOG(ERROR) << "page " << pages_[i].page_id_ << " pin count:" << pages_[i].pin_count_ << endl;
    }
  }
  return res;
}