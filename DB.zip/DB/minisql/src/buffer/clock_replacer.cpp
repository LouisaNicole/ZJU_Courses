//
// Created by dell on 24-5-31.
//
#include "buffer/clock_replacer.h"

CLOCKReplacer::CLOCKReplacer(size_t num_pages) {
  capacity = 0;
  clockHand = 0;
  for (size_t i = 0; i < num_pages; i++) {
    victims.emplace_back(make_pair(true, false));
  }
}

CLOCKReplacer::~CLOCKReplacer() = default;

bool CLOCKReplacer::Victim(frame_id_t *frame_id) {
  for (; this->Size() > 0; clockHand ++) {
    // clock_hand 达到 frames 的长度，则置 0，模拟时钟的重新循环
    if (clockHand == victims.size()) clockHand = 0;
    // 如果该 frame 不存在，指向下一个
    if (victims[clockHand].first) continue;
    // 如果 ref flag 为 true，则将其置为 false 并继续下一个
    if (victims[clockHand].second) {
      victims[clockHand].second = false;
      continue;
    }
    // 找到了之后，clock_hand_ +1
    victims[clockHand].first = true;
    *frame_id = clockHand++;
    capacity--;
    return true;
  }
  return false;
}

void CLOCKReplacer::Pin(frame_id_t frame_id) {
  if (!victims[frame_id].first) {
    victims[frame_id].first = true;
    capacity--;
  }
}

void CLOCKReplacer::Unpin(frame_id_t frame_id) {
  if (victims[frame_id].first) {
    victims[frame_id].first = false;
    victims[frame_id].second = true;
    capacity++;
  }
}

size_t CLOCKReplacer::Size() {
  return capacity;
}