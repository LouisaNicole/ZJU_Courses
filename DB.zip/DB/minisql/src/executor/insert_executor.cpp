//
// Created by njz on 2023/1/27.
//

#include "executor/executors/insert_executor.h"

InsertExecutor::InsertExecutor(ExecuteContext *exec_ctx, const InsertPlanNode *plan,
                               std::unique_ptr<AbstractExecutor> &&child_executor)
    : AbstractExecutor(exec_ctx), plan_(plan), child_executor_(std::move(child_executor)) {}

void InsertExecutor::Init() {
  child_executor_->Init();
  exec_ctx_->GetCatalog()->GetTable(plan_->GetTableName(), table_info_);
  schema_ = table_info_->GetSchema();
  exec_ctx_->GetCatalog()->GetTableIndexes(table_info_->GetTableName(), index_info_);
}

bool InsertExecutor::Next([[maybe_unused]] Row *row, RowId *rid) {
  Row insert_row;
  RowId insert_rid;
  if (child_executor_->Next(&insert_row, &insert_rid)) {
    for (int i = 0; i < table_info_->GetSchema()->GetColumnCount(); i++) {
      if (table_info_->GetSchema()->GetColumn(i)->IsUnique()) {
        for (int col = 0; col < index_info_.size(); col++) {
          if (i == index_info_[col]->GetIndexKeySchema()->GetColumn(0)->GetTableInd()) {
            Row my_row;
            std:vector<RowId> conflict;
            insert_row.GetKeyFromRow(table_info_->GetSchema(), index_info_[col]->GetIndexKeySchema(), my_row);
            index_info_[col]->GetIndex()->ScanKey(my_row, conflict, nullptr);
            if (!conflict.empty()) {
              cout << "PRIMARY KEY conflict or UNIQUE conflict!" << endl;
              return false;
            }
          }
        }
      }
    }
    if (table_info_->GetTableHeap()->InsertTuple(insert_row, exec_ctx_->GetTransaction())) {
      insert_rid = insert_row.GetRowId();
      for (auto info : index_info_) {  // 更新索引
        Row key_row;
        insert_row.GetKeyFromRow(schema_, info->GetIndexKeySchema(), key_row);
        info->GetIndex()->InsertEntry(key_row, insert_rid, exec_ctx_->GetTransaction());
      }
      return true;
    }
  }
  return false;
}