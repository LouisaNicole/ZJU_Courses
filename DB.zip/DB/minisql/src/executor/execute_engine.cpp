#include "executor/execute_engine.h"

#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <chrono>

#include "common/result_writer.h"
#include "executor/executors/delete_executor.h"
#include "executor/executors/index_scan_executor.h"
#include "executor/executors/insert_executor.h"
#include "executor/executors/seq_scan_executor.h"
#include "executor/executors/update_executor.h"
#include "executor/executors/values_executor.h"
#include "glog/logging.h"
#include "planner/planner.h"
#include "utils/utils.h"

extern "C" {
int yyparse(void);
#include "parser/minisql_lex.h"
#include "parser/parser.h"
}

ExecuteEngine::ExecuteEngine() {
  char path[] = "./databases";
  DIR *dir;
  if ((dir = opendir(path)) == nullptr) {
    mkdir("./databases", 0777);
    dir = opendir(path);
  }
  /** When you have completed all the code for
   *  the test, run it using main.cpp and uncomment
   *  this part of the code.

  struct dirent *stdir;
  while((stdir = readdir(dir)) != nullptr) {
    if( strcmp( stdir->d_name , "." ) == 0 ||
        strcmp( stdir->d_name , "..") == 0 ||
        stdir->d_name[0] == '.')
      continue;
    dbs_[stdir->d_name] = new DBStorageEngine(stdir->d_name, false);
  }**/
  closedir(dir);
}

std::unique_ptr<AbstractExecutor> ExecuteEngine::CreateExecutor(ExecuteContext *exec_ctx,
                                                                const AbstractPlanNodeRef &plan) {
  // 根据计划节点（plan）的类型进行不同的处理
  switch (plan->GetType()) {
    // Create a new sequential scan executor
    case PlanType::SeqScan: {
      return std::make_unique<SeqScanExecutor>(exec_ctx, dynamic_cast<const SeqScanPlanNode *>(plan.get()));
    }
    // Create a new index scan executor
    case PlanType::IndexScan: {
      return std::make_unique<IndexScanExecutor>(exec_ctx, dynamic_cast<const IndexScanPlanNode *>(plan.get()));
    }
    // Create a new update executor
    case PlanType::Update: {
      // 获取UpdatePlanNode对象的指针（update_plan）
      auto update_plan = dynamic_cast<const UpdatePlanNode *>(plan.get());
      // 通过递归调用CreateExecutor函数创建子计划的执行器（child_executor）
      auto child_executor = CreateExecutor(exec_ctx, update_plan->GetChildPlan());
      // 使用exec_ctx、update_plan和移动语义（std::move）创建更新执行器，并将子执行器作为参数传递给它
      return std::make_unique<UpdateExecutor>(exec_ctx, update_plan, std::move(child_executor));
    }
      // Create a new delete executor
    case PlanType::Delete: {
      // 类似于更新执行器的创建过程，获取DeletePlanNode对象的指针（delete_plan），创建子计划的执行器，并使用它们创建删除执行器
      auto delete_plan = dynamic_cast<const DeletePlanNode *>(plan.get());
      auto child_executor = CreateExecutor(exec_ctx, delete_plan->GetChildPlan());
      return std::make_unique<DeleteExecutor>(exec_ctx, delete_plan, std::move(child_executor));
    }
    case PlanType::Insert: {
      // 类似于更新和删除执行器的创建过程，获取InsertPlanNode对象的指针（insert_plan），创建子计划的执行器，并使用它们创建插入执行器
      auto insert_plan = dynamic_cast<const InsertPlanNode *>(plan.get());
      auto child_executor = CreateExecutor(exec_ctx, insert_plan->GetChildPlan());
      return std::make_unique<InsertExecutor>(exec_ctx, insert_plan, std::move(child_executor));
    }
    case PlanType::Values: {
      return std::make_unique<ValuesExecutor>(exec_ctx, dynamic_cast<const ValuesPlanNode *>(plan.get()));
    }
    default:
      throw std::logic_error("Unsupported plan type.");
  }
}

// 执行给定的查询计划，并将结果存储在指定的结果集中
dberr_t ExecuteEngine::ExecutePlan(const AbstractPlanNodeRef &plan, std::vector<Row> *result_set, Txn *txn,
                                   ExecuteContext *exec_ctx) {
  // 使用CreateExecutor函数创建与给定计划节点（plan）对应的执行器，并将其存储在executor变量中
  auto executor = CreateExecutor(exec_ctx, plan);
  try {
    // 初始化执行器，在执行之前进行必要的准备工作
    executor->Init();
    // 创建一个空的行标识符,空的行对象，用于存储从执行器中获取的行数据
    RowId rid{};
    Row row{};
    while (executor->Next(&row, &rid)) { // 在每次迭代中，执行器将返回下一行数据，并将其存储在row对象中，同时还会更新行标识符rid
      if (result_set != nullptr) {
        result_set->push_back(row);
      }
    }
  } catch (const exception &ex) {
    std::cout << "Error Encountered in Executor Execution: " << ex.what() << std::endl;
    if (result_set != nullptr) {
      result_set->clear();
    }
    return DB_FAILED;
  }
  return DB_SUCCESS;
}

dberr_t ExecuteEngine::Execute(pSyntaxNode ast) { // 指向pSyntaxNode(语法树节点)的指针ast
  if (ast == nullptr) {
    return DB_FAILED;
  }
  auto start_time = std::chrono::system_clock::now();
  unique_ptr<ExecuteContext> context(nullptr);
  // 如果当前数据库不为空，则通过当前数据库的指针创建一个ExecuteContext对象，并将其存储在context指针中
  if (!current_db_.empty()) context = dbs_[current_db_]->MakeExecuteContext(nullptr);
  switch (ast->type_) { // 根据语法节点的类型进行不同的处理
    case kNodeCreateDB:
      return ExecuteCreateDatabase(ast, context.get());
    case kNodeDropDB:
      return ExecuteDropDatabase(ast, context.get());
    case kNodeShowDB:
      return ExecuteShowDatabases(ast, context.get());
    case kNodeUseDB:
      return ExecuteUseDatabase(ast, context.get());
    case kNodeShowTables:
      return ExecuteShowTables(ast, context.get());
    case kNodeCreateTable:
      return ExecuteCreateTable(ast, context.get());
    case kNodeDropTable:
      return ExecuteDropTable(ast, context.get());
    case kNodeShowIndexes:
      return ExecuteShowIndexes(ast, context.get());
    case kNodeCreateIndex:
      return ExecuteCreateIndex(ast, context.get());
    case kNodeDropIndex:
      return ExecuteDropIndex(ast, context.get());
    case kNodeTrxBegin:
      return ExecuteTrxBegin(ast, context.get());
    case kNodeTrxCommit:
      return ExecuteTrxCommit(ast, context.get());
    case kNodeTrxRollback:
      return ExecuteTrxRollback(ast, context.get());
    case kNodeExecFile:
      return ExecuteExecfile(ast, context.get());
    case kNodeQuit:
      return ExecuteQuit(ast, context.get());
    default:
      break;
  }
  // Plan the query.
  Planner planner(context.get()); // 创建一个查询计划器对象，并传入执行上下文
  std::vector<Row> result_set{};
  try {
    planner.PlanQuery(ast); // 根据给定的语法节点，规划查询的执行计划
    // Execute the query.
    ExecutePlan(planner.plan_, &result_set, nullptr, context.get());
  } catch (const exception &ex) {
    std::cout << "Error Encountered in Planner: " << ex.what() << std::endl;
    return DB_FAILED;
  }
  auto stop_time = std::chrono::system_clock::now();
  double duration_time =
      double((std::chrono::duration_cast<std::chrono::milliseconds>(stop_time - start_time)).count());
  // Return the result set as string.
  std::stringstream ss;
  ResultWriter writer(ss);
  // 如果查询计划的类型是顺序扫描或索引扫描，则执行以下代码块
  if (planner.plan_->GetType() == PlanType::SeqScan || planner.plan_->GetType() == PlanType::IndexScan) {
    // 获取查询计划的输出模式（schema）
    auto schema = planner.plan_->OutputSchema();
    auto num_of_columns = schema->GetColumnCount();
    if (!result_set.empty()) {
      // find the max width for each column
      vector<int> data_width(num_of_columns, 0);
      for (const auto &row : result_set) {
        for (uint32_t i = 0; i < num_of_columns; i++) {
          // 遍历结果集中的每一行，计算每列的最大宽度
          data_width[i] = max(data_width[i], int(row.GetField(i)->toString().size()));
        }
      }
      int k = 0;
      for (const auto &column : schema->GetColumns()) {
        // 遍历模式中的每一列，计算列名的最大宽度
        data_width[k] = max(data_width[k], int(column->GetName().length()));
        k++;
      }
      // Generate header for the result set.根据列的最大宽度生成结果集的分隔线
      writer.Divider(data_width);
      k = 0;
      writer.BeginRow();
      for (const auto &column : schema->GetColumns()) {
        // 遍历模式中的每一列，写入列名
        writer.WriteHeaderCell(column->GetName(), data_width[k++]);
      }
      writer.EndRow();
      writer.Divider(data_width);

      // Transforming result set into strings.
      for (const auto &row : result_set) {
        writer.BeginRow();
        for (uint32_t i = 0; i < schema->GetColumnCount(); i++) {
          writer.WriteCell(row.GetField(i)->toString(), data_width[i]);
        }
        writer.EndRow();
      }
      writer.Divider(data_width);
    }
    writer.EndInformation(result_set.size(), duration_time, true);
  } else {
    writer.EndInformation(result_set.size(), duration_time, false);
  }
  std::cout << writer.stream_.rdbuf();
  return DB_SUCCESS;
}

void ExecuteEngine::ExecuteInformation(dberr_t result) {
  switch (result) {
    case DB_ALREADY_EXIST:
      cout << "Database already exists." << endl;
      break;
    case DB_NOT_EXIST:
      cout << "Database not exists." << endl;
      break;
    case DB_TABLE_ALREADY_EXIST:
      cout << "Table already exists." << endl;
      break;
    case DB_TABLE_NOT_EXIST:
      cout << "Table not exists." << endl;
      break;
    case DB_INDEX_ALREADY_EXIST:
      cout << "Index already exists." << endl;
      break;
    case DB_INDEX_NOT_FOUND:
      cout << "Index not exists." << endl;
      break;
    case DB_COLUMN_NAME_NOT_EXIST:
      cout << "Column not exists." << endl;
      break;
    case DB_KEY_NOT_FOUND:
      cout << "Key not exists." << endl;
      break;
    case DB_QUIT:
      cout << "Bye." << endl;
      break;
    default:
      break;
  }
}

dberr_t ExecuteEngine::ExecuteCreateDatabase(pSyntaxNode ast, ExecuteContext *context) {
#ifdef ENABLE_EXECUTE_DEBUG
  LOG(INFO) << "ExecuteCreateDatabase" << std::endl;
#endif
  string db_name = ast->child_->val_; // 数据库名称存储在 ast 的第一个子节点的属性值中
  if (dbs_.find(db_name) != dbs_.end()) {
    return DB_ALREADY_EXIST;
  }
  dbs_.insert(make_pair(db_name, new DBStorageEngine(db_name, true)));
  return DB_SUCCESS;
}

dberr_t ExecuteEngine::ExecuteDropDatabase(pSyntaxNode ast, ExecuteContext *context) {
#ifdef ENABLE_EXECUTE_DEBUG
  LOG(INFO) << "ExecuteDropDatabase" << std::endl;
#endif
  string db_name = ast->child_->val_;
  if (dbs_.find(db_name) == dbs_.end()) {
    cout << "Drop database fail" << endl;
    return DB_NOT_EXIST;
  }
  remove(db_name.c_str()); // 删除指定名称的数据库文件
  delete dbs_[db_name]; // 删除 dbs_ 中指定名称的数据库对象
  dbs_.erase(db_name); // 从 dbs_ 中移除指定名称的数据库
  return DB_SUCCESS;
}

dberr_t ExecuteEngine::ExecuteShowDatabases(pSyntaxNode ast, ExecuteContext *context) {
#ifdef ENABLE_EXECUTE_DEBUG
  LOG(INFO) << "ExecuteShowDatabases" << std::endl;
#endif
  if (dbs_.empty()) {
    cout << "Empty set (0.00 sec)" << endl;
    return DB_SUCCESS;
  }
  int max_width = 8;
  // 遍历 dbs_ 中的每个数据库名称，比较其长度与当前的 max_width，如果大于 max_width，则更新 max_width 的值
  for (const auto &itr : dbs_) {
    if (itr.first.length() > max_width) max_width = itr.first.length();
  }
  // 以表格形式显示数据库列表
  cout << "+" << setfill('-') << setw(max_width + 2) << ""
       << "+" << endl;
  cout << "| " << std::left << setfill(' ') << setw(max_width) << "Database"
       << " |" << endl;
  cout << "+" << setfill('-') << setw(max_width + 2) << ""
       << "+" << endl;
  for (const auto &itr : dbs_) {
    cout << "| " << std::left << setfill(' ') << setw(max_width) << itr.first << " |" << endl;
  }
  cout << "+" << setfill('-') << setw(max_width + 2) << ""
       << "+" << endl;
  return DB_SUCCESS;
}

dberr_t ExecuteEngine::ExecuteUseDatabase(pSyntaxNode ast, ExecuteContext *context) {
#ifdef ENABLE_EXECUTE_DEBUG
  LOG(INFO) << "ExecuteUseDatabase" << std::endl;
#endif
  string db_name = ast->child_->val_;
  if (dbs_.find(db_name) != dbs_.end()) {
    current_db_ = db_name;
    cout << "Database changed" << endl;
    return DB_SUCCESS;
  }
  return DB_NOT_EXIST;
}

dberr_t ExecuteEngine::ExecuteShowTables(pSyntaxNode ast, ExecuteContext *context) {
#ifdef ENABLE_EXECUTE_DEBUG
  LOG(INFO) << "ExecuteShowTables" << std::endl;
#endif
  if (current_db_.empty()) {
    cout << "No database selected" << endl;
    return DB_FAILED;
  }
  vector<TableInfo *> tables;
  if (dbs_[current_db_]->catalog_mgr_->GetTables(tables) == DB_FAILED) {
    cout << "Empty set (0.00 sec)" << endl;
    return DB_FAILED;
  }
  string table_in_db("Tables_in_" + current_db_);
  uint max_width = table_in_db.length();
  for (const auto &itr : tables) {
    if (itr->GetTableName().length() > max_width) max_width = itr->GetTableName().length();
  }
  cout << "+" << setfill('-') << setw(max_width + 2) << ""
       << "+" << endl;
  cout << "| " << std::left << setfill(' ') << setw(max_width) << table_in_db << " |" << endl;
  cout << "+" << setfill('-') << setw(max_width + 2) << ""
       << "+" << endl;
  for (const auto &itr : tables) {
    cout << "| " << std::left << setfill(' ') << setw(max_width) << itr->GetTableName() << " |" << endl;
  }
  cout << "+" << setfill('-') << setw(max_width + 2) << ""
       << "+" << endl;
  return DB_SUCCESS;
}

/**
 * 创建表
 */
dberr_t ExecuteEngine::ExecuteCreateTable(pSyntaxNode ast, ExecuteContext *context) {
#ifdef ENABLE_EXECUTE_DEBUG
  LOG(INFO) << "ExecuteCreateTable" << std::endl;
#endif
  if (current_db_.empty()) {
    cout << "No database selected" << endl;
    return DB_FAILED;
  }
  string table_name = ast->child_->val_; // 表名
  std::vector<std::string> is_primary_keys, is_unique_keys;
  std::vector<Column *> my_column;
  pSyntaxNode node = ast->child_->next_->child_; // 找到第一个传入table的column
  pSyntaxNode last_node;
  // 如果有primary key，找到所有加入primary_keys中
  for (last_node = node; last_node->next_ != nullptr; last_node = last_node->next_) {}
  if (last_node->val_ != nullptr && strcmp(last_node->val_, "primary keys") == 0) {
    last_node = last_node->child_;
    for (; last_node != nullptr; last_node = last_node->next_) {
      is_primary_keys.emplace_back(last_node->val_);
    }
  }
  pSyntaxNode col_node;
  string col_name, col_type;
  int col_idx = 0;
  bool prim_or_unique = false;
  for (; (node != nullptr); node = node->next_, col_idx++) {
    if (node->val_ != nullptr && strcmp(node->val_, "primary keys") == 0) break;
    col_node = node->child_; // 当前column
    col_name = col_node->val_; // 当前column的名字
    col_type = col_node->next_->val_; // 当前column的类型
    if (node->val_ != nullptr && strcmp(node->val_, "unique") == 0) {
      prim_or_unique = true; // col_name对应是unique的
      is_unique_keys.emplace_back(col_name);
    }
    // 遍历vector:primary_keys
    for (auto my_prim = is_primary_keys.begin(); my_prim != is_primary_keys.end(); my_prim++) {
      if ((*my_prim) == col_name) { // col_name对应有primary key
        prim_or_unique = true;
        break;
      }
    }
    // 根据是否是primary_key或者unique区分
    if (!prim_or_unique) {
      if (col_type == "int") {
        my_column.emplace_back(new Column(col_name, TypeId::kTypeInt, col_idx, true, false));
      }
      else if (col_type == "float") {
        my_column.emplace_back(new Column(col_name, TypeId::kTypeFloat, col_idx, true, false));
      }
      else if (col_type == "char") {
        double char_len_double = std::stod(col_node->next_->child_->val_); // 解析为 double 类型
        int char_len = static_cast<int>(char_len_double); // 转换为整数
        if (char_len < 0 || char_len != char_len_double) {
          cout << "Error! Invalid char length" << endl;
          return DB_FAILED;
        }
        else {
          my_column.emplace_back(new Column(col_name, TypeId::kTypeChar, char_len, col_idx, true, false));
        }
      }
    }
    else {
      if (col_type == "int") {
        my_column.emplace_back(new Column(col_name, TypeId::kTypeInt, col_idx, false, true));
      }
      else if (col_type == "float") {
        my_column.emplace_back(new Column(col_name, TypeId::kTypeFloat, col_idx, false, true));
      }
      else if (col_type == "char") {
        double char_len_double = std::stod(col_node->next_->child_->val_); // 解析为 double 类型
        int char_len = static_cast<int>(char_len_double); // 转换为整数
        if (char_len < 0 || char_len != char_len_double) {
          cout << "Error! Invalid char length" << endl;
          return DB_FAILED;
        }
        else {
          my_column.emplace_back(new Column(col_name, TypeId::kTypeChar, char_len, col_idx, false, true));
        }
      }
    }
  }
  Schema *schema = new Schema(my_column);
  TableInfo *my_table;
  dberr_t my_create;
  my_create = context->GetCatalog()->CreateTable(table_name, schema, context->GetTransaction(), my_table);
  if (my_create == DB_TABLE_ALREADY_EXIST) {
    cout << "Table already exists!" << endl;
    return my_create;
  }
  if (!is_primary_keys.empty()) {
    string primary_key_index = "primary_key_index_on_" + table_name;  // 主键的唯一索引
    IndexInfo *my_index;
    context->GetCatalog()->CreateIndex(my_table->GetTableName(), primary_key_index, is_primary_keys, context->GetTransaction(), my_index, "bptree");

    for (auto it : is_unique_keys) {
      string unique_key_index = "unique_key_index_on_" + table_name + "_" + it;
      IndexInfo *my_index2;
      context->GetCatalog()->CreateIndex(my_table->GetTableName(), unique_key_index, {it}, context->GetTransaction(), my_index2, "btree");
    }
  }
  return DB_SUCCESS;
}

/**
 * 删除表
 */
dberr_t ExecuteEngine::ExecuteDropTable(pSyntaxNode ast, ExecuteContext *context) {
#ifdef ENABLE_EXECUTE_DEBUG
  LOG(INFO) << "ExecuteDropTable" << std::endl;
#endif
  if (current_db_.empty()) {
    cout << "No database selected" << endl;
    return DB_FAILED;
  }
  //  // 获取指定表（ast->child_->val_）的所有索引信息
  //  std::vector<IndexInfo *> table_index;
  //  context->GetCatalog()->GetTableIndexes(ast->child_->val_, table_index);
  //  // 删除索引
  //  for (auto my_it = table_index.begin(); my_it != table_index.end(); my_it++) {
  //    dberr_t delete_table_index = context->GetCatalog()->DropIndex(ast->child_->val_, (*my_it)->GetIndexName());
  //    if (delete_table_index == DB_INDEX_NOT_FOUND) {
  //      cout << "Index not found! Drop table fail" << endl;
  //      return delete_table_index;
  //    }
  //  }
  // context->GetCatalog()返回的是数据库的目录管理器实例并且删除表
  dberr_t delete_table = context->GetCatalog()->DropTable(ast->child_->val_);
  if (delete_table == DB_TABLE_NOT_EXIST) {
    cout << "Table not exists! Drop table fail" << endl;
    return delete_table;
  }

  cout << "Drop table success" << endl;
  return DB_SUCCESS;
}

/**
 * 显示索引
 */
dberr_t ExecuteEngine::ExecuteShowIndexes(pSyntaxNode ast, ExecuteContext *context) {
#ifdef ENABLE_EXECUTE_DEBUG
  LOG(INFO) << "ExecuteShowIndexes" << std::endl;
#endif
  if (current_db_.empty()) {
    cout << "No database selected." << endl;
    return DB_FAILED;
  }
  std::vector<TableInfo *> my_tables;
  context->GetCatalog()->GetTables(my_tables);
  for(auto table_it = my_tables.begin(); table_it != my_tables.end(); table_it++){
    std::vector<IndexInfo *> table_index;
    // 获取指定表（ast->child_->val_）的所有索引信息
    context->GetCatalog()->GetTableIndexes((*table_it)->GetTableName(), table_index);
    cout << "\ton table \"" << (*table_it)->GetTableName() << "\", we have indexes:" << endl;
    // 找到所有索引
    if (table_index.begin() == table_index.end()) cout << "\t\tno indexes!" << endl;
    for(auto index_it = table_index.begin(); index_it != table_index.end(); index_it++){
      cout << "\t\t" << (*index_it)->GetIndexName() << " on columns: ";
      // 找到列对应的名称
      for (auto col_name : (*index_it)->GetIndexKeySchema()->GetColumns()) {
        cout << col_name->GetName() << " ";
      }
      cout << endl;
    }
  }
}

/**
 * 创建索引
 */
dberr_t ExecuteEngine::ExecuteCreateIndex(pSyntaxNode ast, ExecuteContext *context) {
#ifdef ENABLE_EXECUTE_DEBUG
  LOG(INFO) << "ExecuteCreateIndex" << std::endl;
#endif
  string index_name = ast->child_->val_; // 索引名
  string table_name = ast->child_->next_->val_; // 表名
  std::vector<std::string> index_keys; // 包含在索引中的列名列表
  TableInfo *table_info;
  IndexInfo *index_info = nullptr;
  //  Txn *txn = context->GetTransaction();
  pSyntaxNode temp = ast->child_->next_->next_->child_;
  while (temp != nullptr) {
    index_keys.emplace_back(temp->val_);
    temp = temp->next_;
  }
  dberr_t my_create = context->GetCatalog()->CreateIndex(table_name, index_name, index_keys, context->GetTransaction(), index_info, "pbtree");
  if (my_create == DB_TABLE_NOT_EXIST) {
    cout << "Table not exists! Create index fail" << endl;
    return my_create;
  }
  else if (my_create == DB_INDEX_ALREADY_EXIST) {
    cout << "Already exist index! Create index fail" << endl;
    return my_create;
  }
  else if (my_create == DB_COLUMN_NAME_NOT_EXIST) {
    cout << "Column name dosen't exists ! Create index fail" << endl;
    return my_create;
  }
  context->GetCatalog()->GetTable(table_name, table_info);
  TableHeap* my_table_heap = table_info->GetTableHeap();
  for (auto row = my_table_heap->Begin(context->GetTransaction()); row != my_table_heap->End(); row++) {
    vector<Field> my_fields; // 存储每一行中的字段值
    auto columns = index_info->GetIndexKeySchema()->GetColumns();
    // 将每一行中索引键所对应的字段值存储在 my_fields 向量
    for (auto col = columns.begin(); col != columns.end(); col++) {
      my_fields.push_back(*(*row).GetField((*col)->GetTableInd())); // 指针 col 所属的表的索引
    }
    Row my_row(my_fields);
    index_info->GetIndex()->InsertEntry(my_row, row->GetRowId(),context->GetTransaction());
  }
  cout << "Create index: " << index_name << " success" << endl;
  return DB_SUCCESS;
}

/**
 * 删除索引
 */
dberr_t ExecuteEngine::ExecuteDropIndex(pSyntaxNode ast, ExecuteContext *context) {
#ifdef ENABLE_EXECUTE_DEBUG
  LOG(INFO) << "ExecuteDropIndex" << std::endl;
#endif
  if (current_db_.empty()) {
    cout << "No database selected." << endl;
    return DB_FAILED;
  }
  std::vector<TableInfo *> my_tables;
  context->GetCatalog()->GetTables(my_tables);
  std::vector<IndexInfo *> table_index;
  for(auto table_it = my_tables.begin(); table_it != my_tables.end(); table_it++){
    // 获取指定表（ast->child_->val_）的所有索引信息
    context->GetCatalog()->GetTableIndexes((*table_it)->GetTableName(), table_index);
    // 找到所有索引
    for(auto index_it = table_index.begin(); index_it != table_index.end(); index_it++){
      if((*index_it)->GetIndexName() == ast->child_->val_){
        // 找到索引
        context->GetCatalog()->DropIndex((*table_it)->GetTableName(), ast->child_->val_);
        cout << "Drop index: " << ast->child_->val_ << " success" << endl;
        return DB_SUCCESS;
      }
    }
  }
  cout << "Index not found! Drop index fail" << endl;
  return DB_INDEX_NOT_FOUND;
}

dberr_t ExecuteEngine::ExecuteTrxBegin(pSyntaxNode ast, ExecuteContext *context) {
#ifdef ENABLE_EXECUTE_DEBUG
  LOG(INFO) << "ExecuteTrxBegin" << std::endl;
#endif
  return DB_FAILED;
}

dberr_t ExecuteEngine::ExecuteTrxCommit(pSyntaxNode ast, ExecuteContext *context) {
#ifdef ENABLE_EXECUTE_DEBUG
  LOG(INFO) << "ExecuteTrxCommit" << std::endl;
#endif
  return DB_FAILED;
}

dberr_t ExecuteEngine::ExecuteTrxRollback(pSyntaxNode ast, ExecuteContext *context) {
#ifdef ENABLE_EXECUTE_DEBUG
  LOG(INFO) << "ExecuteTrxRollback" << std::endl;
#endif
  return DB_FAILED;
}

/**
 * 执行一个包含SQL命令的文件
 */
dberr_t ExecuteEngine::ExecuteExecfile(pSyntaxNode ast, ExecuteContext *context) {
#ifdef ENABLE_EXECUTE_DEBUG
  LOG(INFO) << "ExecuteExecfile" << std::endl;
#endif
  // execfile "/mnt/d/luyimin/university/sophomore_second/db/project/minisql/maybe_ok_version/test.txt";
  const int buf_size = 1024;
  char cmd[buf_size];
  memset(cmd, 0, buf_size);
  ifstream file(ast->child_->val_,ios::in);
  if(!file.is_open()){
    cout << "Open file fail" << endl;
    return DB_FAILED;
  }
  // 默认情况下C++ 的输入流会跳过空格、制表符和换行符，noskipws 设置不跳过
  file >> noskipws;
  int count = 0;
  char c;
  while (!file.eof()) {
    file >> c;
    cmd[count] = c;
    count++;
    if (c == ';') { //接收回车
      if (!file.eof()) file.get(c);
      YY_BUFFER_STATE bp = yy_scan_string(cmd);
      yy_switch_to_buffer(bp);
      MinisqlParserInit();
      yyparse();
      if(MinisqlParserGetError()){
        printf("%s\n", MinisqlParserGetErrorMessage());
        return DB_FAILED;
      }
      auto result = this->Execute(MinisqlGetParserRootNode());
      MinisqlParserFinish();
      yy_delete_buffer(bp);
      yylex_destroy();
      this->ExecuteInformation(result);
      if (result == DB_QUIT) break;
      memset(cmd, 0, buf_size);
      count = 0;
    }
  }
  file.close();
  return DB_SUCCESS;
}


/**
 * 退出
 */
dberr_t ExecuteEngine::ExecuteQuit(pSyntaxNode ast, ExecuteContext *context) {
#ifdef ENABLE_EXECUTE_DEBUG
  LOG(INFO) << "ExecuteQuit" << std::endl;
#endif
  return DB_QUIT;
}
