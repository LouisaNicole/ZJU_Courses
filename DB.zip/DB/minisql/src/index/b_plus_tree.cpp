#include "index/b_plus_tree.h"

#include <string>

#include "glog/logging.h"
#include "index/basic_comparator.h"
#include "index/generic_key.h"
#include "page/index_roots_page.h"

/**
 * TODO: Student Implement
 */
BPlusTree::BPlusTree(index_id_t index_id, BufferPoolManager *buffer_pool_manager, const KeyManager &KM,
                     int leaf_max_size, int internal_max_size)
    : index_id_(index_id),
      buffer_pool_manager_(buffer_pool_manager),
      processor_(KM),
      leaf_max_size_(leaf_max_size),
      internal_max_size_(internal_max_size) {
  if (leaf_max_size == UNDEFINED_SIZE){
    leaf_max_size_ = LEAF_PAGE_SIZE;
  }
  if(internal_max_size == UNDEFINED_SIZE) {
    internal_max_size_ = INTERNAL_PAGE_SIZE;
  }
  // IndexRootsPage类用于查找index对应的page
  IndexRootsPage * page = reinterpret_cast<IndexRootsPage*>(buffer_pool_manager->FetchPage(INDEX_ROOTS_PAGE_ID));
  // 如果该index不存在，则将root_page_id赋值为INVALID_PAGE_ID，否则index对应的page_id就会被保存在root_page_id中
  if(!page->GetRootId(index_id_, &root_page_id_)){
    root_page_id_ = INVALID_PAGE_ID;
  }
  // 解除固定
  buffer_pool_manager_->UnpinPage(root_page_id_, true);
  buffer_pool_manager_->UnpinPage(INDEX_ROOTS_PAGE_ID, true);
}

void BPlusTree::Destroy(page_id_t current_page_id) {
  // 如果B+树为空，直接返回，不做任何操作
  if (IsEmpty()) return;
  // 如果当前页面是根页面，将根页面ID设置为无效
  if (current_page_id == root_page_id_) {
    root_page_id_ = INVALID_PAGE_ID;
  }
  // 从缓冲池中获取当前页面的数据，并将其转换为BPlusTreePage类型
  BPlusTreePage *bPlusTreePage = reinterpret_cast<BPlusTreePage*>(buffer_pool_manager_->FetchPage(current_page_id)->GetData());
  // 检查当前页面是否是内部页面
  if (!bPlusTreePage->IsLeafPage()) {
    // 将当前页面转换为InternalPage类型
    InternalPage *internalPage = reinterpret_cast<InternalPage *>(bPlusTreePage);
    // 递归地销毁内部页面中的所有子页面
    for (int i = 0; i < internalPage->GetSize(); ++i) {
      Destroy(internalPage->ValueAt(i));
    }
  }
  // 将当前页面的大小设置为0，表示已清空
  bPlusTreePage->SetSize(0);
  // 释放当前页面，不需要将更改写回磁盘
  buffer_pool_manager_->UnpinPage(current_page_id, false);
  // 从缓冲池中删除当前页面
  buffer_pool_manager_->DeletePage(current_page_id);
}


/*
 * Helper function to decide whether current b+tree is empty
 */
bool BPlusTree::IsEmpty() const {
  return root_page_id_ == INVALID_PAGE_ID;
}

/*****************************************************************************
 * SEARCH
 *****************************************************************************/
/*
 * Return the only value that associated with input key
 * This method is used for point query
 * @return : true means key exists
 */
bool BPlusTree::GetValue(const GenericKey *key, std::vector<RowId> &result, Txn *transaction) {
  // 如果该B+树为空，则直接返回false
  if (IsEmpty()) return false;
  // 调用FindLeafPage查找包含键key的叶节点
  LeafPage *leafPage = reinterpret_cast<LeafPage*>(FindLeafPage(key, root_page_id_)->GetData());
  //  leafPage->CheckOrder(processor_);
  // 在叶节点上查找键key对应的记录
  RowId value;
  bool found = leafPage->Lookup(key, value, processor_);
  // 找到
  // 将value放入result中返回
  if(found) result.push_back(value);
  // 解除固定
  buffer_pool_manager_->UnpinPage(leafPage->GetPageId(), true);
  return found;
}

/*****************************************************************************
 * INSERTION
 *****************************************************************************/
/*
 * Insert constant key & value pair into b+ tree
 * if current tree is empty, start new tree, update root page id and insert
 * entry, otherwise insert into leaf page.
 * @return: since we only support unique key, if user try to insert duplicate
 * keys return false, otherwise return true.
 */
bool BPlusTree::Insert(GenericKey *key, const RowId &value, Txn *transaction) {
  if(IsEmpty()) { // 如果当前树为空，则创建一棵新树
    StartNewTree(key, value);
    return true;
  }
  // 否则就将该键值对插入叶节点中
  // 如果已有该键，则插入失败，flag为false
  // 如果没有该键，则插入成功，flag为true
  else return InsertIntoLeaf(key, value, transaction);
}
/*
 * Insert constant key & value pair into an empty tree
 * User needs to first ask for new page from buffer pool manager(NOTICE: throw
 * an "out of memory" exception if returned value is nullptr), then update b+
 * tree's root page id and insert entry directly into leaf page.
 */
void BPlusTree::StartNewTree(GenericKey *key, const RowId &value) {
  // 向内存池申请一个新的数据页
  LeafPage *page = reinterpret_cast<LeafPage*>(buffer_pool_manager_->NewPage(root_page_id_)->GetData());
  if(page == nullptr){
    throw runtime_error("out of memory");
  }
  // 初始化根节点（也是叶节点）
  page->Init(root_page_id_, INVALID_PAGE_ID, processor_.GetKeySize(), LEAF_PAGE_SIZE);
  // 插入键值对信息
  page->Insert(key, value, processor_);
  // 更新root page id
  UpdateRootPageId(1);
  // 操作完毕，解除固定
  buffer_pool_manager_->UnpinPage(root_page_id_, true);
}

/*
 * Insert constant key & value pair into leaf page
 * User needs to first find the right leaf page as insertion target, then look
 * through leaf page to see whether insert key exist or not. If exist, return
 * immediately, otherwise insert entry. Remember to deal with split if necessary.
 * @return: since we only support unique key, if user try to insert duplicate
 * keys return false, otherwise return true.
 */
bool BPlusTree::InsertIntoLeaf(GenericKey *key, const RowId &value, Txn *transaction) {
  // 调用FindLeafPage查找包含键key的叶节点
  LeafPage * leafPage = reinterpret_cast<LeafPage*>(FindLeafPage(key, root_page_id_)->GetData());
  //  if (leafPage->CheckOrder(processor_)) {cout << "\n\n";}
  RowId temp_value;
  // 判断该key是否已经存在于叶节点中，若存在则不允许插入
  if (leafPage->Lookup(key, temp_value, processor_)) {
    buffer_pool_manager_->UnpinPage(leafPage->GetPageId(), true);
    return false;
  }
  // 否则将键值对插入到叶节点上
  int new_size = leafPage->Insert(key, value, processor_);
  if(new_size >= leaf_max_size_){
    auto newLeafPage = Split(leafPage, transaction);
    // 将分裂出的叶节点插入到父节点中
    InsertIntoParent(leafPage, newLeafPage->KeyAt(0), newLeafPage, transaction);
    buffer_pool_manager_->UnpinPage(newLeafPage->GetPageId(), true);
    return true;
  }
  else {
    buffer_pool_manager_->UnpinPage(leafPage->GetPageId(), true);
    return true;
  }
}

/*
 * Split input page and return newly created page.
 * Using template N to represent either internal page or leaf page.
 * User needs to first ask for new page from buffer pool manager(NOTICE: throw
 * an "out of memory" exception if returned value is nullptr), then move half
 * of key & value pairs from input page to newly created page
 */
BPlusTreeInternalPage *BPlusTree::Split(InternalPage *node, Txn *transaction) {
  // 向内存池申请一个新的数据页
  page_id_t pageId;
  InternalPage *page = reinterpret_cast<InternalPage*>(buffer_pool_manager_->NewPage(pageId)->GetData());
  if (page == nullptr) {
    // 如果返回值为nullptr，则抛出"out of memory"异常
    throw runtime_error("out of memory");
  }
  // 初始化新内部节点
  page->SetPageType(IndexPageType::INTERNAL_PAGE);
  page->Init(pageId, node->GetParentPageId(), node->GetKeySize(), internal_max_size_);
  // 将原节点一半移到新节点
  node->MoveHalfTo(page, buffer_pool_manager_);
  buffer_pool_manager_->UnpinPage(pageId, true);
  buffer_pool_manager_->UnpinPage(node->GetPageId(), true);
  return page;
}

BPlusTreeLeafPage *BPlusTree::Split(LeafPage *node, Txn *transaction) {
  // 向内存池申请一个新的数据页
  page_id_t pageId;
  LeafPage *page = reinterpret_cast<LeafPage*>(buffer_pool_manager_->NewPage(pageId)->GetData());
  if (page == nullptr) {
    // 如果返回值为nullptr，则抛出"out of memory"异常
    throw runtime_error("out of memory");
  }
  // 初始化新叶节点
  page->SetPageType(IndexPageType::LEAF_PAGE);
  page->Init(pageId, node->GetParentPageId(), node->GetKeySize(), leaf_max_size_);
  // 将原节点一半移到新节点
  node->MoveHalfTo(page);
  // 更新叶节点链表
  page->SetNextPageId(node->GetNextPageId());
  node->SetNextPageId(pageId);
  page->SetParentPageId(node->GetParentPageId());
  buffer_pool_manager_->UnpinPage(pageId, true);
  buffer_pool_manager_->UnpinPage(node->GetPageId(), true);
  return page;
}

/*
 * Insert key & value pair into internal page after split
 * @param   old_node      input page from split() method
 * @param   key
 * @param   new_node      returned page from split() method
 * User needs to first find the parent page of old_node, parent node must be
 * adjusted to take info of new_node into account. Remember to deal with split
 * recursively if necessary.
 */
void BPlusTree::InsertIntoParent(BPlusTreePage *old_node, GenericKey *key, BPlusTreePage *new_node, Txn *transaction) {
  // 如果是根节点split，那么就需要新创建一个根节点
  if (old_node->IsRootPage()) {
    // 向内存池申请一个新的数据页
    InternalPage *rootsPage = reinterpret_cast<InternalPage *>(buffer_pool_manager_->NewPage(root_page_id_)->GetData());
    // 初始化新根节点
    rootsPage->SetPageType(IndexPageType::INTERNAL_PAGE);
    rootsPage->Init(root_page_id_, INVALID_PAGE_ID, processor_.GetKeySize(), internal_max_size_);
    // 连接新根节点与两个孩子节点
    rootsPage->PopulateNewRoot(old_node->GetPageId(), key, new_node->GetPageId());
    page_id_t rootId = rootsPage->GetPageId();
    old_node->SetParentPageId(rootId);
    new_node->SetParentPageId(rootId);
    // 更新root page id
    UpdateRootPageId(0);
    // 操作完毕，解除固定
    buffer_pool_manager_->UnpinPage(rootId, true);
    return;
  }
  // 如果不是根节点
  // 根据old_node获取父节点
  InternalPage *parent = reinterpret_cast<InternalPage*>(buffer_pool_manager_->FetchPage(old_node->GetParentPageId())->GetData());
  // 插入split得到的新节点的pair信息
  int size = parent->InsertNodeAfter(old_node->GetPageId(), key, new_node->GetPageId()); 
  if (size <= internal_max_size_) {
    page_id_t parentId = parent->GetPageId();
    buffer_pool_manager_->UnpinPage(parentId, true);
    return;
  }
  // 如果父节点插入新pair后超出size限制，则递归调用Split & InsertIntoParent
  InternalPage* newPage = Split(parent, transaction);
  InsertIntoParent(parent, newPage->KeyAt(0), newPage, transaction);
  buffer_pool_manager_->UnpinPage(parent->GetPageId(), true);
  buffer_pool_manager_->UnpinPage(newPage->GetPageId(), true);
}

/*****************************************************************************
 * REMOVE
 *****************************************************************************/
/*
 * Delete key & value pair associated with input key
 * If current tree is empty, return immediately.
 * If not, User needs to first find the right leaf page as deletion target, then
 * delete entry from leaf page. Remember to deal with redistribute or merge if
 * necessary.
 */
void BPlusTree::Remove(const GenericKey *key, Txn *transaction) {
  // 如果B+树为空，直接返回
  if (IsEmpty()) return;
  // 调用FindLeafPage查找包含键key的叶节点
  LeafPage *leafPage = reinterpret_cast<LeafPage*>(FindLeafPage(key, root_page_id_)->GetData());
  // 调用叶节点的RemoveAndDeleteRecord函数尝试删除键值对
  int new_size = leafPage->RemoveAndDeleteRecord(key, processor_);
  // 删除成功，我们需要判断删除该键值对后是否满足半满条件，若不满足则需要调整
  if(new_size < leafPage->GetMinSize()){
    CoalesceOrRedistribute(leafPage, transaction);
  }
  // 若返回的删除后的size没有变，则说明该键值对不存在，无需删除
  buffer_pool_manager_->UnpinPage(leafPage->GetPageId(), true);
}

/* todo
 * User needs to first find the sibling of input page. If sibling's size + input
 * page's size > page's max size, then redistribute. Otherwise, merge.
 * Using template N to represent either internal page or leaf page.
 * @return: true means target leaf page should be deleted, false means no
 * deletion happens
 */
template <typename N>
bool BPlusTree::CoalesceOrRedistribute(N *&node, Txn *transaction) {
  if (IsEmpty()) return false;
  // 如果是根节点，需要根据删除后的数量决定是否删除该根节点
  if (node->IsRootPage())
    return AdjustRoot(node);

  // 否则先根据节点内的pair数是否满足半满条件决定是否需要调整
  if (node->GetSize() >= node->GetMinSize())
  // 满足半满条件，无需调整
    return false;

  // 不满足半满条件，则先得到该节点的兄弟节点，再判断是重新分配还是合并   
  // 找到父亲节点
  InternalPage *parent = reinterpret_cast<InternalPage*>(buffer_pool_manager_->FetchPage(node->GetParentPageId())->GetData());
  // 找到node下标，进而确定兄弟节点下标
  int node_index = parent->ValueIndex(node->GetPageId());
  int sibling_index = (node_index==0) ? 1 : node_index-1;
  // 找到兄弟节点
  N* sibling = reinterpret_cast<N*>(buffer_pool_manager_->FetchPage(parent->ValueAt(sibling_index))->GetData());

  bool deletion;
  // 根据node及其兄弟节点的size确定是重新分配还是合并
  // 重新分配
  if (sibling->GetSize() + node->GetSize() > node->GetMaxSize()) {
    Redistribute(sibling, node, node_index);
    buffer_pool_manager_->UnpinPage(parent->GetPageId(), true);
    buffer_pool_manager_->UnpinPage(sibling->GetPageId(), true);
    return false;
  }
  // 合并
  else {
    deletion = Coalesce(sibling, node, parent, node_index, transaction);
    buffer_pool_manager_->UnpinPage(parent->GetPageId(), true);
    buffer_pool_manager_->UnpinPage(sibling->GetPageId(), true);
    // 调整父节点
    if (deletion) CoalesceOrRedistribute(parent, transaction);
    return true;
  }
}

/*
 * Move all the key & value pairs from one page to its sibling page, and notify
 * buffer pool manager to delete this page. Parent page must be adjusted to
 * take info of deletion into account. Remember to deal with coalesce or
 * redistribute recursively if necessary.
 * Using template N to represent either internal page or leaf page.
 * @param   neighbor_node      sibling page of input "node"
 * @param   node               input from method coalesceOrRedistribute()
 * @param   parent             parent page of input "node"
 * @return  true means parent node should be deleted, false means no deletion happened
 */
bool BPlusTree::Coalesce(LeafPage *&neighbor_node, LeafPage *&node, InternalPage *&parent, int index,
                         Txn *transaction) {
  // 当index等于0时neighbor_node是node的右兄弟，其余情况都是左兄弟
  if (index != 0) {
    // 进行合并
    node->MoveAllTo(neighbor_node);
    buffer_pool_manager_->UnpinPage(neighbor_node->GetPageId(), true);
    // 将node从父节点中移除
    parent->Remove(index);
    buffer_pool_manager_->DeletePage(node->GetPageId());
  }
  else {
    index = 1;
    neighbor_node->MoveAllTo(node);
    buffer_pool_manager_->UnpinPage(node->GetPageId(), true);
    parent->Remove(index);
    buffer_pool_manager_->DeletePage(neighbor_node->GetPageId());
  }
  // 判断父节点是否需要合并或重调整
  if (parent->GetSize() < parent->GetMinSize()) return true;
  return false;
}

bool BPlusTree::Coalesce(InternalPage *&neighbor_node, InternalPage *&node, InternalPage *&parent, int index,
                         Txn *transaction) {
  // 当index等于0时neighbor_node是node的右兄弟，其余情况都是左兄弟
  if (index != 0) {
    // 进行合并
    GenericKey *middle_key = parent->KeyAt(index);
    node->MoveAllTo(neighbor_node, middle_key, buffer_pool_manager_);
    buffer_pool_manager_->UnpinPage(neighbor_node->GetPageId(), true);
    // 将node从父节点中移除
    parent->Remove(index);
    buffer_pool_manager_->DeletePage(node->GetPageId());
  }
  else {
    index = 1;
    GenericKey *middle_key = parent->KeyAt(index);
    neighbor_node->MoveAllTo(node, middle_key, buffer_pool_manager_);
    buffer_pool_manager_->UnpinPage(node->GetPageId(), true);
    parent->Remove(index);
    buffer_pool_manager_->DeletePage(neighbor_node->GetPageId());
  }
  // 判断父节点是否需要合并或重调整
  if (parent->GetSize() < parent->GetMinSize())
    return true;
  return false;
}

/*
 * Redistribute key & value pairs from one page to its sibling page. If index ==
 * 0, move sibling page's first key & value pair into end of input "node",
 * otherwise move sibling page's last key & value pair into head of input
 * "node".
 * Using template N to represent either internal page or leaf page.
 * @param   neighbor_node      sibling page of input "node"
 * @param   node               input from method coalesceOrRedistribute()
 */
void BPlusTree::Redistribute(LeafPage *neighbor_node, LeafPage *node, int index) {
  // 获取父节点
  InternalPage *parent = reinterpret_cast<InternalPage*>(buffer_pool_manager_->FetchPage(neighbor_node->GetParentPageId())->GetData());
  // 如果index等于0，就把兄弟节点的第一个键值对移到node末尾
  if (index == 0) {
    neighbor_node->MoveFirstToEndOf(node);
    parent->SetKeyAt(1, neighbor_node->KeyAt(0));
  }
  // 否则，就把兄弟节点的最后一个键值对移到node开头
  else {
    neighbor_node->MoveLastToFrontOf(node);
    parent->SetKeyAt(index, node->KeyAt(0));
  }
  buffer_pool_manager_->UnpinPage(parent->GetPageId(), true);
}
void BPlusTree::Redistribute(InternalPage *neighbor_node, InternalPage *node, int index) {
  // 获取父节点
  InternalPage *parent = reinterpret_cast<InternalPage*>(buffer_pool_manager_->FetchPage(node->GetParentPageId())->GetData());
  // 如果index等于0，就把兄弟节点的第一个键值对移到node末尾
  if (index == 0) {
    index = 1;
    GenericKey* middle_key = parent->KeyAt(index);
    neighbor_node->MoveFirstToEndOf(node, middle_key, buffer_pool_manager_);
    parent->SetKeyAt(index, neighbor_node->KeyAt(0));
    buffer_pool_manager_->UnpinPage(parent->GetPageId(), true);
  }
  // 否则，就把兄弟节点的最后一个键值对移到node开头
  else {
    GenericKey* middle_key = parent->KeyAt(index);
    neighbor_node->MoveLastToFrontOf(node, middle_key, buffer_pool_manager_);
    parent->SetKeyAt(index, node->KeyAt(0));
    buffer_pool_manager_->UnpinPage(parent->GetPageId(), true);
  }
}
/*
 * Update root page if necessary
 * NOTE: size of root page can be less than min size and this method is only
 * called within coalesceOrRedistribute() method
 * case 1: when you delete the last element in root page, but root page still
 * has one last child
 * case 2: when you delete the last element in whole b+ tree
 * @return : true means root page should be deleted, false means no deletion
 * happened
 */
bool BPlusTree::AdjustRoot(BPlusTreePage *old_root_node) {
  // case2：删掉仅剩的最后一个节点
  if (old_root_node->GetSize() == 0) {
    root_page_id_ = INVALID_PAGE_ID;
    UpdateRootPageId(0);
    return true;
  }
  // case1：将仅剩的一个儿子调整为根
  if (old_root_node->GetSize() == 1) {
    // 移除旧根，得到新根
    InternalPage *internalPage = reinterpret_cast<InternalPage*>(old_root_node);
    page_id_t child = internalPage->RemoveAndReturnOnlyChild();
    BPlusTreePage *bPlusTreePage = reinterpret_cast<BPlusTreePage*>(buffer_pool_manager_->FetchPage(child)->GetData());
    bPlusTreePage->SetParentPageId(INVALID_PAGE_ID);
    buffer_pool_manager_->UnpinPage(child, true);
    // 更新B+树的根信息
    UpdateRootPageId(0);
    return true;
  }
  return false;
}

/*****************************************************************************
 * INDEX ITERATOR
 *****************************************************************************/
/*
 * Input parameter is void, find the left most leaf page first, then construct
 * index iterator
 * @return : index iterator
 */
IndexIterator BPlusTree::Begin() {
  LeafPage *leafPage = reinterpret_cast<LeafPage*>(FindLeafPage(nullptr, root_page_id_, true)->GetData());
  return IndexIterator(leafPage->GetPageId(), buffer_pool_manager_);
}

/*
 * Input parameter is low key, find the leaf page that contains the input key
 * first, then construct index iterator
 * @return : index iterator
 */
IndexIterator BPlusTree::Begin(const GenericKey *key) {
  LeafPage *leafPage = reinterpret_cast<LeafPage*>(FindLeafPage(key, root_page_id_, false)->GetData());
  return IndexIterator(leafPage->GetPageId(), buffer_pool_manager_, leafPage->KeyIndex(key, processor_));
}

/*
 * Input parameter is void, construct an index iterator representing the end
 * of the key/value pair in the leaf node
 * @return : index iterator
 */
IndexIterator BPlusTree::End() {
  return IndexIterator(INVALID_PAGE_ID, buffer_pool_manager_, 0);
}

/*****************************************************************************
 * UTILITIES AND DEBUG
 *****************************************************************************/
/*
 * Find leaf page containing particular key, if leftMost flag == true, find
 * the left most leaf page
 * Note: the leaf page is pinned, you need to unpin it after use.
 */
Page *BPlusTree::FindLeafPage(const GenericKey *key, page_id_t page_id, bool leftMost) {
  // 从根节点开始查找包含键值key的叶节点
  Page* page = nullptr;
  page_id_t curr_page_id = page_id;
  int cnt = 0;
  while(true){
    // std::cout << "leaf cnt = " << cnt << std::endl;
    // 获取当前页面的数据
    page = buffer_pool_manager_->FetchPage(curr_page_id);
    if (page == nullptr) throw std::runtime_error("Failed to fetch page");
    BPlusTreePage* bPlusTreePage = reinterpret_cast<BPlusTreePage*>(page->GetData());
    page->RLatch();   // 获取读锁
    if (bPlusTreePage->IsLeafPage()) {
      page->RUnlatch();   // 释放读锁
      buffer_pool_manager_->UnpinPage(curr_page_id, false);  // 解除页面固定
      return page;
    }
    // 如果是内部页面，转换为InternalPage类型
    InternalPage* internalPage = reinterpret_cast<InternalPage*>(bPlusTreePage);

    //    ToString(internalPage, buffer_pool_manager_);
    //是否要找最左侧的节点 根据leftMost参数获取子页面ID
    page_id_t child_id = leftMost ? internalPage->ValueAt(0) : internalPage->Lookup(key, processor_);
    // 释放当前页面的读锁并解除固定
    page->RUnlatch();
    buffer_pool_manager_->UnpinPage(curr_page_id, false);
    // 更新当前页面ID为子页面ID，继续查找
    curr_page_id = child_id;
    cnt++;
  }
}

/*
 * Update/Insert root page id in header page(where page_id = 0, header_page is
 * defined under include/page/header_page.h)
 * Call this method everytime root page id is changed.
 * @parameter: insert_record      default value is false. When set to true,
 * insert a record <index_name, current_page_id> into header page instead of
 * updating it.
 */
void BPlusTree::UpdateRootPageId(int insert_record) {
  IndexRootsPage* rootsPage = reinterpret_cast<IndexRootsPage*>(buffer_pool_manager_->FetchPage(INDEX_ROOTS_PAGE_ID)->GetData());
  // 根据insert_record参数决定是插入还是更新根页面ID
  if (insert_record)
    rootsPage->Insert(index_id_, root_page_id_);
  else
    rootsPage->Update(index_id_, root_page_id_);
  // 释放头页面，并将其标记为脏页
  buffer_pool_manager_->UnpinPage(INDEX_ROOTS_PAGE_ID, true);
}

/**
 * This method is used for debug only, You don't need to modify
 */
void BPlusTree::ToGraph(BPlusTreePage *page, BufferPoolManager *bpm, std::ofstream &out, Schema *schema) const {
  std::string leaf_prefix("LEAF_");
  std::string internal_prefix("INT_");
  if (page->IsLeafPage()) {
    auto *leaf = reinterpret_cast<LeafPage *>(page);
    // Print node name
    out << leaf_prefix << leaf->GetPageId();
    // Print node properties
    out << "[shape=plain color=green ";
    // Print data of the node
    out << "label=<<TABLE BORDER=\"0\" CELLBORDER=\"1\" CELLSPACING=\"0\" CELLPADDING=\"4\">\n";
    // Print data
    out << "<TR><TD COLSPAN=\"" << leaf->GetSize() << "\">P=" << leaf->GetPageId()
        << ",Parent=" << leaf->GetParentPageId() << "</TD></TR>\n";
    out << "<TR><TD COLSPAN=\"" << leaf->GetSize() << "\">"
        << "max_size=" << leaf->GetMaxSize() << ",min_size=" << leaf->GetMinSize() << ",size=" << leaf->GetSize()
        << "</TD></TR>\n";
    out << "<TR>";
    for (int i = 0; i < leaf->GetSize(); i++) {
      Row ans;
      processor_.DeserializeToKey(leaf->KeyAt(i), ans, schema);
      out << "<TD>" << ans.GetField(0)->toString() << "</TD>\n";
    }
    out << "</TR>";
    // Print table end
    out << "</TABLE>>];\n";
    // Print Leaf node link if there is a next page
    if (leaf->GetNextPageId() != INVALID_PAGE_ID) {
      out << leaf_prefix << leaf->GetPageId() << " -> " << leaf_prefix << leaf->GetNextPageId() << ";\n";
      out << "{rank=same " << leaf_prefix << leaf->GetPageId() << " " << leaf_prefix << leaf->GetNextPageId() << "};\n";
    }

    // Print parent links if there is a parent
    if (leaf->GetParentPageId() != INVALID_PAGE_ID) {
      out << internal_prefix << leaf->GetParentPageId() << ":p" << leaf->GetPageId() << " -> " << leaf_prefix
          << leaf->GetPageId() << ";\n";
    }
  } else {
    auto *inner = reinterpret_cast<InternalPage *>(page);
    // Print node name
    out << internal_prefix << inner->GetPageId();
    // Print node properties
    out << "[shape=plain color=pink ";  // why not?
    // Print data of the node
    out << "label=<<TABLE BORDER=\"0\" CELLBORDER=\"1\" CELLSPACING=\"0\" CELLPADDING=\"4\">\n";
    // Print data
    out << "<TR><TD COLSPAN=\"" << inner->GetSize() << "\">P=" << inner->GetPageId()
        << ",Parent=" << inner->GetParentPageId() << "</TD></TR>\n";
    out << "<TR><TD COLSPAN=\"" << inner->GetSize() << "\">"
        << "max_size=" << inner->GetMaxSize() << ",min_size=" << inner->GetMinSize() << ",size=" << inner->GetSize()
        << "</TD></TR>\n";
    out << "<TR>";
    for (int i = 0; i < inner->GetSize(); i++) {
      out << "<TD PORT=\"p" << inner->ValueAt(i) << "\">";
      if (i > 0) {
        Row ans;
        processor_.DeserializeToKey(inner->KeyAt(i), ans, schema);
        out << ans.GetField(0)->toString();
      } else {
        out << " ";
      }
      out << "</TD>\n";
    }
    out << "</TR>";
    // Print table end
    out << "</TABLE>>];\n";
    // Print Parent link
    if (inner->GetParentPageId() != INVALID_PAGE_ID) {
      out << internal_prefix << inner->GetParentPageId() << ":p" << inner->GetPageId() << " -> " << internal_prefix
          << inner->GetPageId() << ";\n";
    }
    // Print leaves
    for (int i = 0; i < inner->GetSize(); i++) {
      auto child_page = reinterpret_cast<BPlusTreePage *>(bpm->FetchPage(inner->ValueAt(i))->GetData());
      ToGraph(child_page, bpm, out, schema);
      if (i > 0) {
        auto sibling_page = reinterpret_cast<BPlusTreePage *>(bpm->FetchPage(inner->ValueAt(i - 1))->GetData());
        if (!sibling_page->IsLeafPage() && !child_page->IsLeafPage()) {
          out << "{rank=same " << internal_prefix << sibling_page->GetPageId() << " " << internal_prefix
              << child_page->GetPageId() << "};\n";
        }
        bpm->UnpinPage(sibling_page->GetPageId(), false);
      }
    }
  }
  bpm->UnpinPage(page->GetPageId(), false);
}

/**
 * This function is for debug only, you don't need to modify
 */
void BPlusTree::ToString(BPlusTreePage *page, BufferPoolManager *bpm) const {
  if (page->IsLeafPage()) {
    auto *leaf = reinterpret_cast<LeafPage *>(page);
    std::cout << "Leaf Page: " << leaf->GetPageId() << " parent: " << leaf->GetParentPageId()
              << " next: " << leaf->GetNextPageId() << std::endl;
    for (int i = 0; i < leaf->GetSize(); i++) {
      std::cout << leaf->KeyAt(i) << ",";
    }
    std::cout << std::endl;
    std::cout << std::endl;
  } else {
    auto *internal = reinterpret_cast<InternalPage *>(page);
    std::cout << "Internal Page: " << internal->GetPageId() << " parent: " << internal->GetParentPageId() << std::endl;
    for (int i = 0; i < internal->GetSize(); i++) {
      std::cout << internal->KeyAt(i) << ": " << internal->ValueAt(i) << ",";
    }
    std::cout << std::endl;
    std::cout << std::endl;
    for (int i = 0; i < internal->GetSize(); i++) {
      ToString(reinterpret_cast<BPlusTreePage *>(bpm->FetchPage(internal->ValueAt(i))->GetData()), bpm);
      bpm->UnpinPage(internal->ValueAt(i), false);
    }
  }
}

bool LeafPage::CheckOrder(const KeyManager &KM) {
  for (int i = 0; i < GetSize() - 1; i++) {
    if (KM.CompareKeys(KeyAt(i), KeyAt(i + 1)) >= 0) {
      std::cout << ValueAt(i).Get() << "" << ValueAt(i + 1).Get() << std::endl;
    }
    //    std::cout << ValueAt(i).Get() << std::endl;
  }
  return true;
}

bool BPlusTree::Check() {
  bool all_unpinned = buffer_pool_manager_->CheckAllUnpinned();
  if (!all_unpinned) {
    LOG(ERROR) << "problem in page unpin" << endl;
  }
  return all_unpinned;
}