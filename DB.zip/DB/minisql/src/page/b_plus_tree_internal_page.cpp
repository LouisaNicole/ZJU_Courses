#include "page/b_plus_tree_internal_page.h"

#include "index/generic_key.h"

#define pairs_off (data_)
#define pair_size (GetKeySize() + sizeof(page_id_t))
#define key_off 0
#define val_off GetKeySize()

/**
 * TODO: Student Implement
 */
/*****************************************************************************
 * HELPER METHODS AND UTILITIES
 *****************************************************************************/
/*
 * Init method after creating a new internal page
 * Including set page type, set current size, set page id, set parent id and set
 * max page size
 */
void InternalPage::Init(page_id_t page_id, page_id_t parent_id, int key_size, int max_size) {
    // 设置页面的类型为内部页面
    SetPageType(IndexPageType::INTERNAL_PAGE);
    // 设置页面的当前条目数为0
    SetSize(0);
    // 设置页面的ID，这是页面的唯一标识符
    SetPageId(page_id);
    // 设置父页面的ID，用于B+树结构中定位页面的父节点
    SetParentPageId(parent_id);
    // 设置页面可以包含的最大条目数
    SetMaxSize(max_size);
    // 设置每个键的大小，这影响了页面能存储的键值对数量
    SetKeySize(key_size);
}

/*
 * Helper method to get/set the key associated with input "index"(a.k.a
 * array offset)
 */
GenericKey *InternalPage::KeyAt(int index) {
  return reinterpret_cast<GenericKey *>(pairs_off + index * pair_size + key_off);
}

void InternalPage::SetKeyAt(int index, GenericKey *key) {
  memcpy(pairs_off + index * pair_size + key_off, key, GetKeySize());
}

page_id_t InternalPage::ValueAt(int index) const {
  return *reinterpret_cast<const page_id_t *>(pairs_off + index * pair_size + val_off);
}

void InternalPage::SetValueAt(int index, page_id_t value) {
  *reinterpret_cast<page_id_t *>(pairs_off + index * pair_size + val_off) = value;
}

int InternalPage::ValueIndex(const page_id_t &value) const {
  for (int i = 0; i < GetSize(); ++i) {
    if (ValueAt(i) == value)
      return i;
  }
  return -1;
}

void *InternalPage::PairPtrAt(int index) {
  return KeyAt(index);
}

void InternalPage::PairCopy(void *dest, void *src, int pair_num) {
  memcpy(dest, src, pair_num * (GetKeySize() + sizeof(page_id_t)));
}
/*****************************************************************************
 * LOOKUP
 *****************************************************************************/
/*
 * Find and return the child pointer(page_id) which points to the child page
 * that contains input "key"
 * Start the search from the second key(the first key should always be invalid)
 * 用了二分查找
 */
page_id_t InternalPage::Lookup(const GenericKey *key, const KeyManager &KM) {
    // 初始化左右索引，用于二分查找，忽略索引0因为它通常是特殊用途
    int left_index = 1, right_index = GetSize() - 1;
    int mid_index;

    // 当左索引不超过右索引时，执行循环
    while (left_index <= right_index) {
        // 计算中间索引
        mid_index = (left_index + right_index) / 2;
        // 获取中间索引处的键
        GenericKey* mid_key = KeyAt(mid_index);
        // 使用KeyManager比较中间键和目标键
        int cmp = KM.CompareKeys(mid_key, key);

        // 如果中间键大于目标键
        if (cmp > 0) {
            // 检查是否找到目标位置
            if (mid_index == 1 || KM.CompareKeys(KeyAt(mid_index-1), key) <= 0)
                return ValueAt(mid_index - 1);
            // 更新右索引以继续在左侧搜索
            right_index = mid_index - 1;
        }
        // 如果中间键小于目标键
        else if (cmp < 0) {
            // 检查是否找到目标位置
            if(mid_index == GetSize() - 1 || KM.CompareKeys(KeyAt(mid_index+1), key) > 0)
                return ValueAt(mid_index);
            // 更新左索引以继续在右侧搜索
            left_index = mid_index + 1;
        }
        // 如果中间键等于目标键
        else {
            return ValueAt(mid_index);
        }
    }
    // 如果循环结束未找到，返回左侧边界的前一个值
    // B+树的内部节点键是用来指示子节点中键的最大值的界限
    // 所以返回left_index - 1位置的值（即左边的分界点）
    // 指针将指向包含目标键或其应该插入位置的子树
    return ValueAt(left_index - 1);
}


/*****************************************************************************
 * INSERTION
 *****************************************************************************/
/*
 * Populate new root page with old_value + new_key & new_value
 * When the insertion cause overflow from leaf page all the way upto the root
 * page, you should create a new root page and populate its elements.
 * NOTE: This method is only called within InsertIntoParent()(b_plus_tree.cpp)
 */
void InternalPage::PopulateNewRoot(const page_id_t &old_value, GenericKey *new_key, const page_id_t &new_value) {
  SetSize(2);
  SetValueAt(0, old_value);
  SetKeyAt(1, new_key);
  SetValueAt(1, new_value);
}

/*
 * Insert new_key & new_value pair right after the pair with its value ==
 * old_value
 * @return:  new size after insertion
 */
int InternalPage::InsertNodeAfter(const page_id_t &old_value, GenericKey *new_key, const page_id_t &new_value) {
  // 首先找到old_value对应的节点，然后把它之后的所有节点向后移动
  int old_value_index = ValueIndex(old_value);
  int old_size = GetSize();
  int i;
  for (i = GetSize() - 1; i > old_value_index ; --i) {
    GenericKey* key = KeyAt(i);
    page_id_t value = ValueAt(i);
    SetKeyAt(i+1, key);
    SetValueAt(i+1, value);
  }
  // 插入new_key和new_value
  SetKeyAt(i+1, new_key);
  SetValueAt(i+1, new_value);
  SetSize(old_size + 1);
  return GetSize();
}

/*****************************************************************************
 * SPLIT
 *****************************************************************************/
/*
 * Remove half of key & value pairs from this page to "recipient" page
 * buffer_pool_manager 是干嘛的？传给CopyNFrom()用于Fetch数据页
 */
void InternalPage::MoveHalfTo(InternalPage *recipient, BufferPoolManager *buffer_pool_manager) {
  int total_size = this->GetSize(); // 当前节点的数目
  int rec_size = recipient->GetSize(); // 目标节点的数目
  int size_after_move = total_size / 2; // 移动后当前节点剩余的数目
  int size_moved = total_size - size_after_move; // 移动的数目
  int cur_index = size_after_move;

  for (int i = rec_size; cur_index < GetSize(); i++, cur_index++) {
    // 移动
    recipient->SetKeyAt(i, this->KeyAt(cur_index));
    recipient->SetValueAt(i, this->ValueAt(cur_index));
    // 更新孩子节点的指针
    Page* page = buffer_pool_manager->FetchPage(this->ValueAt(cur_index));
    BPlusTreePage* node = reinterpret_cast<BPlusTreePage*>(page);
    node->SetParentPageId(recipient->GetPageId());
    buffer_pool_manager->UnpinPage(node->GetPageId(), true);
  }
  // 更新size
  IncreaseSize(-size_moved);
  recipient->IncreaseSize(size_moved);
}

/* Copy entries into me, starting from {items} and copy {size} entries.
 * Since it is an internal page, for all entries (pages) moved, their parents page now changes to me.
 * So I need to 'adopt' them by changing their parent page id, which needs to be persisted with BufferPoolManger
 *
 */
void InternalPage::CopyNFrom(void *src, int size, BufferPoolManager *buffer_pool_manager) {
    // 设置当前页面的大小为新复制的元素数量
    SetSize(size);
    
    // 使用memcpy将src指向的数据复制到当前页面的data_成员中
    // 复制的总大小是元素数量乘以每个元素的大小（键的大小加上页面ID的大小）
    memcpy(data_, src, size * (GetKeySize() + sizeof(page_id_t)));

    // 遍历新复制的每个元素
    for(int i=0; i<size; i++){
        // 获取每个元素对应的页面ID
        page_id_t pageId = ValueAt(GetSize() + i);
        // 从缓冲池管理器中获取对应页面ID的页面，并转换为BPlusTreePage类型
        BPlusTreePage* page = reinterpret_cast<BPlusTreePage*>(buffer_pool_manager->FetchPage(pageId)->GetData());
        // 设置该页面的父页面ID为当前页面的ID
        page->SetParentPageId(GetPageId());
        // 完成修改后，释放该页面（减少固定计数并标记为脏页）
        buffer_pool_manager->UnpinPage(pageId, true);
    }
}


/*****************************************************************************
 * REMOVE
 *****************************************************************************/
/*
 * Remove the key & value pair in internal page according to input index(a.k.a
 * array offset)
 * NOTE: store key&value pair continuously after deletion
 */
void InternalPage::Remove(int index) {
  // 从指定的索引开始，将后续的元素前移一位，覆盖要删除的元素
  for(int i=index; i<GetSize()-1; i++){
    SetKeyAt(i, KeyAt(i+1));
    SetValueAt(i, ValueAt(i+1));
  }
  SetSize(GetSize()-1);
}

/*
 * Remove the only key & value pair in internal page and return the value
 * NOTE: only call this method within AdjustRoot()(in b_plus_tree.cpp)
 */
page_id_t InternalPage::RemoveAndReturnOnlyChild() {
  SetSize(0);
  return ValueAt(0);
}

/*****************************************************************************
 * MERGE
 *****************************************************************************/
/*
 * Remove all of key & value pairs from this page to "recipient" page.
 * The middle_key is the separation key you should get from the parent. You need
 * to make sure the middle key is added to the recipient to maintain the invariant.
 * You also need to use BufferPoolManager to persist changes to the parent page id for those
 * pages that are moved to the recipient
 */
// left <- right
void InternalPage::MoveAllTo(InternalPage *recipient, GenericKey *middle_key, BufferPoolManager *buffer_pool_manager) {
    int old_size = GetSize();
    int rec_size = recipient->GetSize(); // 目标节点的数目
    for(int i=0; i<old_size; i++){
      // 移动
      recipient->SetKeyAt(rec_size + i, KeyAt(i));
      recipient->SetValueAt(rec_size + i, ValueAt(i));
      // 更新孩子节点的指针
      BPlusTreePage* bPlusTreePage = reinterpret_cast<BPlusTreePage*>(buffer_pool_manager->FetchPage(ValueAt(i))->GetData());
      bPlusTreePage->SetParentPageId(recipient->GetPageId());
      buffer_pool_manager->UnpinPage(ValueAt(i), true);
    }
    // 更新size
    SetSize(0);
    recipient->SetSize(recipient->GetSize() + old_size);
}

/*****************************************************************************
 * REDISTRIBUTE
 *****************************************************************************/
/*
 * Remove the first key & value pair from this page to tail of "recipient" page.
 *
 * The middle_key is the separation key you should get from the parent. You need
 * to make sure the middle key is added to the recipient to maintain the invariant.
 * You also need to use BufferPoolManager to persist changes to the parent page id for those
 * pages that are moved to the recipient
 */
void InternalPage::MoveFirstToEndOf(InternalPage *recipient, GenericKey *middle_key,
                                    BufferPoolManager *buffer_pool_manager) {
  // make sure the middle key is added to the recipient to maintain the invariant
  SetKeyAt(0, middle_key);
  // Append an entry at the end.
  recipient->CopyLastFrom(KeyAt(0), ValueAt(0), buffer_pool_manager);
  Remove(0);
}

/* Append an entry at the end.
 * Since it is an internal page, the moved entry(page)'s parent needs to be updated.
 * So I need to 'adopt' it by changing its parent page id, which needs to be persisted with BufferPoolManger
 */
void InternalPage::CopyLastFrom(GenericKey *key, const page_id_t value, BufferPoolManager *buffer_pool_manager) {
  // 在末尾插入新pair
  int old_size = GetSize();
  SetSize(old_size + 1);
  SetKeyAt(old_size, key);
  SetValueAt(old_size, value);
  // 修改孩子节点的父指针
  // 取出value对应的page的内容，即该pair的value对应的孩子节点信息
  InternalPage * internalPage = reinterpret_cast<InternalPage*>(buffer_pool_manager->FetchPage(value)->GetData());
  // 更新孩子节点的父亲指针
  internalPage->SetParentPageId(GetPageId());
  // 由于fecth page时将这个数据页固定了，现在处理完了应该解除固定
  buffer_pool_manager->UnpinPage(value, true);
}

/*
 * Remove the last key & value pair from this page to head of "recipient" page.
 * You need to handle the original dummy key properly, e.g. updating recipient’s array to position the middle_key at the
 * right place.
 * You also need to use BufferPoolManager to persist changes to the parent page id for those pages that are
 * moved to the recipient
 */
void InternalPage::MoveLastToFrontOf(InternalPage *recipient, GenericKey *middle_key,
                                     BufferPoolManager *buffer_pool_manager) {
  int old_size = GetSize();
  int rec_size = recipient->GetSize();
  // 目标节点pair后移
  recipient->SetKeyAt(0, middle_key);
  for (int i = rec_size; i > 0; i--) {
    recipient->SetKeyAt(i, recipient->KeyAt(i - 1));
    recipient->SetValueAt(i, recipient->ValueAt(i - 1));
  }
  // 将当前节点的最后一个节点放到目标节点头
  recipient->SetKeyAt(0, this->KeyAt(this->GetSize() - 1));
  recipient->SetValueAt(0, this->ValueAt(this->GetSize() - 1));

  // 更新孩子节点父指针
  BPlusTreePage* node = reinterpret_cast<BPlusTreePage*>(buffer_pool_manager->FetchPage(ValueAt(GetSize() - 1))->GetData());
  node->SetParentPageId(recipient->GetPageId());
  buffer_pool_manager->UnpinPage(ValueAt(GetSize() - 1), true);
  // 更新size
  SetSize(old_size - 1);
  recipient->SetSize(rec_size + 1);
}

/* Append an entry at the beginning.
 * Since it is an internal page, the moved entry(page)'s parent needs to be updated.
 * So I need to 'adopt' it by changing its parent page id, which needs to be persisted with BufferPoolManger
 */
void InternalPage::CopyFirstFrom(const page_id_t value, BufferPoolManager *buffer_pool_manager) {
  int old_size = GetSize();
  // 当前节点pair后移
  for(int i=old_size-1; i>=0; i--){
    GenericKey* key = KeyAt(i);
    page_id_t temp_value = ValueAt(i);
    SetKeyAt(i+1, key);
    SetValueAt(i+1, temp_value);
  }
  // 在当前节点的开头插入新pair
  SetSize(old_size+1);
  SetValueAt(0, value);
  // 更新孩子节点父指针
  InternalPage * internalPage = reinterpret_cast<InternalPage*>(buffer_pool_manager->FetchPage(value));
  internalPage->SetParentPageId(GetPageId());
  buffer_pool_manager->UnpinPage(value, true);
}