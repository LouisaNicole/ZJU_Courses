#include "page/b_plus_tree_leaf_page.h"

#include <algorithm>

#include "index/generic_key.h"

#define pairs_off (data_)
#define pair_size (GetKeySize() + sizeof(RowId))
#define key_off 0
#define val_off GetKeySize()
/*****************************************************************************
 * HELPER METHODS AND UTILITIES
 *****************************************************************************/

/**
 * TODO: Student Implement
 */
/**
 * Init method after creating a new leaf page
 * Including set page type, set current size to zero, set page id/parent id, set
 * next page id and set max size
 * 未初始化next_page_id
 */
void LeafPage::Init(page_id_t page_id, page_id_t parent_id, int key_size, int max_size) {
    SetPageType(IndexPageType::LEAF_PAGE);
    SetSize(0);
    SetPageId(page_id);
    SetParentPageId(parent_id);
    SetKeySize(key_size);
    SetMaxSize(max_size);
    SetNextPageId(INVALID_PAGE_ID);
}

/**
 * Helper methods to set/get next page id
 */
page_id_t LeafPage::GetNextPageId() const {
  return next_page_id_;
}

void LeafPage::SetNextPageId(page_id_t next_page_id) {
  next_page_id_ = next_page_id;
  if (next_page_id == 0) {
    LOG(INFO) << "Fatal error";
  }
}

/**
 * TODO: Student Implement
 */
/**
 * Helper method to find the first index i so that pairs_[i].first >= key
 * NOTE: This method is only used when generating index iterator
 * 二分查找
 */
int LeafPage::KeyIndex(const GenericKey *key, const KeyManager &KM) {
  int left_index = 0, right_index = GetSize() - 1;
  int mid_index;
  int ret_index = INVALID_PAGE_ID;
  while (left_index <= right_index){
    mid_index = (left_index + right_index) / 2;
    GenericKey * mid_key = KeyAt(mid_index);
    int cmp = KM.CompareKeys(mid_key, key);
    if (cmp > 0){
      // mid的key大于要查找的key
      // pairs_[i].first >= key 记录潜在的返回索引
      ret_index = mid_index;
      right_index = mid_index - 1;
    }
    else if (cmp < 0) {
      left_index = mid_index + 1;
    }
    else {
      // mid的key等于要查找的key
      return mid_index;
    }
  }
  // 如果循环结束未找到完全匹配的键，返回最后记录的潜在位置
  return ret_index;
}

/*
 * Helper method to find and return the key associated with input "index"(a.k.a
 * array offset)
 */
GenericKey *LeafPage::KeyAt(int index) {
  return reinterpret_cast<GenericKey *>(pairs_off + index * pair_size + key_off);
}

void LeafPage::SetKeyAt(int index, GenericKey *key) {
  memcpy(pairs_off + index * pair_size + key_off, key, GetKeySize());
}

RowId LeafPage::ValueAt(int index) const {
  return *reinterpret_cast<const RowId *>(pairs_off + index * pair_size + val_off);
}

void LeafPage::SetValueAt(int index, RowId value) {
  *reinterpret_cast<RowId *>(pairs_off + index * pair_size + val_off) = value;
}

void *LeafPage::PairPtrAt(int index) {
  return KeyAt(index);
}

void LeafPage::PairCopy(void *dest, void *src, int pair_num) {
  memcpy(dest, src, pair_num * (GetKeySize() + sizeof(RowId)));
}
/*
 * Helper method to find and return the key & value pair associated with input
 * "index"(a.k.a. array offset)
 */
std::pair<GenericKey *, RowId> LeafPage::GetItem(int index) { return {KeyAt(index), ValueAt(index)}; }

/*****************************************************************************
 * INSERTION
 *****************************************************************************/
/*
 * Insert key & value pair into leaf page ordered by key
 * @return page size after insertion
 */
int LeafPage::Insert(GenericKey *key, const RowId &value, const KeyManager &KM) {
  // 找到第一个满足pairs_[i].first>=的pair
  int old_index = KeyIndex(key, KM);
  int old_size = GetSize();

  // 如果该键已经存在，就无需插入直接返回
  if (KeyAt(old_index) == key)
    return -1;
  if(old_index >= old_size || old_index == INVALID_PAGE_ID)
    old_index = old_size;
  // 否则就将index处的pair与其之后的pair往后挪
  PairCopy(PairPtrAt(old_index + 1), PairPtrAt(old_index), old_size - old_index);
  // 把新pair插到这里
  SetKeyAt(old_index, key);
  SetValueAt(old_index, value);
  SetSize(old_size+1);
  return GetSize();
}

/*****************************************************************************
 * SPLIT
 *****************************************************************************/
/*
 * Remove half of key & value pairs from this page to "recipient" page
 */
void LeafPage::MoveHalfTo(LeafPage *recipient) {
  int old_size = GetSize(); // 当前节点的数目
  int half = (old_size + 1) / 2; // 移动后当前节点剩余的数目
  SetSize(half);
  void* pos = PairPtrAt(half);
  recipient->CopyNFrom(pos, old_size / 2);
  // 为了保持两个页面的平衡，采用(old_size + 1) / 2
  // 来确定保留在当前页面的元素数量
  // 而old_size / 2则是移动到接收页面的元素数量
  // 比如5个，左边留3个，右边留2个
}

/*
 * Copy starting from items, and copy {size} number of elements into me.
 */
void LeafPage::CopyNFrom(void *src, int size) {
  // 将size个pair从src复制到dest
  memcpy(data_,src,size*(GetKeySize() + sizeof(RowId)));
  SetSize(size);
}

/*****************************************************************************
 * LOOKUP
 *****************************************************************************/
/*
 * For the given key, check to see whether it exists in the leaf page. If it
 * does, then store its corresponding value in input "value" and return true.
 * If the key does not exist, then return false
 */
bool LeafPage::Lookup(const GenericKey *key, RowId &value, const KeyManager &KM) {
  int index = KeyIndex(key, KM);
  // 没找到
  if (index == INVALID_PAGE_ID || index >= GetSize()) return false; 
  int cmp = KM.CompareKeys(KeyAt(index), key);
  if (cmp != 0) return false;
  // 找到
  value = ValueAt(index);
  return true;
}

/*****************************************************************************
 * REMOVE
 *****************************************************************************/
/*
 * First look through leaf page to see whether delete key exist or not. If
 * existed, perform deletion, otherwise return immediately.
 * NOTE: store key&value pair continuously after deletion
 * @return  page size after deletion
 */
int LeafPage::RemoveAndDeleteRecord(const GenericKey *key, const KeyManager &KM) {
  int index = KeyIndex(key, KM);
  // 没找到
  if (index == INVALID_PAGE_ID || index >= GetSize()) return -1;
  int old_size = GetSize();
  int cmp = KM.CompareKeys(KeyAt(index), key);
  if (cmp != 0) return GetSize();
  // 找到
  // 将该pair从对应的节点中删掉，后续pair前移
  for (int i = index; i < old_size - 1; ++i) {
    SetKeyAt(i, KeyAt(i+1));
    SetValueAt(i, ValueAt(i+1));
  }
  SetSize(old_size - 1);
  return GetSize();
}

/*****************************************************************************
 * MERGE
 *****************************************************************************/
/*
 * Remove all key & value pairs from this page to "recipient" page. Don't forget
 * to update the next_page id in the sibling page
 */
void LeafPage::MoveAllTo(LeafPage *recipient) {
  int old_size = recipient->GetSize();
  recipient->PairCopy(recipient->KeyAt(old_size), KeyAt(0), GetSize());
  recipient->SetSize(old_size + GetSize());
  recipient->SetNextPageId(GetNextPageId());
  SetSize(0);
}

/*****************************************************************************
 * REDISTRIBUTE
 *****************************************************************************/
/*
 * Remove the first key & value pair from this page to "recipient" page.
 *
 */
void LeafPage::MoveFirstToEndOf(LeafPage *recipient) {
  // 将第一个pair添加到另一个节点的末尾
  recipient->CopyLastFrom(KeyAt(0), ValueAt(0));
  int old_size = GetSize();
  // 后续节点前移
  for (int i = 0; i < old_size-1; ++i) {
    SetKeyAt(i, KeyAt(i+1));
    SetValueAt(i, ValueAt(i+1));
  }
  SetSize(old_size - 1);
}

/*
 * Copy the item into the end of my item list. (Append item to my array)
 */
void LeafPage::CopyLastFrom(GenericKey *key, const RowId value) {
  int old_size = GetSize();
  SetSize(old_size + 1);
  SetKeyAt(old_size, key);
  SetValueAt(old_size, value);
}

/*
 * Remove the last key & value pair from this page to "recipient" page.
 */
void LeafPage::MoveLastToFrontOf(LeafPage *recipient) {
  int old_size = GetSize();
  // 将该节点的最后一个pair插入到目标节点头
  recipient->CopyFirstFrom(KeyAt(old_size-1), ValueAt(old_size-1));
  SetSize(old_size - 1);
}

/*
 * Insert item at the front of my items. Move items accordingly.
 *
 */
void LeafPage::CopyFirstFrom(GenericKey *key, const RowId value) {
  int old_size = GetSize();
  // 将节点中的pair后移
  for (int i = old_size-1; i >= 0; --i) {
    GenericKey* temp_key = KeyAt(i);
    RowId temp_value = ValueAt(i);
    SetKeyAt(i+1, temp_key);
    SetValueAt(i+1, temp_value);
  }
  SetSize(old_size + 1);
  // 插入到节点头
  SetKeyAt(0, key);
  SetValueAt(0, value);
}