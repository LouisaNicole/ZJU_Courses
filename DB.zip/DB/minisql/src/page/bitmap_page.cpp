#include "page/bitmap_page.h"

#include "glog/logging.h"

/**
 * TODO: Student Implement
 */
template <size_t PageSize>
bool BitmapPage<PageSize>::AllocatePage(uint32_t &page_offset) {
    // 检查是否所有页面都已分配完毕
    if(page_allocated_ == GetMaxSupportedSize()) {
        // 没有更多页面可分配，返回 false
        return false;
    }
    // 已分配页面数增加
    page_allocated_ ++;
    // 设置 page_offset 为下一个空闲页面的索引
    page_offset = next_free_page_;

    // 计算位图中存储此页面位的字节索引
    uint32_t byte_index = next_free_page_ / 8;
    // 计算该字节内的位索引
    uint8_t bit_index = next_free_page_ % 8;
    // 在计算位置处将位设置为 1，表示页面现在已分配
    bytes[byte_index] |= (1 << (7 - bit_index));

    // 遍历位图以找到下一个空闲页面
    for(uint32_t i = next_free_page_ ; i< GetMaxSupportedSize(); i++){
        // 检查索引 i 处的页面是否空闲
        if(IsPageFree(i)){
            // 更新下一个空闲页面的索引为 i
            next_free_page_ = i;
            break;
        }
    }
    // 返回 true 表示页面已成功分配
    return true;
}

/**
 * TODO: Student Implement
 */
template <size_t PageSize>
bool BitmapPage<PageSize>::DeAllocatePage(uint32_t page_offset) {
    // 检查给定偏移处的页面是否已经空闲
    if(IsPageFree(page_offset))
        return false; // 页面已经空闲，返回 false

    // 已分配页面数减少
    page_allocated_--;

    // 计算位图中存储此页面位的字节索引
    uint32_t byte_index = page_offset / 8;
    // 计算该字节内的位索引
    uint8_t bit_index = page_offset % 8;
    // 将计算位置的位清零，表示页面现在已空闲
    bytes[byte_index] &= ~(1 << (7 - bit_index));

    // 如果这个页面的偏移小于当前记录的下一个空闲页面的偏移，更新它
    if(page_offset < next_free_page_){
        next_free_page_ = page_offset;
    }

    // 返回 true 表示页面已成功释放
    return true;
}


/**
 * TODO: Student Implement
 */
template <size_t PageSize>
bool BitmapPage<PageSize>::IsPageFree(uint32_t page_offset) const {
    // 计算给定页面偏移在位图中的字节索引
    uint32_t byte_index = page_offset / 8;
    // 计算在该字节中的位索引
    uint8_t bit_index = page_offset % 8;
    // 调用 IsPageFreeLow 方法，传入字节索引和位索引，判断页面是否空闲
    return IsPageFreeLow(byte_index, bit_index);
}


template <size_t PageSize>
bool BitmapPage<PageSize>::IsPageFreeLow(uint32_t byte_index, uint8_t bit_index) const {
  return (bytes[byte_index] & (1 << (7 - bit_index))) == 0;
}

template class BitmapPage<64>;

template class BitmapPage<128>;

template class BitmapPage<256>;

template class BitmapPage<512>;

template class BitmapPage<1024>;

template class BitmapPage<2048>;

template class BitmapPage<4096>;