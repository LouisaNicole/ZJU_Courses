#include "concurrency/lock_manager.h"

#include <iostream>
#include <unordered_map>

#include "common/rowid.h"
#include "concurrency/txn.h"
#include "concurrency/txn_manager.h"

void LockManager::SetTxnMgr(TxnManager *txn_mgr) { txn_mgr_ = txn_mgr; }

bool LockManager::LockShared(Txn *txn, const RowId &rid) {
  // 创建 std::unique_lock<std::mutex> 对象传入私有变量 latch_ 实现加锁
  std::unique_lock<std::mutex> my_lock(latch_);
  // 锁相关信息
  txn_id_t request_id = txn->GetTxnId();
  LockMode request_mode = LockMode::kShared;
  IsolationLevel request_level = txn->GetIsolationLevel();
  TxnState request_state = txn->GetState();
  TxnState shrink_state = TxnState::kShrinking;
  TxnState exception_state = TxnState::kAborted;
  IsolationLevel exception_level = IsolationLevel::kReadUncommitted;
  if (request_level == exception_level) { // 中止该事务并抛出异常
    AbortReason exception_reason = AbortReason::kLockSharedOnReadUncommitted;
    // 检查事务的隔离级别，防止在 Read Uncommitted 下以共享模式获取锁，事务可以读取其他事务未提交的数据，导致数据不一致
    txn->SetState(exception_state);
    throw TxnAbortException(request_id, exception_reason);
  }
  if (request_state == shrink_state) {
    AbortReason exception_reason = AbortReason::kLockOnShrinking;
    txn->SetState(exception_state);
    throw TxnAbortException(request_id, exception_reason);
  }
  else {
    // 准备锁
    LockPrepare(txn, rid);
    // 从私有变量 lock_table_ 锁表中获取 rid 相关的锁请求队列
    // 为了避免复制 LockRequestQueue 对象，这里直接用 ‘&’ 获取引用以便对其进行后续的操作
    LockRequestQueue &my_queue = lock_table_[rid];
    // 将锁请求以共享模式添加到锁表中
    my_queue.EmplaceLockRequest(request_id, request_mode);
    // 如果该行有正在进行的写请求，则等待所有写请求完成
    // 条件变量 cv 的 wait() 函数使当前线程进入等待状态并释放互斥锁
    if (my_queue.is_writing_) {
      // 定义一个谓词函数（可以在if语句内部定义），用于判断等待条件是否满足
      // 创建一个 lambda 表达式，并将其赋值给 my_predicate 变量。lambda 表达式以方括号 [...] 开始，表示捕获外部变量，这里捕获了 my_queue 和 txn。
      // -> bool 表示该 lambda 表达式返回一个布尔值
      auto my_predicate = [&my_queue, txn]() -> bool {
        bool isAborted = (txn->GetState() == TxnState::kAborted);
        bool isNotWrite = !my_queue.is_writing_;
        bool isCondition = (isAborted || isNotWrite);
        return isCondition;
      };
      // 在等待期间，条件变量会周期性地调用 my_predicate 谓词函数来检查等待条件是否满足。
      // 只有当谓词函数返回 false 时，线程才会继续等待。当谓词函数返回 true 时，条件满足，线程将被唤醒并继续执行后续的操作。
      my_queue.cv_.wait(my_lock, my_predicate);  // 条件变量 cv 的 wait 方法用于阻塞当前线程，直到满足特定条件
    }
    // 调用 CheckAbort 函数检查事务是否因死锁检测而中止
    CheckAbort(txn, my_queue);
    // 增加锁的共享计数器
    (my_queue.sharing_cnt_)++;
    // 使用 emplace(rid) 对私有变量 shared_lock_set_ 进行插入操作，将 rid 添加到事务的共享锁集合中
    txn->GetSharedLockSet().emplace(rid);
    // 将锁授予该事务，将锁请求的私有变量 granted_ 设置为 kShared
    std::list<LockRequest>::iterator my_ite = my_queue.GetLockRequestIter(request_id);
    my_ite->granted_ = request_mode;
    return true;
  }
}

bool LockManager::LockExclusive(Txn *txn, const RowId &rid) {
  // 创建 std::unique_lock<std::mutex> 对象传入私有变量 latch_ 实现加锁
  std::unique_lock<std::mutex> my_lock(latch_);
  // 锁相关信息
  txn_id_t request_id = txn->GetTxnId();
  LockMode request_mode = LockMode::kExclusive;
  // 准备锁
  LockPrepare(txn, rid);
  // 从私有变量 lock_table_ 锁表中获取 rid 相关的锁请求队列
  LockRequestQueue &my_queue = lock_table_[rid];
  // 将锁请求以独占模式添加到锁表中
  my_queue.EmplaceLockRequest(request_id, request_mode);
  // 如果有进行的写请求或存在共享锁占用，则等待所有写请求和共享锁释放
  if (my_queue.is_writing_ || my_queue.sharing_cnt_ != 0) {
    // 定义一个谓词函数（可以在if语句内部定义），用于判断等待条件是否满足
    auto my_predicate = [&my_queue, txn]() -> bool {
      bool isAborted = (txn->GetState() == TxnState::kAborted);
      bool isNotWrite = !my_queue.is_writing_;
      bool isNotShare = (my_queue.sharing_cnt_ == 0);
      bool isCondition = (isAborted || (isNotWrite && isNotShare));
      return isCondition;
    };
    // 使用条件变量的 .wait() 方法等待条件变量满足特定条件
    my_queue.cv_.wait(my_lock, my_predicate);
  }
  // 调用 CheckAbort 函数检查事务是否因死锁检测而中止
  CheckAbort(txn, my_queue);
  // 对于独占锁，同一时间只能有一个事务持有该锁，标记请求队列正在写入状态
  my_queue.is_writing_ = true;
  // 使用 emplace(rid) 对私有变量 exclusive_lock_set_ 进行插入操作，将 rid 添加到事务的独占锁集合中
  txn->GetExclusiveLockSet().emplace(rid);
  // 将锁授予该事务，将锁请求的私有变量 granted_ 设置为 kExclusive
  std::list<LockRequest>::iterator my_ite = my_queue.GetLockRequestIter(request_id);
  my_ite->granted_ = request_mode;
  return true;
}

bool LockManager::LockUpgrade(Txn *txn, const RowId &rid) {
  // 创建 std::unique_lock<std::mutex> 对象传入私有变量 latch_ 实现加锁
  std::unique_lock<std::mutex> my_lock(latch_);
  // 准备锁
  LockPrepare(txn, rid);
  // 锁的相关信息
  txn_id_t request_id = txn->GetTxnId();
  LockMode request_mode = LockMode::kExclusive;
  TxnState request_state = txn->GetState();
  TxnState shrink_state = TxnState::kShrinking;
  TxnState exception_state = TxnState::kAborted;
  // 从私有变量 lock_table_ 锁表中获取 rid 相关的锁请求队列
  LockRequestQueue &my_queue = lock_table_[rid];
  // 如果事务正在缩减过程中，不允许进行锁升级的情况
  if (request_state == shrink_state) {
    AbortReason exception_reason = AbortReason::kLockOnShrinking;
    txn->SetState(exception_state);
    throw TxnAbortException(request_id, exception_reason);
  }
  // 如果已经有其他事务正在进行锁升级操作，这会导致冲突
  else if (my_queue.is_upgrading_) {
    AbortReason exception_reason = AbortReason::kUpgradeConflict;
    txn->SetState(exception_state);
    throw TxnAbortException(request_id, exception_reason);
  }
  else {
//    my_ite->granted_ = LockMode::kShared;
    my_queue.is_upgrading_ = true;
    // 如果该行有正在进行的写请求，则等待所有写请求完成
    if (my_queue.is_writing_ || my_queue.sharing_cnt_ > 1) {
      auto my_predicate = [&my_queue, txn]() -> bool {
        bool isAborted = (txn->GetState() == TxnState::kAborted);
        bool isNotWrite = !my_queue.is_writing_;
        bool isOnlyShare = (my_queue.sharing_cnt_ == 1);
        bool isCondition = (isAborted || (isNotWrite && isOnlyShare));
        return isCondition;
      };
      my_queue.cv_.wait(my_lock, my_predicate);
    }
    // 调用 CheckAbort 函数检查事务是否因死锁检测而中止
    CheckAbort(txn, my_queue);
    // 从事务的共享锁集合中删除当前行
    txn->GetSharedLockSet().erase(rid);
    // 更新锁请求队列的状态
    (my_queue.sharing_cnt_)--;
    my_queue.is_writing_ = true;
    my_queue.is_upgrading_ = false;
    std::list<LockRequest>::iterator my_ite = my_queue.GetLockRequestIter(request_id);
    // 修改锁请求迭代器的锁模式和授予模式
    my_ite->granted_ = request_mode;
    txn->GetExclusiveLockSet().emplace(rid);
    return true;
  }
}

bool LockManager::Unlock(Txn *txn, const RowId &rid) {
  // 创建 std::unique_lock<std::mutex> 对象传入私有变量 latch_ 实现加锁
  std::unique_lock<std::mutex> my_lock(latch_);
  // 锁相关信息
  txn_id_t request_id = txn->GetTxnId();
  IsolationLevel request_level = txn->GetIsolationLevel();
  IsolationLevel commit_level = IsolationLevel::kReadCommitted;
  TxnState shrink_state = TxnState::kShrinking;
  // 从私有变量 lock_table_ 锁表中获取 rid 相关的锁请求队列
  LockRequestQueue &my_queue = lock_table_[rid];
  std::list<LockRequest>::iterator my_ite = my_queue.GetLockRequestIter(request_id);
  LockMode request_mode = my_ite->lock_mode_;
  LockMode share_mode = LockMode::kShared;
  // 判断事务是否持有共享锁或独占锁，再进行删除操作
  if (txn->GetSharedLockSet().count(rid) > 0) {
    (my_queue.sharing_cnt_)-- ;
    txn->GetSharedLockSet().erase(rid);
  }
  if (txn->GetExclusiveLockSet().count(rid) > 0) {
    txn->GetExclusiveLockSet().erase(rid);
  }
  // 从队列中删除该锁
  bool request_erase = my_queue.EraseLockRequest(request_id);
  assert(request_erase);
  // 如果在 growing 阶段释放锁，则将事务状态设置为 shrinking 阶段
  // 其他线程可能会等待该事务进入 Shrinking 阶段，但该事务永远不会进入，从而导致死锁
  if (txn->GetState() == TxnState::kGrowing) txn->SetState(shrink_state);
  my_queue.is_writing_ = false;
  // 通知等待的线程，使得等待获取锁的线程将继续执行
  my_queue.cv_.notify_all();
  return true;
}

void LockManager::LockPrepare(Txn *txn, const RowId &rid) {
  // 锁相关信息
  txn_id_t request_id = txn->GetTxnId();
  TxnState request_state = txn->GetState();
  TxnState shrink_state = TxnState::kShrinking;
  TxnState exception_state = TxnState::kAborted;
  AbortReason exception_reason = AbortReason::kLockOnShrinking;
  if (request_state == shrink_state) { // 已经完成了读取操作并准备进行写入操作
    txn->SetState(exception_state);
    throw TxnAbortException(request_id, exception_reason);
  }
}

// 别的地方把事务 set abort 之后手动抛出异常了，只有对于死锁的检测会加一个 checkabort 因为是异步的
void LockManager::CheckAbort(Txn *txn, LockManager::LockRequestQueue &req_queue) {
  if (txn->GetState() == TxnState::kAborted) {
    req_queue.EraseLockRequest(txn->GetTxnId());
    throw TxnAbortException(txn->GetTxnId(), AbortReason::kDeadlock);
  }
}

void LockManager::AddEdge(txn_id_t t1, txn_id_t t2) {
  waits_for_[t1].emplace(t2);
}

void LockManager::RemoveEdge(txn_id_t t1, txn_id_t t2) {
  waits_for_[t1].erase(t2);
}

void LockManager::DeleteNode(txn_id_t txn_id) {
  waits_for_.erase(txn_id);

  auto *txn = txn_mgr_->GetTransaction(txn_id);

  for (const auto &row_id : txn->GetSharedLockSet()) {
    for (const auto &lock_req : lock_table_[row_id].req_list_) {
      if (lock_req.granted_ == LockMode::kNone) {
        RemoveEdge(lock_req.txn_id_, txn_id);
      }
    }
  }

  for (const auto &row_id : txn->GetExclusiveLockSet()) {
    for (const auto &lock_req : lock_table_[row_id].req_list_) {
      if (lock_req.granted_ == LockMode::kNone) {
        RemoveEdge(lock_req.txn_id_, txn_id);
      }
    }
  }
}

bool LockManager::HasCycle(txn_id_t &newest_tid_in_cycle) {
  // 重置私有变量
  while (!visited_path_.empty()) {
    visited_path_.pop();
  }
  visited_set_.clear();
  revisited_node_ = INVALID_TXN_ID;
  // 获取所有事务的集合，遍历等待关系的映射表添加到txn_set
  std::set<txn_id_t> txn_set;
  auto it = waits_for_.begin();
  while (it != waits_for_.end()) {
    std::set<int> set_of_ints = it->second;
    std::vector<txn_id_t> vec(set_of_ints.begin(), set_of_ints.end());
    for (const txn_id_t& t1 : vec) {
      txn_set.insert(t1);
    }
    it++;
  }
  // 在每个事务中执行DFS搜索，找到循环路径并返回路径中最新的事务ID
  for (const txn_id_t& dfs_id : txn_set) {
    bool flag = false;
    if (visited_set_.count(dfs_id) > 0) {
      revisited_node_ = dfs_id;
      flag = true;
      break;
    }
    // 首个dfs_id节点
    visited_path_.emplace(dfs_id);
    visited_set_.emplace(dfs_id);
    auto it = waits_for_[dfs_id].begin();
    while (it != waits_for_[dfs_id].end()) {
      const auto child_txn_id = *it;
      if (DFS(waits_for_, child_txn_id, visited_set_, visited_path_, revisited_node_)) {
        flag = true;
      }
      ++it;
    }
    if (flag) {
      newest_tid_in_cycle = revisited_node_;
      while (true) {
        // 找出一条循环中 txn_id 最大的值 也就是最新的事务抛弃
        if (visited_path_.empty()) break;
        // 确保newest_tid_in_cycle保存的是循环路径中最新的事务ID
        else if (revisited_node_ == visited_path_.top()) break;
        else newest_tid_in_cycle = std::max(newest_tid_in_cycle, visited_path_.top());
        visited_path_.pop();
      }
      return true;
    }
  }
  newest_tid_in_cycle = INVALID_TXN_ID;
  return false;
}

bool LockManager::DFS(const std::unordered_map<txn_id_t, std::set<txn_id_t>>& waits_for, txn_id_t txn_id,
         std::unordered_set<txn_id_t>& visited_set, std::stack<txn_id_t>& visited_path, txn_id_t& revisited_node) {
  if (visited_set.count(txn_id) > 0) {
    revisited_node = txn_id;
    return true;
  }
  visited_path.emplace(txn_id);
  visited_set.emplace(txn_id);
  if (waits_for.count(txn_id) > 0) { // 该事务存在指向的前置事务的边 需要继续 dfs
    for (const auto& child_txn_id : waits_for.at(txn_id)) {  // waits_for.at(txn_id) 获取 txn_id 对应的前置事务的集合
      if (DFS(waits_for, child_txn_id, visited_set, visited_path, revisited_node)) {
        return true;
      }
    }
  }
  // 搜索完当前事务所等待的所有事务ID后仍未找到循环路径
  // 将当前事务ID从visited_set_集合和visited_path_堆栈中移除，并返回false
  else {
    visited_path.pop();
    visited_set.erase(txn_id);
  }
  return false;
}

void LockManager::RunCycleDetection() {
  // 如果当前时间距离上次检测的时间间隔还不到设定的周期时间则继续等待
  auto start_time = std::chrono::steady_clock::now();
  while (enable_cycle_detection_) {
    auto current_time = std::chrono::steady_clock::now();
    // 还未到检测周期
    if (std::chrono::duration_cast<std::chrono::milliseconds>(current_time - start_time).count() < cycle_detection_interval_.count()) {
      continue;
    }
    // 重置计时器
    start_time = current_time;
    {
      LockMode none_mode = LockMode::kNone;
      TxnState exception_state = TxnState::kAborted;
      // 存储需要被检查的事务所请求的锁对应的行 ID，找到映射
      std::unordered_map<txn_id_t, RowId> request_row;
      // 加锁防止其他线程同时访问这些数据
      std::unique_lock<std::mutex> my_lock(latch_);
      // 获取 lock_table_ 的迭代器遍历元素
      auto request_lock_table = lock_table_.begin();
      while (request_lock_table != lock_table_.end()) {
        // 获取当前迭代器指向的行 ID 和锁请求队列
        const RowId& row_id = request_lock_table->first;
        const LockRequestQueue& request_queue = request_lock_table->second;
        // 获取锁请求队列的迭代器遍历锁请求
        auto request_list = request_queue.req_list_.begin();
        while (request_list != request_queue.req_list_.end()) {
          const LockRequest& lock_request = *request_list;
          // 如果已授予请求的状态不是 kNone 则跳过该请求
          if (lock_request.granted_ != none_mode) {
            request_list++;
            continue;
          }
          // 如果已授予请求的状态是 kNone 则表示在等待锁释放后竞争，这就需要加入到检测图中
          request_row[lock_request.txn_id_] = row_id;
          auto granted_req_it = request_queue.req_list_.begin();
          while (granted_req_it != request_queue.req_list_.end()) {
            const LockRequest& granted_req = *granted_req_it;
            if (granted_req.granted_ == none_mode) {
              granted_req_it++;
              continue;
            }
            // 因为每次加的锁都是放在 lock_table 的前面，所以前置事务锁在后面
            // 前置事务锁状态 即图中需要加上一条边 lock_request 指向前置事务 granted_req 等他释放才行
            AddEdge(lock_request.txn_id_, granted_req.txn_id_);
            granted_req_it++;
          }
          request_list++;
        }
        request_lock_table++;
      }
      // 初始化事务 ID 为无效值
      txn_id_t txn_id = INVALID_TXN_ID;
      // 当存在死锁时进行处理
      if (HasCycle(txn_id)) {
        auto* my_txn = txn_mgr_->GetTransaction(txn_id);
        DeleteNode(txn_id);
        my_txn->SetState(exception_state);
        lock_table_[request_row[txn_id]].cv_.notify_all();
      }
      waits_for_.clear();
    }
  }
}

std::vector<std::pair<txn_id_t, txn_id_t>> LockManager::GetEdgeList() {
  std::vector<std::pair<txn_id_t, txn_id_t>> result;
  // my_edge 存储与该事务相关的等待边的容器
  for (const auto& my_edge : waits_for_) {
    // 将当前事务存储在变量t1中
    txn_id_t t1 = my_edge.first;
    // 将当前事务关联的等待边容器存储在变量edges中
    const auto& edges = my_edge.second;
    for (const auto& t2 : edges) {
      // 将由事务ID t1 和 t2 组成的一对边加入到result向量中
      result.push_back({t1, t2});
    }
  }
  return result;
}
